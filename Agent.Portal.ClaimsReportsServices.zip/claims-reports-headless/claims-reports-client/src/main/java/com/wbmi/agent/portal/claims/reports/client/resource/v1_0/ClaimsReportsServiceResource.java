package com.wbmi.agent.portal.claims.reports.client.resource.v1_0;

import com.wbmi.agent.portal.claims.reports.client.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.reports.client.http.HttpInvoker;
import com.wbmi.agent.portal.claims.reports.client.problem.Problem;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public interface ClaimsReportsServiceResource {

	public static Builder builder() {
		return new Builder();
	}

	public ClaimsReportsResponse getAgencyPlClaimReport(
			String agencyId, String claimType, String dateRange)
		throws Exception;

	public HttpInvoker.HttpResponse getAgencyPlClaimReportHttpResponse(
			String agencyId, String claimType, String dateRange)
		throws Exception;

	public static class Builder {

		public Builder authentication(String login, String password) {
			_login = login;
			_password = password;

			return this;
		}

		public ClaimsReportsServiceResource build() {
			return new ClaimsReportsServiceResourceImpl(this);
		}

		public Builder endpoint(String host, int port, String scheme) {
			_host = host;
			_port = port;
			_scheme = scheme;

			return this;
		}

		public Builder header(String key, String value) {
			_headers.put(key, value);

			return this;
		}

		public Builder locale(Locale locale) {
			_locale = locale;

			return this;
		}

		public Builder parameter(String key, String value) {
			_parameters.put(key, value);

			return this;
		}

		private Builder() {
		}

		private Map<String, String> _headers = new LinkedHashMap<>();
		private String _host = "localhost";
		private Locale _locale;
		private String _login = "";
		private String _password = "";
		private Map<String, String> _parameters = new LinkedHashMap<>();
		private int _port = 8080;
		private String _scheme = "http";

	}

	public static class ClaimsReportsServiceResourceImpl
		implements ClaimsReportsServiceResource {

		public ClaimsReportsResponse getAgencyPlClaimReport(
				String agencyId, String claimType, String dateRange)
			throws Exception {

			HttpInvoker.HttpResponse httpResponse =
				getAgencyPlClaimReportHttpResponse(
					agencyId, claimType, dateRange);

			String content = httpResponse.getContent();

			_logger.fine("HTTP response content: " + content);

			_logger.fine("HTTP response message: " + httpResponse.getMessage());
			_logger.fine(
				"HTTP response status code: " + httpResponse.getStatusCode());

			try {
				return com.wbmi.agent.portal.claims.reports.client.serdes.v1_0.
					ClaimsReportsResponseSerDes.toDTO(content);
			}
			catch (Exception e) {
				_logger.log(
					Level.WARNING,
					"Unable to process HTTP response: " + content, e);

				throw new Problem.ProblemException(Problem.toDTO(content));
			}
		}

		public HttpInvoker.HttpResponse getAgencyPlClaimReportHttpResponse(
				String agencyId, String claimType, String dateRange)
			throws Exception {

			HttpInvoker httpInvoker = HttpInvoker.newHttpInvoker();

			if (_builder._locale != null) {
				httpInvoker.header(
					"Accept-Language", _builder._locale.toLanguageTag());
			}

			for (Map.Entry<String, String> entry :
					_builder._headers.entrySet()) {

				httpInvoker.header(entry.getKey(), entry.getValue());
			}

			for (Map.Entry<String, String> entry :
					_builder._parameters.entrySet()) {

				httpInvoker.parameter(entry.getKey(), entry.getValue());
			}

			httpInvoker.httpMethod(HttpInvoker.HttpMethod.GET);

			httpInvoker.path(
				_builder._scheme + "://" + _builder._host + ":" +
					_builder._port +
						"/o/claims-reports-service/v1.0/agency/pl/claims/reports/{agencyId}/{claimType}/{dateRange}",
				agencyId, claimType, dateRange);

			httpInvoker.userNameAndPassword(
				_builder._login + ":" + _builder._password);

			return httpInvoker.invoke();
		}

		private ClaimsReportsServiceResourceImpl(Builder builder) {
			_builder = builder;
		}

		private static final Logger _logger = Logger.getLogger(
			ClaimsReportsServiceResource.class.getName());

		private Builder _builder;

	}

}