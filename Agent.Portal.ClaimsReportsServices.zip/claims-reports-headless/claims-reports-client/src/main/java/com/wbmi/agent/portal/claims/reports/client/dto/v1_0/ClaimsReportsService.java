package com.wbmi.agent.portal.claims.reports.client.dto.v1_0;

import com.wbmi.agent.portal.claims.reports.client.function.UnsafeSupplier;
import com.wbmi.agent.portal.claims.reports.client.serdes.v1_0.ClaimsReportsServiceSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsReportsService implements Cloneable, Serializable {

	public static ClaimsReportsService toDTO(String json) {
		return ClaimsReportsServiceSerDes.toDTO(json);
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public void setService(
		UnsafeSupplier<String, Exception> serviceUnsafeSupplier) {

		try {
			service = serviceUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String service;

	@Override
	public ClaimsReportsService clone() throws CloneNotSupportedException {
		return (ClaimsReportsService)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ClaimsReportsService)) {
			return false;
		}

		ClaimsReportsService claimsReportsService =
			(ClaimsReportsService)object;

		return Objects.equals(toString(), claimsReportsService.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ClaimsReportsServiceSerDes.toJSON(this);
	}

}