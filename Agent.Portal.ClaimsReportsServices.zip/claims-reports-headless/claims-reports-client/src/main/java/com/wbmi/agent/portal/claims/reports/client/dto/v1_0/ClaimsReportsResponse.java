package com.wbmi.agent.portal.claims.reports.client.dto.v1_0;

import com.wbmi.agent.portal.claims.reports.client.function.UnsafeSupplier;
import com.wbmi.agent.portal.claims.reports.client.serdes.v1_0.ClaimsReportsResponseSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsReportsResponse implements Cloneable, Serializable {

	public static ClaimsReportsResponse toDTO(String json) {
		return ClaimsReportsResponseSerDes.toDTO(json);
	}

	public ClaimsReportRecord[] getClaimsReportRecords() {
		return claimsReportRecords;
	}

	public void setClaimsReportRecords(
		ClaimsReportRecord[] claimsReportRecords) {

		this.claimsReportRecords = claimsReportRecords;
	}

	public void setClaimsReportRecords(
		UnsafeSupplier<ClaimsReportRecord[], Exception>
			claimsReportRecordsUnsafeSupplier) {

		try {
			claimsReportRecords = claimsReportRecordsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected ClaimsReportRecord[] claimsReportRecords;

	public String getFilterCriteria() {
		return filterCriteria;
	}

	public void setFilterCriteria(String filterCriteria) {
		this.filterCriteria = filterCriteria;
	}

	public void setFilterCriteria(
		UnsafeSupplier<String, Exception> filterCriteriaUnsafeSupplier) {

		try {
			filterCriteria = filterCriteriaUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String filterCriteria;

	@Override
	public ClaimsReportsResponse clone() throws CloneNotSupportedException {
		return (ClaimsReportsResponse)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ClaimsReportsResponse)) {
			return false;
		}

		ClaimsReportsResponse claimsReportsResponse =
			(ClaimsReportsResponse)object;

		return Objects.equals(toString(), claimsReportsResponse.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ClaimsReportsResponseSerDes.toJSON(this);
	}

}