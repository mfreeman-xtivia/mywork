package com.wbmi.agent.portal.claims.reports.client.serdes.v1_0;

import com.wbmi.agent.portal.claims.reports.client.dto.v1_0.ClaimsReportRecord;
import com.wbmi.agent.portal.claims.reports.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsReportRecordSerDes {

	public static ClaimsReportRecord toDTO(String json) {
		ClaimsReportRecordJSONParser claimsReportRecordJSONParser =
			new ClaimsReportRecordJSONParser();

		return claimsReportRecordJSONParser.parseToDTO(json);
	}

	public static ClaimsReportRecord[] toDTOs(String json) {
		ClaimsReportRecordJSONParser claimsReportRecordJSONParser =
			new ClaimsReportRecordJSONParser();

		return claimsReportRecordJSONParser.parseToDTOs(json);
	}

	public static String toJSON(ClaimsReportRecord claimsReportRecord) {
		if (claimsReportRecord == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (claimsReportRecord.getAgencyId() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"agencyId\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getAgencyId()));

			sb.append("\"");
		}

		if (claimsReportRecord.getCauseOfLoss() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"causeOfLoss\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getCauseOfLoss()));

			sb.append("\"");
		}

		if (claimsReportRecord.getCheckNumber() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"checkNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getCheckNumber()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClaimKey() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimKey\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClaimKey()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClaimNumber() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClaimNumber()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClaimOccurrenceNumber() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimOccurrenceNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClaimOccurrenceNumber()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClaimOccurrenceType() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimOccurrenceType\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClaimOccurrenceType()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClaimantName() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimantName\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClaimantName()));

			sb.append("\"");
		}

		if (claimsReportRecord.getClosedDate() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"closedDate\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getClosedDate()));

			sb.append("\"");
		}

		if (claimsReportRecord.getDateOfLoss() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateOfLoss\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getDateOfLoss()));

			sb.append("\"");
		}

		if (claimsReportRecord.getDateReported() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateReported\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getDateReported()));

			sb.append("\"");
		}

		if (claimsReportRecord.getFinancialTypeCode() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"financialTypeCode\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getFinancialTypeCode()));

			sb.append("\"");
		}

		if (claimsReportRecord.getLossDescription() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lossDescription\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getLossDescription()));

			sb.append("\"");
		}

		if (claimsReportRecord.getPayToTheOrderOf() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"payToTheOrderOf\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getPayToTheOrderOf()));

			sb.append("\"");
		}

		if (claimsReportRecord.getPaymentIssuedDate() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"paymentIssuedDate\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getPaymentIssuedDate()));

			sb.append("\"");
		}

		if (claimsReportRecord.getPolicyHolder() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"policyHolder\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getPolicyHolder()));

			sb.append("\"");
		}

		if (claimsReportRecord.getPolicyNumber() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"policyNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getPolicyNumber()));

			sb.append("\"");
		}

		if (claimsReportRecord.getStatus() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getStatus()));

			sb.append("\"");
		}

		if (claimsReportRecord.getTotalIncurred() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"totalIncurred\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getTotalIncurred()));

			sb.append("\"");
		}

		if (claimsReportRecord.getTotalPaymentAmount() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"totalPaymentAmount\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportRecord.getTotalPaymentAmount()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		ClaimsReportRecordJSONParser claimsReportRecordJSONParser =
			new ClaimsReportRecordJSONParser();

		return claimsReportRecordJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(
		ClaimsReportRecord claimsReportRecord) {

		if (claimsReportRecord == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (claimsReportRecord.getAgencyId() == null) {
			map.put("agencyId", null);
		}
		else {
			map.put(
				"agencyId", String.valueOf(claimsReportRecord.getAgencyId()));
		}

		if (claimsReportRecord.getCauseOfLoss() == null) {
			map.put("causeOfLoss", null);
		}
		else {
			map.put(
				"causeOfLoss",
				String.valueOf(claimsReportRecord.getCauseOfLoss()));
		}

		if (claimsReportRecord.getCheckNumber() == null) {
			map.put("checkNumber", null);
		}
		else {
			map.put(
				"checkNumber",
				String.valueOf(claimsReportRecord.getCheckNumber()));
		}

		if (claimsReportRecord.getClaimKey() == null) {
			map.put("claimKey", null);
		}
		else {
			map.put(
				"claimKey", String.valueOf(claimsReportRecord.getClaimKey()));
		}

		if (claimsReportRecord.getClaimNumber() == null) {
			map.put("claimNumber", null);
		}
		else {
			map.put(
				"claimNumber",
				String.valueOf(claimsReportRecord.getClaimNumber()));
		}

		if (claimsReportRecord.getClaimOccurrenceNumber() == null) {
			map.put("claimOccurrenceNumber", null);
		}
		else {
			map.put(
				"claimOccurrenceNumber",
				String.valueOf(claimsReportRecord.getClaimOccurrenceNumber()));
		}

		if (claimsReportRecord.getClaimOccurrenceType() == null) {
			map.put("claimOccurrenceType", null);
		}
		else {
			map.put(
				"claimOccurrenceType",
				String.valueOf(claimsReportRecord.getClaimOccurrenceType()));
		}

		if (claimsReportRecord.getClaimantName() == null) {
			map.put("claimantName", null);
		}
		else {
			map.put(
				"claimantName",
				String.valueOf(claimsReportRecord.getClaimantName()));
		}

		if (claimsReportRecord.getClosedDate() == null) {
			map.put("closedDate", null);
		}
		else {
			map.put(
				"closedDate",
				String.valueOf(claimsReportRecord.getClosedDate()));
		}

		if (claimsReportRecord.getDateOfLoss() == null) {
			map.put("dateOfLoss", null);
		}
		else {
			map.put(
				"dateOfLoss",
				String.valueOf(claimsReportRecord.getDateOfLoss()));
		}

		if (claimsReportRecord.getDateReported() == null) {
			map.put("dateReported", null);
		}
		else {
			map.put(
				"dateReported",
				String.valueOf(claimsReportRecord.getDateReported()));
		}

		if (claimsReportRecord.getFinancialTypeCode() == null) {
			map.put("financialTypeCode", null);
		}
		else {
			map.put(
				"financialTypeCode",
				String.valueOf(claimsReportRecord.getFinancialTypeCode()));
		}

		if (claimsReportRecord.getLossDescription() == null) {
			map.put("lossDescription", null);
		}
		else {
			map.put(
				"lossDescription",
				String.valueOf(claimsReportRecord.getLossDescription()));
		}

		if (claimsReportRecord.getPayToTheOrderOf() == null) {
			map.put("payToTheOrderOf", null);
		}
		else {
			map.put(
				"payToTheOrderOf",
				String.valueOf(claimsReportRecord.getPayToTheOrderOf()));
		}

		if (claimsReportRecord.getPaymentIssuedDate() == null) {
			map.put("paymentIssuedDate", null);
		}
		else {
			map.put(
				"paymentIssuedDate",
				String.valueOf(claimsReportRecord.getPaymentIssuedDate()));
		}

		if (claimsReportRecord.getPolicyHolder() == null) {
			map.put("policyHolder", null);
		}
		else {
			map.put(
				"policyHolder",
				String.valueOf(claimsReportRecord.getPolicyHolder()));
		}

		if (claimsReportRecord.getPolicyNumber() == null) {
			map.put("policyNumber", null);
		}
		else {
			map.put(
				"policyNumber",
				String.valueOf(claimsReportRecord.getPolicyNumber()));
		}

		if (claimsReportRecord.getStatus() == null) {
			map.put("status", null);
		}
		else {
			map.put("status", String.valueOf(claimsReportRecord.getStatus()));
		}

		if (claimsReportRecord.getTotalIncurred() == null) {
			map.put("totalIncurred", null);
		}
		else {
			map.put(
				"totalIncurred",
				String.valueOf(claimsReportRecord.getTotalIncurred()));
		}

		if (claimsReportRecord.getTotalPaymentAmount() == null) {
			map.put("totalPaymentAmount", null);
		}
		else {
			map.put(
				"totalPaymentAmount",
				String.valueOf(claimsReportRecord.getTotalPaymentAmount()));
		}

		return map;
	}

	public static class ClaimsReportRecordJSONParser
		extends BaseJSONParser<ClaimsReportRecord> {

		@Override
		protected ClaimsReportRecord createDTO() {
			return new ClaimsReportRecord();
		}

		@Override
		protected ClaimsReportRecord[] createDTOArray(int size) {
			return new ClaimsReportRecord[size];
		}

		@Override
		protected void setField(
			ClaimsReportRecord claimsReportRecord, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "agencyId")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setAgencyId(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "causeOfLoss")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setCauseOfLoss(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "checkNumber")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setCheckNumber(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "claimKey")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClaimKey(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "claimNumber")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClaimNumber(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(
						jsonParserFieldName, "claimOccurrenceNumber")) {

				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClaimOccurrenceNumber(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(
						jsonParserFieldName, "claimOccurrenceType")) {

				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClaimOccurrenceType(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "claimantName")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClaimantName(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "closedDate")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setClosedDate(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "dateOfLoss")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setDateOfLoss(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "dateReported")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setDateReported(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "financialTypeCode")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setFinancialTypeCode(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "lossDescription")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setLossDescription(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "payToTheOrderOf")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setPayToTheOrderOf(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "paymentIssuedDate")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setPaymentIssuedDate(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "policyHolder")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setPolicyHolder(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "policyNumber")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setPolicyNumber(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "status")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setStatus((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "totalIncurred")) {
				if (jsonParserFieldValue != null) {
					claimsReportRecord.setTotalIncurred(
						(String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(
						jsonParserFieldName, "totalPaymentAmount")) {

				if (jsonParserFieldValue != null) {
					claimsReportRecord.setTotalPaymentAmount(
						(String)jsonParserFieldValue);
				}
			}
			else if (jsonParserFieldName.equals("status")) {
				throw new IllegalArgumentException();
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\":");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(",");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}