package com.wbmi.agent.portal.claims.reports.internal.resource.v1_0;

import com.wbmi.agent.portal.cache.servlet.filter.AgentPortalCacheFilter;
import com.wbmi.agent.portal.claims.reports.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.reports.resource.v1_0.ClaimsReportsServiceResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wbmi.agent.portal.claims.reports.service.ClaimsReportsService;

/**
 * @author WBMI
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/claims-reports-service.properties",
	scope = ServiceScope.PROTOTYPE, service = ClaimsReportsServiceResource.class
)
public class ClaimsReportsServiceResourceImpl
	extends BaseClaimsReportsServiceResourceImpl {

	@Override
	public ClaimsReportsResponse getAgencyPlClaimReport(String agencyId,
														String claimType,
														String dateRange) throws Exception {

		logger.debug("StartClaimsReportsResourceImpl.getPlClaimReport()");
		ClaimsReportsResponse claimsReportsResp = claimsReportsService.
				getAgencyClaimsReports(agencyId,claimType, dateRange, contextCompany);
		//cacheFilter.processFilter(contextHttpServletRequest, contextHttpServletResponse);
		return claimsReportsResp;
	}

	@Reference
	private ClaimsReportsService claimsReportsService;

	@Reference
	private AgentPortalCacheFilter cacheFilter;

	private static final Logger logger = LoggerFactory.getLogger(ClaimsReportsServiceResourceImpl.class);
}