package com.wbmi.agent.portal.claims.reports.internal.auth;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.security.auth.AccessControlContext;
import com.liferay.portal.kernel.security.auth.AuthException;
import com.liferay.portal.kernel.security.auth.verifier.AuthVerifier;
import com.liferay.portal.kernel.security.auth.verifier.AuthVerifierResult;
import com.liferay.portal.kernel.security.auth.verifier.AuthVerifierResult.State;
import com.liferay.portal.kernel.util.PortalUtil;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.util.Properties;

@Component(immediate = true,
		property = { "auth.verifier.ClaimsReportsAuthVerifier.urls.includes=/o/claims-reports-service/*" })
public class ClaimsReportsAuthVerifier implements AuthVerifier {

	@Override
	public String getAuthType() {
		return HttpServletRequest.FORM_AUTH;
	}

	@Override
	public AuthVerifierResult verify(AccessControlContext accessControlContext, Properties properties)
			throws AuthException {
		AuthVerifierResult avr = new AuthVerifierResult();
		long userid = 0;
		try {
			User user = PortalUtil.getUser(accessControlContext.getRequest());
			userid = user.getUserId();
			avr.setUserId(userid);
			avr.setPasswordBasedAuthentication(true);
			avr.setState(State.SUCCESS);
		} catch (PortalException e) {
			logger.error(e.getMessage(), e);
		}
		return avr;
	}

	private static final Logger logger = LoggerFactory.getLogger(ClaimsReportsAuthVerifier.class);

}
