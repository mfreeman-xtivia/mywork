package com.wbmi.agent.portal.claims.reports.service.model;

public class AgencyClaimsReportsResponse {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//result = prime * result + ((personalLinesRollouts == null) ? 0 : personalLinesRollouts.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgencyClaimsReportsResponse other = (AgencyClaimsReportsResponse) obj;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("]");
		return builder.toString();
	}

}
