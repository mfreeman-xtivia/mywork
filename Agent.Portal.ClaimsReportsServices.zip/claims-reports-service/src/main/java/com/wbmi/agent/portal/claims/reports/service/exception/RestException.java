package com.wbmi.agent.portal.claims.reports.service.exception;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

public class RestException extends WebApplicationException {
	private static final long serialVersionUID = 1L;

	private final Response.Status status;

	public RestException() {
		super();
		status = Response.Status.INTERNAL_SERVER_ERROR;
	}

	public RestException(String msg) {
		super(msg);
		status = Response.Status.INTERNAL_SERVER_ERROR;
	}

	public RestException(String msg, Exception e) {
		super(msg, e);
		status = Response.Status.INTERNAL_SERVER_ERROR;
	}

	public RestException(String msg, Exception e, Response.Status status) {
		super(msg, e);
		this.status = status;
	}

	public RestException(String msg, Response.Status status) {
		super(msg);
		this.status = status;
	}

	@Override
	public Response getResponse() {
		final JSONObject json = JSONFactoryUtil.createJSONObject();
		json.put("message", super.getMessage());

		return Response.status(getStatus()).entity(json.toString()).build();
	}

	public Response.Status getStatus() {
		return status;
	}

}
