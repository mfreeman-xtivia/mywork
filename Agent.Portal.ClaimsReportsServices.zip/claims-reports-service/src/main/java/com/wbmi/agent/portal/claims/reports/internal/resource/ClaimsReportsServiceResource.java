package com.wbmi.agent.portal.claims.reports.internal.resource;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONDeserializer;
import com.liferay.portal.kernel.json.JSONFactory;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.util.StringUtil;
import com.wbmi.agent.portal.apim.executor.WebServiceExecutor;
import com.wbmi.agent.portal.claims.reports.dto.v1_0.ClaimsReportRecord;
import com.wbmi.agent.portal.claims.reports.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.reports.internal.constants.ClaimsReportsConstants;
import com.wbmi.agent.portal.common.service.model.WebServiceMethod;
import com.wbmi.agent.portal.configuration.util.AzureAPIMConfigurationUtil;
import com.wbmi.agent.portal.configuration.util.MockServiceConfigurationUtil;
import com.wbmi.agent.portal.exception.WebServiceException;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component(immediate = true, service = ClaimsReportsServiceResource.class)
public class ClaimsReportsServiceResource {

	public ClaimsReportsResponse getAgencyClaimsReports(String agencyId,
														String claimType,
														String dateRange,
														Company company)
			                                            throws PortalException {
		logger.debug("ClaimsReportsServiceResource.getAgencyClaimsReports()");
		boolean isMockingEnabled = MockServiceConfigurationUtil.claimsReportsMockingEnabled();
		if (isMockingEnabled) {
			return createMockResponse(agencyId, claimType);
		}
		return getAgencyClaimsReports(agencyId,claimType,dateRange, company.getCompanyId());
	}

	private ClaimsReportsResponse getAgencyClaimsReports(String agencyId,
			                                            String claimType,
			                                            String dateRange,
			                                            long companyId)
														throws PortalException {
		
		logger.debug("ClaimsReportsServiceResource.getAgencyClaimsReports()");

		String apiKey = AzureAPIMConfigurationUtil.claimsReportsApiKey();
		String jsonBody = buildJsonBody(agencyId,dateRange);
		String url,response="";

		switch (claimType) {
			case ClaimsReportsConstants.NEW_CLAIMS:
			    url = WebServiceMethod.CLAIMS_NEW.getUrl();
			    logger.debug("Claims API URL to be used="+url);
			    response = _webServiceExecutor.executePost(companyId, WebServiceMethod.CLAIMS_NEW,
						                                   apiKey, url, jsonBody);
			    break;

			case ClaimsReportsConstants.CLOSED_CLAIMS:
				url = WebServiceMethod.CLAIMS_CLOSED.getUrl();
				logger.debug("Claims API URL to be used="+url);
				response = _webServiceExecutor.executePost(companyId, WebServiceMethod.CLAIMS_CLOSED,
						                                   apiKey, url, jsonBody);
				break;

			case ClaimsReportsConstants.CLAIM_PAYMENTS:
				url = WebServiceMethod.CLAIMS_PAYMENTS.getUrl();
				logger.debug("Claims API URL to be used="+url);
				response = _webServiceExecutor.executePost(companyId, WebServiceMethod.CLAIMS_PAYMENTS,
						                                   apiKey, url, jsonBody);
				break;
		}

		logger.info("getAgencyClaimsReports() response {}", response);

		return convert(agencyId,response);

	}

	private String buildJsonBody(String agencyId, String dateRange) {

		Calendar calendar = Calendar.getInstance();

		switch (dateRange) {
			case ClaimsReportsConstants.LAST7DAYS:
				calendar.add(Calendar.DATE, -7);
				break;

			case ClaimsReportsConstants.LAST2WEEKS:
				calendar.add(Calendar.DATE, -14);
				break;

			case ClaimsReportsConstants.LASTMONTH:
				calendar.add(Calendar.MONTH, -1);
				break;

			default: throw new IllegalArgumentException("Unsupported date range qualifier="+dateRange);
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date from = new Date(calendar.getTimeInMillis());
		Date to = new Date();

		String postedJson = String.format("{\"AgencyCode\": \"%s\", \"StartDate\": \"%s\", \"EndDate\": \"%s\"}",
				                          agencyId,sdf.format(from),sdf.format(to));

		logger.info("JSON to be posted to Claims API="+postedJson);

		return postedJson;
	}

	private ClaimsReportsResponse convert(String agencyId, String response)  {

		//logger.info("getAgencyClaimsReports() input JSON={}", response);

		String _response = String.format("%s%s%s",JSON_PREFIX,response,JSON_SUFFIX);

		for (Map.Entry<String,String> entry : CLAIMS_FIELD_NAME_MAP.entrySet()) {
			_response = _response.replaceAll(entry.getKey(),entry.getValue());
		}

		JSONDeserializer<ClaimsReportsResponse> jsonDeserializer = _jsonFactory.createJSONDeserializer();
		ClaimsReportsResponse crr = jsonDeserializer.deserialize(_response, ClaimsReportsResponse.class);
		postProcessRecords(agencyId,crr);
		return crr;
	}

	private void postProcessRecords(String agencyId, ClaimsReportsResponse crr) {
		for (ClaimsReportRecord record: crr.getClaimsReportRecords()) {
			record.setAgencyId(agencyId);
			record.setDateOfLoss(ISOTimestampToClientDateString(record.getDateOfLoss()));
			record.setClosedDate(ISOTimestampToClientDateString(record.getClosedDate()));
			record.setDateReported(ISOTimestampToClientDateString(record.getDateReported()));
			record.setPaymentIssuedDate(ISOTimestampToClientDateString(record.getPaymentIssuedDate()));
			String status = record.getStatus();
			if (status != null) {
				String mappedStatus = STATUS_CODE_MAP.get(status);
				if (mappedStatus != null) {
					record.setStatus(mappedStatus);
				}
			}
		}
	}

	public String ISOTimestampToClientDateString(String iso) {
		if (iso == null) return null;
		try {
			Date dt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(iso);
			return new SimpleDateFormat("MM/dd/yyyy").format(dt);
		} catch (ParseException pe) {
			logger.error("Error parsing date returned by claims report", pe);
			return iso;
		}
	}

	private ClaimsReportsResponse createMockResponse(String agencyId, String claimType) throws WebServiceException {

		logger.debug("ClaimsReportsResource.createMockResponse(),claimType="+claimType);

		BundleContext bundleContext = FrameworkUtil.getBundle(this.getClass()).getBundleContext();
		Bundle bundle = bundleContext.getBundle();
		URL mockJsonFileUrl =
		    bundle.getResource(ClaimsReportsConstants.CLAIMS_REPORTS_RESPONSE_JSON_FILE + "_" + claimType + ".json");
		logger.debug("Mock URL="+mockJsonFileUrl);
		try (InputStream inputStream = mockJsonFileUrl.openStream()) {
			String mockResponse = StringUtil.read(inputStream);
			return convert(agencyId, mockResponse);
		} catch (Exception ioe) {
			ioe.printStackTrace();
			throw new WebServiceException("Could not return default response for mock service", ioe);
		}
	}

	@Activate
	@SuppressWarnings("unused")
	protected void activate(BundleContext bundleContext, Map<String, Object> properties) {
		logger.debug("ClaimsReportsResource.activate()");
	}

	@Reference
	protected WebServiceExecutor _webServiceExecutor;

	@Reference
	private JSONFactory _jsonFactory;

	private static final Logger logger = LoggerFactory.getLogger(ClaimsReportsServiceResource.class);

	private static final Map<String,String> STATUS_CODE_MAP;

	private static final Map<String,String> CLAIMS_FIELD_NAME_MAP;

	static {

		// base claim
		CLAIMS_FIELD_NAME_MAP = new HashMap<>();
		CLAIMS_FIELD_NAME_MAP.put("PolicyNumber","policyNumber");
		CLAIMS_FIELD_NAME_MAP.put("CustomerName","policyHolder");
		CLAIMS_FIELD_NAME_MAP.put("ClaimLossDate","dateOfLoss");
		CLAIMS_FIELD_NAME_MAP.put("LossDescription","lossDescription");
		CLAIMS_FIELD_NAME_MAP.put("ClaimKey","claimKey");
		CLAIMS_FIELD_NAME_MAP.put("ClaimNumber","claimNumber");
		CLAIMS_FIELD_NAME_MAP.put("ClaimOccurrenceNumber","claimOccurrenceNumber");
		CLAIMS_FIELD_NAME_MAP.put("ClaimReportedDate","dateReported");
		CLAIMS_FIELD_NAME_MAP.put("TotalLossIncurred","totalIncurred");
		CLAIMS_FIELD_NAME_MAP.put("ClaimOccurrenceType","claimOccurrenceType");
		CLAIMS_FIELD_NAME_MAP.put("ClaimStatusCode","status");

		// closed claim
		CLAIMS_FIELD_NAME_MAP.put("ClosedDate","closedDate");

		// payment claim
		CLAIMS_FIELD_NAME_MAP.put("PayToTheOrderOfName","payToTheOrderOf");
		CLAIMS_FIELD_NAME_MAP.put("ClaimantName","claimantName");
		CLAIMS_FIELD_NAME_MAP.put("PaymentIssuedDate","paymentIssuedDate");
		CLAIMS_FIELD_NAME_MAP.put("FinancialTypeCode","financialTypeCode");
		CLAIMS_FIELD_NAME_MAP.put("TotalPaymentAmount","totalIncurred");
		CLAIMS_FIELD_NAME_MAP.put("CheckNumber","checkNumber");
		CLAIMS_FIELD_NAME_MAP.put("CauseOfLoss","causeOfLoss");

		STATUS_CODE_MAP = new HashMap<>();
		STATUS_CODE_MAP.put("O","Open");
		STATUS_CODE_MAP.put("C","Closed");
		STATUS_CODE_MAP.put("E","Opened in Error");
		STATUS_CODE_MAP.put("NO","Notice Only");
	}

	public final String JSON_PREFIX="{\"claimsReportRecords\": ";
	public final String JSON_SUFFIX="}";

}
