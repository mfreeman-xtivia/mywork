package com.wbmi.agent.portal.claims.reports.service.impl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Company;
import com.wbmi.agent.portal.claims.reports.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.reports.internal.resource.ClaimsReportsServiceResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, service = com.wbmi.agent.portal.claims.reports.service.ClaimsReportsService.class)
public class ClaimsReportsServiceImpl implements com.wbmi.agent.portal.claims.reports.service.ClaimsReportsService {

	@Override
	public ClaimsReportsResponse getAgencyClaimsReports(String agencyId,
														String claimType,
														String dateRange,
														Company company)
			                                            throws PortalException {
		logger.debug("ClaimsReportsImpl.getAgencyClaimsReports()");
		return agencyClaimsReportsResource.getAgencyClaimsReports(agencyId,claimType, dateRange, company);
	}

	@Reference
	private ClaimsReportsServiceResource agencyClaimsReportsResource;

	private static final Logger logger =
			LoggerFactory.getLogger(com.wbmi.agent.portal.claims.reports.service.impl.ClaimsReportsServiceImpl.class);

}
