package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.AgencySyncConfigService;

public class AgencySyncConfigUtil {
	
	public static AgencySyncConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String cronExpression() {
		return getService().cronExpression();
	}
	
	public static Boolean isSchedulerActive() {
		return getService().isSchedulerActive();
	}
	
	public static Boolean isStartUpSyncActive() {
		return getService().isStartUpSyncActive();
	}
	
	public static Integer maxRecursionForSorting() {
		return getService().maxRecursionForSorting();
	}

	private static ServiceTracker<AgencySyncConfigService, AgencySyncConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(AgencySyncConfigUtil.class) , AgencySyncConfigService.class);
}
