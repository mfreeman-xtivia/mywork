package com.wbmi.agent.portal.configuration.model;

public enum ErrorMessageCategoryEnum {
	
	BILLING_ERROR("billingError"),
	CLAIMS_REPORT_ERROR("claimsReportError"),
	GENERAL_TECH_ERROR("generalTechnicalError"),
	RSM_ERROR("rsmError"),
	UW_ERROR("uwError");
	
	private ErrorMessageCategoryEnum(String category) {
		this.category=category;
	}
	
	private String category;
	
	public String getCategory() {
		return category;
	}

}
