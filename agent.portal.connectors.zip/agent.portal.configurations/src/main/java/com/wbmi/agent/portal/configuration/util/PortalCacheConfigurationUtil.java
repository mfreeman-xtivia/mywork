package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.PortalCacheService;

public class PortalCacheConfigurationUtil {
	
	public static PortalCacheService getService() {
		return _serviceTracker.getService();
	}
	
	public static Boolean isBrowserCacheEnabled() {
		return getService().isBrowserCacheEnabled();
	}
	
	public static Boolean isPortalCacheEnabled() {
		return getService().isPortalCacheEnabled();
	}
	
	public static String[] byPassUrlPatterns() {
		return getService().byPassUrlPatterns();
	}
	
	public static String[] cacheHeaders() {
		return getService().cacheHeaders();
	}
	
	private static ServiceTracker<PortalCacheService, PortalCacheService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(PortalCacheService.class) , PortalCacheService.class);

}
