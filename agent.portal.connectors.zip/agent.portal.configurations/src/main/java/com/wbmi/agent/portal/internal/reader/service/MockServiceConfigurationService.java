package com.wbmi.agent.portal.internal.reader.service;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.mock.service.MockServiceConfiguration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(configurationPid = "com.wbmi.agent.portal.internal.configuration.mock.service.MockServiceConfiguration", immediate = true, service = MockServiceConfigurationService.class)
public class MockServiceConfigurationService {

	public String mockAgencyCode() {
		return _mockServiceConfiguration.mockAgencyCode();
	}
	
	public String mockAgencyName() {
		return _mockServiceConfiguration.mockAgencyName();
	}

	public Boolean mockAgencyCodeEnabled() {
		return _mockServiceConfiguration.mockAgencyCodeEnabled();
	}

	public Boolean customerDetailsMockingEnabled() {
		return _mockServiceConfiguration.customerDetailsMockingEnabled();
	}

	public Boolean courseListMockingEnabled() {
		return _mockServiceConfiguration.courseListMockingEnabled();
	}

	public Boolean registerCoursesMockingEnabled() {
		return _mockServiceConfiguration.registerCoursesMockingEnabled();
	}

	public Boolean isDocumentServiceMockingEnabled() {
		return _mockServiceConfiguration.documentServiceMockingEnabled();
	}

	public Boolean listCategoryServiceMockingEnabled() {
		return _mockServiceConfiguration.listCategoryServiceMockingEnabled();
	}

	public Boolean agencyContactsMockingEnabled() {
		return _mockServiceConfiguration.agencyContactsMockingEnabled();
	}

	public Boolean generalInfoContactsMockingEnabled() {
		return _mockServiceConfiguration.generalInfoContactsMockingEnabled();
	}

	public Boolean recentCancellationsMockingEnabled() {
		return _mockServiceConfiguration.recentCancellationsMockingEnabled();
	}

	public Boolean renewalsPastDueMockingEnabled() {
		return _mockServiceConfiguration.renewalsPastDueMockingEnabled();
	}

	public Boolean accountsPastDueMockingEnabled() {
		return _mockServiceConfiguration.accountsPastDueMockingEnabled();
	}

	public Boolean startQuoteMockingEnabled() {
		return _mockServiceConfiguration.startQuoteMockingEnabled();
	}
	
	public Boolean agencyDetailsMockingEnabled() {
		return _mockServiceConfiguration.agencyDetailsMockingEnabled();
	}
	
	public Boolean agencyMockingEnabled() {
		return _mockServiceConfiguration.agencyMockingEnabled();
	}
	
	public Boolean getMonitoringServiceMockingEnabled() {
		return _mockServiceConfiguration.getMonitoringServiceMockingEnabled();
	}
	
	public Boolean generateBadStatusServiceMockResponse() {
		return _mockServiceConfiguration.generateBadStatusServiceMockResponse();
	}
	
	public Boolean addMonitoringServiceMockingEnabled() {
		return _mockServiceConfiguration.addMonitoringServiceMockingEnabled();
	}
	
	public Boolean updateMonitoringServiceMockingEnabled() {
		return _mockServiceConfiguration.updateMonitoringServiceMockingEnabled();
	}
	
	public Boolean deleteMonitoringServiceMockingEnabled() {
		return _mockServiceConfiguration.deleteMonitoringServiceMockingEnabled();
	}
	
	public Boolean allServiceMonitoringStatusMockingEnabled() {
		return _mockServiceConfiguration.allServiceMonitoringStatusMockingEnabled();
	}
	
	public Boolean notificationServiceMockingEnabled() {
		return _mockServiceConfiguration.notificationServiceMockingEnabled();
	}


	public Boolean claimsReportsMockingEnabled() {
		return _mockServiceConfiguration.claimsReportsMockingEnabled();
	}

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("MockServiceConfigurationService activating");
		_mockServiceConfiguration = ConfigurableUtil.createConfigurable(MockServiceConfiguration.class, properties);
	}

	private MockServiceConfiguration _mockServiceConfiguration;

	private static final Logger _logUtil = LoggerFactory.getLogger(MockServiceConfigurationService.class);

}
