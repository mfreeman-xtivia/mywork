package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.connectivity.PortalFacadeServiceConfiguration;

@Component(
	configurationPid = "com.wbmi.agent.portal.internal.configuration.connectivity.PortalFacadeServiceConfiguration",
	immediate = true, service = PortalFacadeConfigService.class
)
public class PortalFacadeConfigService {
	
	public String getWbmiApiKey() {
		return _portalFacadeServiceConfig.wbmiApiKey();
	}

	public String getWbmiBaseURL() {
		return _portalFacadeServiceConfig.wbmiBaseURL();
	}

	public String getWbmiAzureApiSubscriptionKey() {
		return _portalFacadeServiceConfig.wbmiAzureApiSubscriptionKey();
	}

	public String getWbmiAzureApiBaseURL() {
		return _portalFacadeServiceConfig.wbmiAzureApiBaseURL();
	}
	
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("PortalFacadeConfigService activating");
		_portalFacadeServiceConfig = ConfigurableUtil.createConfigurable(PortalFacadeServiceConfiguration.class, properties);
	}
	
	private PortalFacadeServiceConfiguration _portalFacadeServiceConfig;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(PortalFacadeConfigService.class);

}
