package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.PortalFacadeConfigService;

public class PortalFacadeConfigurationUtil {
	
	public static PortalFacadeConfigService getService() {
		return _serviceTracker.getService();
	}

	public static String getWbmiApiKey() {
		return getService().getWbmiApiKey();
	}

	public static String getWbmiBaseURL() {
		return getService().getWbmiBaseURL();
	}

	public static String getWbmiAzureApiSubscriptionKey() {
		return getService().getWbmiAzureApiSubscriptionKey();
	}

	public static String getWbmiAzureApiBaseURL() {
		return getService().getWbmiAzureApiBaseURL();
	}
	
	private static ServiceTracker<PortalFacadeConfigService, PortalFacadeConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(PortalFacadeConfigurationUtil.class) , PortalFacadeConfigService.class);

}
