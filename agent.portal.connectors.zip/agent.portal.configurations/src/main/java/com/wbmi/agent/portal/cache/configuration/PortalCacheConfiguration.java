package com.wbmi.agent.portal.cache.configuration;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(id = "com.wbmi.agent.portal.cache.configuration.PortalCacheConfiguration", 
			localization = "content/Language", name = "portal-cache-config")
public interface PortalCacheConfiguration {
	
	@Meta.AD(deflt = "true", description = "Portal Cache is Enabled",name = "is-portal-cache-enabled", required = false)
	public Boolean isPortalCacheEnabled();
	
	@Meta.AD(deflt = "false", description = "Enable HTTP Browser Caching",name = "is-browser-cache-enabled", required = false)
	public Boolean isBrowserCacheEnabled();
	
	@Meta.AD(description = "", name = "cache-headers", required = false)
	public String[] cacheHeaders();
	
	@Meta.AD(description = "These urls will not be cached in http browser cache", name = "by-pass-url-patterns", required = false)
	public String[] byPassUrlPatterns();
}
