package com.wbmi.agent.portal.internal.configuration.connectivity;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(id = "com.wbmi.agent.portal.internal.configuration.connectivity.AzureAPIMConfiguration", 
			localization = "content/Language", name = "apim-web-service")
public interface AzureAPIMConfiguration {

	@Meta.AD(deflt = "https://qa-api.wbmi.com", description = "Base URL for requests to Azure APIM", name = "apim-base-url", required = false)
	public String apimBaseURL();
	
	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Continuing Education Service.", name = "continuing-education-api-key", required = false)
	public String continuingEducationApiKey();

	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Billing Status Service.", name = "billing-status-api-key", required = false)
	public String billingStatusApiKey();
	
	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Agency Contacts APIM Key.", name = "agency-contacts-api-key", required = false)
	public String agencyContactsApiKey();

	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Customer Details APIM Key.", name = "customer-details-api-key", required = false)
	public String customerDetailsKey();
	
	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Start Quote APIM Key.", name = "agency-start-quote-api-key", required = false)
	public String agencyStartQuoteApiKey();
	
	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Agency Service APIM Key.", name = "agency-service-api-key", required = false)
	public String agencyServiceApiKey();
	
	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Monitoring Services.", name = "Monitoring Services API Key", required = false)
	public String monitoringServiceApiKey();

	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Claims Reports Services.", name = "Monitoring Services API Key", required = false)
	public String claimsReportsApiKey();
}
