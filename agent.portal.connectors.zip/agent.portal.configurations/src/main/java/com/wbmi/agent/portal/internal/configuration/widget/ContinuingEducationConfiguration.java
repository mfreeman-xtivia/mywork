package com.wbmi.agent.portal.internal.configuration.widget;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
	id = "com.wbmi.agent.portal.internal.configuration.widget.ContinuingEducationConfiguration",
	localization = "content/Language", name = "continuing-education-config")
public interface ContinuingEducationConfiguration {

	@Meta.AD(deflt = "SilverLiningNonProd@wbmi.com", 
			description = "Email Address of Marketing Team", name = "marketing-email-address", required = false)
	public String marketingEmailAddress();
	
	@Meta.AD(deflt = "Continuing Education", 
			description = "Documents and Media Folder Name", name = "continuing-education-folder-name", required = false)
	public String folderName();
	
	@Meta.AD(deflt = "WBUIRegistration.pdf", 
			description = "Documents and Media File Name", name = "continuing-education-file-name", required = false)
	public String fileName();
	
	@Meta.AD(deflt = "West Bend University Course Request", 
			description = "Mail to Agent Subject", name = "mail-to-agent-subject", required = false)
	public String mailToAgentSubject();
	
	@Meta.AD(deflt = "Continuing Education", 
			description = "Mail to Marketing Subject", name = "mail-to-marketing-subject", required = false)
	public String mailToMarketingSubject();
	
	@Meta.AD(deflt = "Register for multiple classes", 
			description = "Link Description that shows up in UI", name = "continuing-education-link-description", required = false)
	public String linkDesciption();
	
	
}
