package com.wbmi.agent.portal.cache.scheduler.configuration;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
		id = "com.wbmi.agent.portal.cache.scheduler.configuration.CacheSchedulerConfiguration",
		localization = "content/Language",
		name = "cache.scheduler.configuration"
)
public interface CacheSchedulerConfiguration {
	
	@Meta.AD(deflt = "0 0 8 * * ?", description = "cron-expression-description", name = "cron-expression", required = false)
	public String cronExpression();
	
	@Meta.AD(deflt = "true", description = "Is scheduler Active", required = false)
	public Boolean isSchedulerActive();
	
	@Meta.AD(deflt = "true", description = "Is Startup Active", required = false)
	public Boolean isStartUpActive();
}
