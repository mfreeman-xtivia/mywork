package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.ContinuingEducationConfigService;

public class ContinuingEducationConfigurationUtil {
	
	public static ContinuingEducationConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String marketingEmailAddress() {
		return getService().marketingEmailAddress();
	}
	 
	public static String folderName() {
		return getService().folderName();
	}
	
	public static String fileName() {
		return getService().fileName();
	}
	
	public static String mailToAgentSubject() {
		return getService().mailToAgentSubject();
	}
	
	public static String mailToMarketingSubject() {
		return getService().mailToMarketingSubject();
	}
	
	public static String linkDesciption() {
		return getService().linkDesciption();
	}
	
	private static ServiceTracker<ContinuingEducationConfigService, ContinuingEducationConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(ContinuingEducationConfigurationUtil.class) , ContinuingEducationConfigService.class);

}
