package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.widget.ContinuingEducationConfiguration;

@Component(
		configurationPid = "com.wbmi.agent.portal.internal.configuration.widget.ContinuingEducationConfiguration",
		immediate = true, service = ContinuingEducationConfigService.class
	)
public class ContinuingEducationConfigService {
	
	public String marketingEmailAddress() {
		return _configuration.marketingEmailAddress();
	}
	
	public String folderName() {
		return _configuration.folderName();
	}
	
	public String fileName() {
		return _configuration.fileName();
	}
	
	public String mailToAgentSubject() {
		return _configuration.mailToAgentSubject();
	}
	
	public String mailToMarketingSubject() {
		return _configuration.mailToMarketingSubject();
	}
	
	public String linkDesciption() {
		return _configuration.linkDesciption();
	}
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("ContinuingEducationConfigService activating");
		_configuration = ConfigurableUtil.createConfigurable(ContinuingEducationConfiguration.class, properties);
	}
	
	private ContinuingEducationConfiguration _configuration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(ContinuingEducationConfigService.class);

}
