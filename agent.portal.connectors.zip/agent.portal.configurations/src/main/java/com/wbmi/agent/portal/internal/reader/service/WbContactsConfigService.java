package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.widget.WBContactsConfigurations;

@Component(
		configurationPid = " com.wbmi.agent.portal.internal.configuration.widget.WBContactsConfigurations",
		immediate = true, service = WbContactsConfigService.class
	)
public class WbContactsConfigService {
	
	public String vocabulary() {
		return _contactsConfigurations.vocabulary();
	}
	
	public String categoryName() {
		return _contactsConfigurations.categoryName();
	}
	
	public String westBendPhone() {
		return _contactsConfigurations.westBendPhone();
	}
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("WbContactsConfigService activating");
		_contactsConfigurations = ConfigurableUtil.createConfigurable(WBContactsConfigurations.class, properties);
	}
	
	private WBContactsConfigurations  _contactsConfigurations;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(WbContactsConfigService.class);

}
