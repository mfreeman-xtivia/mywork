package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.cache.scheduler.configuration.CacheSchedulerConfiguration;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
		configurationPid = "com.wbmi.agent.portal.cache.scheduler.configuration.CacheSchedulerConfiguration",
		immediate = true, service = CacheSchedulerConfigService.class
	)
public class CacheSchedulerConfigService {

	public String cronExpression() {
		return _configuration.cronExpression();
	}
	
	public Boolean isSchedulerActive() {
		return _configuration.isSchedulerActive();
	}
	
	public Boolean isStartUpActive() {
		return _configuration.isStartUpActive();
	}
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("CacheSchedulerConfigService activating");
		_configuration = ConfigurableUtil.createConfigurable(CacheSchedulerConfiguration.class, properties);
	}
	
	private CacheSchedulerConfiguration _configuration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(CacheSchedulerConfigService.class);

}
