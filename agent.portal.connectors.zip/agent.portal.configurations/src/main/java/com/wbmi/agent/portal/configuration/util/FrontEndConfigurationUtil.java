package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.FrontEndConfigService;

public class FrontEndConfigurationUtil {
	
	public static FrontEndConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String wbConnectDomain() {
		return getService().wbConnectDomain();
	}

	public static String serviceTimeOut() {
		return getService().serviceTimeOut();
	}
	
	public static String dcdmAgencyUpdateLink() {
		return getService().dcdmAgencyUpdateLink();
	}
	
	public static String dataTablePageSizes() {
		return getService().dataTablePageSizes();
	}

	public static String billingErrorMessage() {
		return getService().billingErrorMessage();
	}

	public static String claimsReportsErrorMessage() {
		return getService().claimsReportsErrorMessage();
	}
	
	public static String generalTechnicalError() {
		return getService().generalTechnicalError();
	}
	
	public static String rsmError() {
		return getService().rsmError();
	}
	
	public static String underwriterErrorMessage() {
		return getService().underwriterErrorMessage();
	}
	
	public static String notifyMeButtonText() {
		return getService().notifyMeButtonText();
	}
	
	public static String emailSuccessText() {
		return getService().emailSuccessText();
	}
	
	private static ServiceTracker<FrontEndConfigService, FrontEndConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(FrontEndConfigurationUtil.class) , FrontEndConfigService.class);

}
