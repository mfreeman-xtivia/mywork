package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.PoolingHttpConfigService;

public class PoolingHttpConfigurationUtil {
	
	public static PoolingHttpConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static boolean contentCompressionEnabled() {
		return getService().contentCompressionEnabled();
	}

	public static int connectionRequestTimeout() {
		return getService().connectionRequestTimeout();
	}

	public static int defaultMaxConnectionsPerRoute() {
		return getService().defaultMaxConnectionsPerRoute();
	}

	public static int maxTotalConnections() {
		return getService().maxTotalConnections();
	}
	
	private static ServiceTracker<PoolingHttpConfigService, PoolingHttpConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(PoolingHttpConfigurationUtil.class) , PoolingHttpConfigService.class);

}
