package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.AzureAPIMConfigService;

public class AzureAPIMConfigurationUtil {
	
	public static AzureAPIMConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String continuingEducationApiKey() {
		return getService().continuingEducationApiKey();
	}
	
	public static String billingStatusApiKey() {
		return getService().billingStatusApiKey();
	}
	
	public static String agencyContactsApiKey() {
		return getService().agencyContactsApiKey();
	}

	public static String customerDetailsKey() {
		return getService().customerDetailsKey();
	}

	public static String apimBaseURL() {
		return getService().apimBaseURL();
	}
	
	public static String agencyStartQuoteApiKey() {
		return getService().agencyStartQuoteApiKey();
	}
	
	public static String agencyServiceApiKey() {
		return getService().agencyServiceApiKey();
	}
	
	public static String monitoringServiceApiKey() {
		return getService().monitoringServiceApiKey();
	}

	public static String claimsReportsApiKey() {
		return getService().claimsReportsServiceApiKey();
	}
	
	private static ServiceTracker<AzureAPIMConfigService, AzureAPIMConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(AzureAPIMConfigurationUtil.class) , AzureAPIMConfigService.class);

}
