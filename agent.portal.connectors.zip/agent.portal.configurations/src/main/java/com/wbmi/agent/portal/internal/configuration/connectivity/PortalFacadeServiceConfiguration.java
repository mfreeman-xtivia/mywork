package com.wbmi.agent.portal.internal.configuration.connectivity;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(id = "com.wbmi.agent.portal.internal.configuration.connectivity.PortalFacadeServiceConfiguration", 
	localization = "content/Language", name = "facade-web-service")
public interface PortalFacadeServiceConfiguration {

	@Meta.AD(deflt = "insert API key here", description = "Type the API Key to access the Facade API.", name = "facade-api-key", required = false)
	public String wbmiApiKey();

	@Meta.AD(deflt = "https://wbmi-dev.com/api", description = "Base URL for requests to Facade Service", name = "facade-base-url", required = false)
	public String wbmiBaseURL();

	@Meta.AD(deflt = "insert Azure API subscription key here", description = "Type the Azure API Subscription Key to access the Facade Azure API.", name = "facade-azure-api-subscription-key", required = false)
	public String wbmiAzureApiSubscriptionKey();

	@Meta.AD(deflt = "https://wbmi-dev-api.azure-api.net/common", description = "Base URL for requests to Facade Azure APIs", name = "facade-azure-api-base-url", required = false)
	public String wbmiAzureApiBaseURL();

}