package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.widget.DocumentConfiguration;


@Component(configurationPid = "com.wbmi.agent.portal.internal.configuration.widget.DocumentConfiguration", immediate = true, service = DocumentConfigService.class)
public class DocumentConfigService {

	public String vocabulary() {
		return _documentConfiguration.vocabulary();
	}

	public String documentTypeVocabulary() {
		return _documentConfiguration.documentTypeVocabulary();
	}

	public String[] categoryList() {
		return _documentConfiguration.categoryList();
	}

	public String[] brochuresDocumentTypes() {
		return _documentConfiguration.brochuresDocumentTypes();
	}

	public String[] formsAndQuestDocumentTypes() {
		return _documentConfiguration.formsAndQuestDocumentTypes();
	}

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("DocumentConfigService activating");
		_documentConfiguration = ConfigurableUtil.createConfigurable(DocumentConfiguration.class, properties);
	}

	private DocumentConfiguration _documentConfiguration;

	private static final Logger _logUtil = LoggerFactory.getLogger(DocumentConfigService.class);

}
