package com.wbmi.agent.portal.internal.reader.service;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.common.FrontEndConfigurations;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(
		configurationPid = "com.wbmi.agent.portal.internal.configuration.common.FrontEndConfigurations",
		immediate = true, service = FrontEndConfigService.class
	)
public class FrontEndConfigService {
	
	public String wbConnectDomain() {
		return _configuration.wbConnectDomain();
	}
	
	public String dcdmAgencyUpdateLink() {
		return _configuration.dcdmAgencyUpdateLink();
	}

	public String serviceTimeOut() {
		return _configuration.serviceTimeOut();
	}
	
	public String dataTablePageSizes() {
		return _configuration.dataTablePageSizes();
	}
	
	public String underwriterErrorMessage() {
		return _configuration.underwriterErrorMessage();
	}
	
	public String rsmError() {
		return _configuration.rsmError();
	}
	
	public String notifyMeButtonText() {
		return _configuration.notifyMeButtonText();
	}
	
	public String generalTechnicalError() {
		return _configuration.generalTechnicalError();
	}
	
	public String emailSuccessText() {
		return _configuration.emailSuccessText();
	}
	
	public String billingErrorMessage() {
		return _configuration.billingErrorMessage();
	}

	public String claimsReportsErrorMessage() {
		return _configuration.claimsReportsErrorMessage();
	}
	
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("FrontEndConfigService activating");
		_configuration = ConfigurableUtil.createConfigurable(FrontEndConfigurations.class, properties);
	}
	
	private FrontEndConfigurations _configuration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(FrontEndConfigService.class);

}
