package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.configuration.connectivity.PoolingHttpClientFactoryConfiguration;

@Component(
		configurationPid = "com.wbmi.agent.portal.configuration.connectivity.PoolingHttpClientFactoryConfiguration",
		immediate = true, service = PoolingHttpConfigService.class
	)
public class PoolingHttpConfigService {
	
	public boolean contentCompressionEnabled() {
		return _configuration.contentCompressionEnabled();
	}

	public int connectionRequestTimeout() {
		return _configuration.connectionRequestTimeout();
	}

	public int defaultMaxConnectionsPerRoute() {
		return _configuration.defaultMaxConnectionsPerRoute();
	}

	public int maxTotalConnections() {
		return _configuration.maxTotalConnections();
	}
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("PoolingHttpConfigService activating");
		_configuration = ConfigurableUtil.createConfigurable(PoolingHttpClientFactoryConfiguration.class, properties);
	}
	
	private PoolingHttpClientFactoryConfiguration _configuration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(PoolingHttpConfigService.class);

}
