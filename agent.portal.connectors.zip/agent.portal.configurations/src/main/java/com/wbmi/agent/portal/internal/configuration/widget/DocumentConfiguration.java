package com.wbmi.agent.portal.internal.configuration.widget;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
	id = "com.wbmi.agent.portal.internal.configuration.widget.DocumentConfiguration", 
	localization = "content/Language", name = "document-service-config")
public interface DocumentConfiguration {

	@Meta.AD(deflt = "Division", description = "Documents Vocabulary name for Agent Portal.", name = "vocab-name", required = false)
	public String vocabulary();
	
	@Meta.AD(deflt = "Document Types", description = "Document Type Vocabulary name for Agent Portal.", name = "document-type-vocab-name", required = false)
	public String documentTypeVocabulary();
	
	@Meta.AD(deflt = "Bonds|Commercial Enterprise|Personal Lines", description = "Documents Category array list for Agent Portal.", name = "category-list", required = false)
	public String[] categoryList();
	
	@Meta.AD(deflt = "Marketing|Brochures", description = "Brochures Document Type Category list for Agent Portal.", name = "brochures-document-types", required = false)
	public String[] brochuresDocumentTypes();
	
	@Meta.AD(deflt = "Forms & Questionnaires|Contracts & Endorsements", description = "Forms and Questionnaires Documents Category list for Agent Portal.", name = "forms-and-quest-document-types", required = false)
	public String[] formsAndQuestDocumentTypes();
}
