package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.MockServiceConfigurationService;

public class MockServiceConfigurationUtil {

	public static MockServiceConfigurationService getService() {
		return _serviceTracker.getService();
	}

	public static String mockAgencyCode() {
		return getService().mockAgencyCode();
	}
	
	public static String mockAgencyName() {
		return getService().mockAgencyName();
	}

	public static Boolean mockAgencyCodeEnabled() {
		return getService().mockAgencyCodeEnabled();
	}

	public static Boolean customerDetailsMockingEnabled() {
		return getService().customerDetailsMockingEnabled();
	}

	public static Boolean courseListMockingEnabled() {
		return getService().courseListMockingEnabled();
	}

	public static Boolean registerCoursesMockingEnabled() {
		return getService().registerCoursesMockingEnabled();
	}

	public static Boolean isDocumentServiceMockingEnabled() {
		return getService().isDocumentServiceMockingEnabled();
	}

	public static Boolean listCategoryServiceMockingEnabled() {
		return getService().listCategoryServiceMockingEnabled();
	}

	public static Boolean agencyContactsMockingEnabled() {
		return getService().agencyContactsMockingEnabled();
	}

	public static Boolean generalInfoContactsMockingEnabled() {
		return getService().generalInfoContactsMockingEnabled();
	}

	public static Boolean recentCancellationsMockingEnabled() {
		return getService().recentCancellationsMockingEnabled();
	}

	public static Boolean renewalsPastDueMockingEnabled() {
		return getService().renewalsPastDueMockingEnabled();
	}

	public static Boolean accountsPastDueMockingEnabled() {
		return getService().accountsPastDueMockingEnabled();
	}

	public static Boolean startQuoteMockingEnabled() {
		return getService().startQuoteMockingEnabled();
	}
	
	public static Boolean agencyDetailsMockingEnabled() {
		return getService().agencyDetailsMockingEnabled();
	}
	
	public static Boolean agencyMockingEnabled() {
		return getService().agencyMockingEnabled();
	}
	
	public static Boolean getMonitoringServiceMockingEnabled() {
		return getService().getMonitoringServiceMockingEnabled();
	}
	
	public static Boolean generateBadStatusServiceMockResponse() {
		return getService().generateBadStatusServiceMockResponse();
	}
	
	public static Boolean addMonitoringServiceMockingEnabled() {
		return getService().addMonitoringServiceMockingEnabled();
	}
	
	public static Boolean updateMonitoringServiceMockingEnabled() {
		return getService().updateMonitoringServiceMockingEnabled();
	}
	
	public static Boolean deleteMonitoringServiceMockingEnabled() {
		return getService().deleteMonitoringServiceMockingEnabled();
	}
	
	
	public static Boolean allServiceMonitoringStatusMockingEnabled() {
		return getService().allServiceMonitoringStatusMockingEnabled();
	}
	
	public static Boolean notificationServiceMockingEnabled() {
		return getService().notificationServiceMockingEnabled();
	}


	public static Boolean claimsReportsMockingEnabled() {
		return getService().claimsReportsMockingEnabled();
	}
	

	private static ServiceTracker<MockServiceConfigurationService, MockServiceConfigurationService> _serviceTracker = ServiceTrackerFactory
			.open(FrameworkUtil.getBundle(MockServiceConfigurationUtil.class), MockServiceConfigurationService.class);
}
