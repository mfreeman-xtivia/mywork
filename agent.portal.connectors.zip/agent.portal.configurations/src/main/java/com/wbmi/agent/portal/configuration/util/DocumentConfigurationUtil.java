package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.DocumentConfigService;

public class DocumentConfigurationUtil {
	
	public static DocumentConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String vocabulary() {
		return getService().vocabulary();
	}
	
	public static String documentTypeVocabulary() {
		return getService().documentTypeVocabulary();
	}
	
	public static String[] catregoryList() {
		return getService().categoryList();
	}
	
	public static String[] brochuresDocumentTypes() {
		return getService().brochuresDocumentTypes();
	}

	public static String[] formsAndQuestDocumentTypes() {
		return getService().formsAndQuestDocumentTypes();
	}


	private static ServiceTracker<DocumentConfigService, DocumentConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(DocumentConfigurationUtil.class) , DocumentConfigService.class);

}
