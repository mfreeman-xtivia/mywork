package com.wbmi.agent.portal.configuration.util;

import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

import com.liferay.osgi.util.ServiceTrackerFactory;
import com.wbmi.agent.portal.internal.reader.service.WbContactsConfigService;

public class WBContactsConfigurationUtil {
	
	public static WbContactsConfigService getService() {
		return _serviceTracker.getService();
	}
	
	public static String vocabulary() {
		return getService().vocabulary();
	}
	
	public static String categoryName() {
		return getService().categoryName();
	}
	
	public static String westBendPhone() {
		return getService().westBendPhone();
	}
	
	private static ServiceTracker<WbContactsConfigService, WbContactsConfigService> _serviceTracker =
			ServiceTrackerFactory.open(FrameworkUtil.getBundle(WBContactsConfigurationUtil.class) , WbContactsConfigService.class);

}
