package com.wbmi.agent.portal.internal.configuration.injector;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.servlet.taglib.BaseDynamicInclude;
import com.liferay.portal.kernel.servlet.taglib.DynamicInclude;
import com.liferay.portal.kernel.util.StringBundler;
import com.wbmi.agent.portal.configuration.model.ErrorMessageCategoryEnum;
import com.wbmi.agent.portal.configuration.util.FrontEndConfigurationUtil;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Component(
	immediate = true, service = DynamicInclude.class, 
	configurationPolicy = ConfigurationPolicy.OPTIONAL
)
public class ConfigurationInjector extends BaseDynamicInclude {

	@Override
	public void include(final HttpServletRequest request, final HttpServletResponse response, final String key)
			throws IOException {
		logger.debug("ConfigurationInjector.include()");
		final PrintWriter printWriter = response.getWriter();
		final StringBundler sb = new StringBundler();

		sb.append("<script type=\"text/javascript\">\n");
		sb.append("var agentPortalUtility = ");
		JSONObject frontEndJson = JSONFactoryUtil.createJSONObject();
		frontEndJson.put("wbConnectDomain", FrontEndConfigurationUtil.wbConnectDomain());
		frontEndJson.put("serviceTimeout", FrontEndConfigurationUtil.serviceTimeOut());
		frontEndJson.put("wbConnectDomain", FrontEndConfigurationUtil.wbConnectDomain());
		frontEndJson.put("dataTablePageSize", FrontEndConfigurationUtil.dataTablePageSizes());
		
		frontEndJson.put(ErrorMessageCategoryEnum.BILLING_ERROR.getCategory(), FrontEndConfigurationUtil.billingErrorMessage());
		frontEndJson.put(ErrorMessageCategoryEnum.CLAIMS_REPORT_ERROR.getCategory(), FrontEndConfigurationUtil.claimsReportsErrorMessage());
		frontEndJson.put(ErrorMessageCategoryEnum.GENERAL_TECH_ERROR.getCategory(), FrontEndConfigurationUtil.generalTechnicalError());
		frontEndJson.put(ErrorMessageCategoryEnum.RSM_ERROR.getCategory(), FrontEndConfigurationUtil.rsmError());
		frontEndJson.put(ErrorMessageCategoryEnum.UW_ERROR.getCategory(), FrontEndConfigurationUtil.underwriterErrorMessage());
		frontEndJson.put("notifyButtonText", FrontEndConfigurationUtil.notifyMeButtonText());
		frontEndJson.put("emailSuccessText", FrontEndConfigurationUtil.emailSuccessText());


		sb.append(frontEndJson.toJSONString());
		sb.append(";\n");
		sb.append("</script>");

		printWriter.println(sb.toString());
	}

	@Override
	public void register(final DynamicIncludeRegistry dynamicIncludeRegistry) {
		dynamicIncludeRegistry.register("/html/common/themes/top_head.jsp#post");
	}

	private static final Logger logger = LoggerFactory.getLogger(ConfigurationInjector.class);
}
