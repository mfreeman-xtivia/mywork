package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.cache.configuration.PortalCacheConfiguration;

@Component(
		configurationPid = "com.wbmi.agent.portal.cache.configuration.PortalCacheConfiguration",
		immediate = true, service = PortalCacheService.class
	)
public class PortalCacheService {
	
	public Boolean isPortalCacheEnabled() {
		return _configurations.isPortalCacheEnabled();
	}
	
	public Boolean isBrowserCacheEnabled() {
		return _configurations.isBrowserCacheEnabled();
	}
	
	public String[] byPassUrlPatterns() {
		return _configurations.byPassUrlPatterns();
	}
	
	public String[] cacheHeaders() {
		return _configurations.cacheHeaders();
	}
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("PortalCacheService activating");
		_configurations = ConfigurableUtil.createConfigurable(PortalCacheConfiguration.class, properties);
	}
	
	private PortalCacheConfiguration  _configurations;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(PortalCacheService.class);

}
