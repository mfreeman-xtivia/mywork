package com.wbmi.agent.portal.internal.reader.service;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.internal.configuration.connectivity.AzureAPIMConfiguration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(
		configurationPid = "com.wbmi.agent.portal.internal.configuration.connectivity.AzureAPIMConfiguration",
		immediate = true, service = AzureAPIMConfigService.class
	)
public class AzureAPIMConfigService {
	
	public String apimBaseURL() {
		return _apimConfiguration.apimBaseURL();
	}
	
	public String continuingEducationApiKey() {
		return _apimConfiguration.continuingEducationApiKey();
	}
	
	public String billingStatusApiKey() {
		return _apimConfiguration.billingStatusApiKey();
	}
	
	public String agencyContactsApiKey() {
		return _apimConfiguration.agencyContactsApiKey();
	}

	public String customerDetailsKey() {
		return _apimConfiguration.customerDetailsKey();
	}
	
	public String agencyStartQuoteApiKey() {
		return _apimConfiguration.agencyStartQuoteApiKey();
	}
	
	public String agencyServiceApiKey() {
		return _apimConfiguration.agencyServiceApiKey();
	}
	
	public String monitoringServiceApiKey() {
		return _apimConfiguration.monitoringServiceApiKey();
	}

	public String claimsReportsServiceApiKey() {
		return _apimConfiguration.claimsReportsApiKey();
	}
	
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("AzureAPIMConfigService activating");
		_apimConfiguration = ConfigurableUtil.createConfigurable(AzureAPIMConfiguration.class, properties);
	}
	
	private AzureAPIMConfiguration _apimConfiguration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(AzureAPIMConfigService.class);

}
