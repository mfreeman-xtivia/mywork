package com.wbmi.agent.portal.internal.configuration.common;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(id = "com.wbmi.agent.portal.internal.configuration.common.FrontEndConfigurations", 
			localization = "content/Language", name = "front-end-config")
public interface FrontEndConfigurations {

	@Meta.AD(deflt = "https://test.wbconnect.com/", description = "Type the domain for WB Connect.", name = "wb-connect-domain", required = false)
	public String wbConnectDomain();
	
	@Meta.AD(deflt = "https://wbmi.okta.com/home/westbendmutualinsurancecompany_producerone_1/0oa8vl86ilzxHXt0e1t7/aln8vlbyscJUFW4Tn1t7", 
				description = "DCDM Agency or Producer Information Update Link", name = "DCDM Agency/Producer Update Link", required = false)
	public String dcdmAgencyUpdateLink();

	@Meta.AD(deflt = "30", description = "Timeout configuration for the service calls in seconds", name = "timeout-property", required = false)
	public String serviceTimeOut();
	
	@Meta.AD(deflt = "15", description = "Default page size for Data Tables", name = "page-size-property", required = false)
	public String dataTablePageSizes();
	
	@Meta.AD(deflt = "Billing Error", 
				description = "Error Message shown on billing widgets", name = "Billing Error Message", required = false)
	public String billingErrorMessage();

	@Meta.AD(deflt = "Claims Reporting Error",
			description = "Error Message shown on claims reports widgets", name = "Claims Reporting Error Message", required = false)
	public String claimsReportsErrorMessage();
	
	@Meta.AD(deflt = "Technical Error", 
			description = "General Technical Error Message", name = "General Technical Error Message", required = false)
	public String generalTechnicalError();
	
	@Meta.AD(deflt = "RSM Error", 
			description = "Error Message shown on Contacts widgets", name = "Regional Sales Manager Error Message", required = false)
	public String rsmError();
	
	@Meta.AD(deflt = "Underwriter Error", 
			description = "Error Message shown on Underwriter widgets", name = "Underwriter Error Message", required = false)
	public String underwriterErrorMessage();
	
	@Meta.AD(deflt = "Notify me when the issue is resolved", 
			description = "Message Shown on the Notify me Button", name = "Notify Button Text", required = false)
	public String notifyMeButtonText();
	
	@Meta.AD(deflt = "Email Success Text", 
			description = "Success Message shown after clicking Notify Me Button", name = "Email Success Message", required = false)
	public String emailSuccessText();
}
