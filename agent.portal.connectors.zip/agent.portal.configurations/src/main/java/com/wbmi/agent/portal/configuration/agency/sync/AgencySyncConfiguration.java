package com.wbmi.agent.portal.configuration.agency.sync;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
		id = "com.wbmi.agent.portal.configuration.agency.sync.AgencySyncConfiguration",
		localization = "content/Language",
		name = "agent.portal.agency.sync.configurations"
)
public interface AgencySyncConfiguration {
	
	@Meta.AD(deflt = "0 0 8 * * ?", description = "cron-expression-description", name = "cron-expression", required = false)
	public String cronExpression();
	
	@Meta.AD(deflt = "false", description = "Is scheduler Active", required = false)
	public Boolean isSchedulerActive();
	
	@Meta.AD(deflt = "true", description = "Is Startup Sync Active", required = false)
	public Boolean isStartUpSyncActive();
	
	@Meta.AD(deflt = "10", description = "Maximum Number of Recursive call before stopping recursion", required = false)
	public Integer maxRecursionForSorting();
}
