package com.wbmi.agent.portal.internal.reader.service;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.wbmi.agent.portal.configuration.agency.sync.AgencySyncConfiguration;

@Component(
		configurationPid = "com.wbmi.agent.portal.configuration.agency.sync.AgencySyncConfiguration",
		immediate = true, service = AgencySyncConfigService.class
	)
public class AgencySyncConfigService {
	
	public String cronExpression() {
		return _configuration.cronExpression();
	}
	
	public Boolean isSchedulerActive() {
		return _configuration.isSchedulerActive();
	}
	
	public Boolean isStartUpSyncActive() {
		return _configuration.isStartUpSyncActive();
	}
	
	public Integer maxRecursionForSorting() {
		return _configuration.maxRecursionForSorting();
	}
	
	
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_logUtil.debug("AgencySyncConfigService activating");
		_configuration = ConfigurableUtil.createConfigurable(AgencySyncConfiguration.class, properties);
	}
	
	private AgencySyncConfiguration _configuration;
	
	private static final Logger  _logUtil = LoggerFactory.getLogger(AgencySyncConfigService.class);

}
