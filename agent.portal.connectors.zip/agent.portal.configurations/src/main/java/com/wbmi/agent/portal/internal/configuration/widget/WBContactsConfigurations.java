package com.wbmi.agent.portal.internal.configuration.widget;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
	id = "com.wbmi.agent.portal.internal.configuration.widget.WBContactsConfigurations", 
	localization = "content/Language", name = "wb-contacts-service-config")
public interface WBContactsConfigurations {
	
	@Meta.AD(deflt = "Web Contents", description = "Web Contents Vocabulary name for Agent Portal.", name = "contacts-vocab-name", required = false)
	public String vocabulary();
	
	@Meta.AD(deflt = "West Bend Contacts", description = "Category for West Bend Contacts web content.", name = "contacts-category-name", required = false)
	public String categoryName();
	
	@Meta.AD(deflt = "(800) 236-5010", description = "West Bend Phone No. (To be used for both CL,PL and Speciality Lines Division)", name = "wb-phone", required = false)
	public String westBendPhone();
	
}
