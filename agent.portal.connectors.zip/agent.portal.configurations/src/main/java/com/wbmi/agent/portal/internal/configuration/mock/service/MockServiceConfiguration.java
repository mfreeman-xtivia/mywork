package com.wbmi.agent.portal.internal.configuration.mock.service;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author kmukherjee
 *
 */
@ExtendedObjectClassDefinition(category = "agent-portal")
@Meta.OCD(
		id = "com.wbmi.agent.portal.internal.configuration.mock.service.MockServiceConfiguration", 
		localization = "content/Language", name = "mock-web-service")
public interface MockServiceConfiguration {
	
	@Meta.AD(deflt = "48787", description = "Mock Agency Code used to fetch Data", required = false)
	public String mockAgencyCode();
	
	@Meta.AD(deflt = "SAMPLE ACCOUNT", description = "Mock Agency Name", required = false)
	public String mockAgencyName();
	
	@Meta.AD(deflt = "true", description = "Agency Code Mocking Enabled", required = false)
	public Boolean mockAgencyCodeEnabled();

	@Meta.AD(deflt = "true", description = "Enable Get Course List Service Mocking", required = false)
	public boolean courseListMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Register Courses mocking", required = false)
	public boolean registerCoursesMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable List Category Service Mocking", required = false)
	public boolean listCategoryServiceMockingEnabled();

	@Meta.AD(deflt = "true", description = "Enable Document Service Mocking", required = false)
	public boolean documentServiceMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Agency Contact Service Mocking", required = false)
	public boolean agencyContactsMockingEnabled();

	@Meta.AD(deflt = "true", description = "Enable Customer Details Service Mocking", required = false)
	public boolean customerDetailsMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable General Info Contact Service Mocking", required = false)
	public boolean generalInfoContactsMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Recent Cancellations Mocking", required = false)
	public boolean recentCancellationsMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Renewals Past Due Mocking", required = false)
	public boolean renewalsPastDueMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Accounts Past Due Mocking", required = false)
	public boolean accountsPastDueMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Start Quote Mocking", required = false)
	public boolean startQuoteMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Agency Details Mocking", required = false)
	public boolean agencyDetailsMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Agencies for Agent Quote Mocking", required = false)
	public boolean agencyMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Get Service Monitoring", required = false)
	public boolean getMonitoringServiceMockingEnabled();
	
	@Meta.AD(deflt = "false", description = "Enable Bad Status Service Monitoring Response", required = false)
	public boolean generateBadStatusServiceMockResponse();
	
	@Meta.AD(deflt = "true", description = "Enable Add Service Monitoring", required = false)
	public boolean addMonitoringServiceMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Update Service Monitoring", required = false)
	public boolean updateMonitoringServiceMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable Delete Service Monitoring", required = false)
	public boolean deleteMonitoringServiceMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable All Service monitoring Status", required = false)
	public boolean allServiceMonitoringStatusMockingEnabled();
	
	@Meta.AD(deflt = "true", description = "Enable OutageNotification  Service for Agent Portal", required = false)
	public boolean notificationServiceMockingEnabled();

	@Meta.AD(deflt = "true", description = "Enable Claims Reports Mocking", required = false)
	public boolean claimsReportsMockingEnabled();

}
