package com.wbmi.agent.portal.cache.constants;

public enum MultiVMCacheNames {
	
	BILLING_CACHE( "com.wbmi.agent.portal.cache.BillingCache","Billing"),
	AGENCY_DIRECTORY("com.wbmi.agent.portal.cache.AgencyDirectory", "Agency Contacts"),
	AGENCY_DETAILS("com.wbmi.agent.portal.cache.AgencyDetails", "Agency Details"),
	CONTINUING_EDUCATION("com.wbmi.agent.portal.cache.TrainingCourses", "Training Courses"),
	START_QUOTE("com.wbmi.agent.portal.cache.StartQuote", "Start Quote"),
	CLAIMS_REPORTS("com.wbmi.agent.portal.cache.ClaimsReports", "Claims Reports");
	
	private MultiVMCacheNames(String cacheName,String displayName) {
		this.cacheName = cacheName;
		this.displayName= displayName;
	}
	
	public String getCacheName() {
		return cacheName;
	}
	
	public String getDisplayName() {
		return displayName;
	}

	private String cacheName;
	private String displayName;
}
