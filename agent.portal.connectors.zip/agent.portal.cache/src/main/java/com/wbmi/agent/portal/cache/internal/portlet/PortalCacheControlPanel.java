package com.wbmi.agent.portal.cache.internal.portlet;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.application.list.BasePanelApp;
import com.liferay.application.list.PanelApp;
import com.liferay.portal.kernel.model.Portlet;

@Component(
		immediate = true,
		property = {
				"panel.category.key=control_panel.agent.portal", 
				"service.ranking:Integer=100" 
		},
		service = PanelApp.class)
public class PortalCacheControlPanel extends BasePanelApp {

	@Override
	public String getPortletId() {
		return PortalCachePortletKeys.PORTLET_NAME;
	}

	@Override
	@Reference(
			target = "(javax.portlet.name=" + PortalCachePortletKeys.PORTLET_NAME + ")",
			unbind = "-")
	public void setPortlet(Portlet portlet) {
		super.setPortlet(portlet);
	}
}