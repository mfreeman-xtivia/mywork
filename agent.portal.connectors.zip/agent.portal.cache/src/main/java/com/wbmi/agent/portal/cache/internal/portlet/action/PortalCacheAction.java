package com.wbmi.agent.portal.cache.internal.portlet.action;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.wbmi.agent.portal.cache.api.AgentPortalCache;
import com.wbmi.agent.portal.cache.constants.CacheTypeEnum;
import com.wbmi.agent.portal.cache.internal.portlet.PortalCachePortletKeys;
import com.wbmi.agent.portal.cache.model.PortalCacheMetadata;

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + PortalCachePortletKeys.PORTLET_NAME,
			"mvc.command.name=clearCache"
		},
		service = MVCActionCommand.class
	)
public class PortalCacheAction extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		logger.info("PortalCacheAction.doProcessAction() called");
		String cacheType = ParamUtil.getString(actionRequest,"cacheType","multiVM");
		String cacheName = ParamUtil.getString(actionRequest, "cacheName");
		String redirect = ParamUtil.getString(actionRequest, "redirect");
		String tabs1 = ParamUtil.getString(actionRequest, "tabs1");
		logger.info("Cache Type is {} and Cache name is {}", cacheType, cacheName);
		PortalCacheMetadata portalCacheMetadata= new PortalCacheMetadata();
		if("multiVM".equalsIgnoreCase(cacheType)) {
			portalCacheMetadata.setCacheType(CacheTypeEnum.MULTI_VM_POOL);
		} else {
			portalCacheMetadata.setCacheType(CacheTypeEnum.SINGLE_VM_POOL);
		}
		if(!"all".equalsIgnoreCase(cacheName)) {
			portalCacheMetadata.setCacheName(cacheName);
			agentPortalCache.removeCache(portalCacheMetadata);
		} else {
			agentPortalCache.removeCacheType(portalCacheMetadata);
		}
		
		actionRequest.setAttribute("tabs1", tabs1);
		sendRedirect(actionRequest, actionResponse,redirect);
	}
	
	
	@Reference
	private AgentPortalCache agentPortalCache;
	
	private static final Logger logger = LoggerFactory.getLogger(PortalCacheAction.class);

}
