package com.wbmi.agent.portal.cache.constants;

public enum CacheTypeEnum {
	
	SINGLE_VM_POOL("Single VM Pool", Boolean.FALSE),MULTI_VM_POOL("Multi VM Pool", Boolean.TRUE), NONE("No Cache", null);
	
	public String getCacheType() {
		return cacheType;
	}

	public void setCacheType(String cacheType) {
		this.cacheType = cacheType;
	}
	
	public Boolean isMultiVM() {
		return isMultiVM;
	}

	public void setMultiVM(Boolean isMultiVM) {
		this.isMultiVM = isMultiVM;
	}
	
	private CacheTypeEnum(String cacheType, Boolean isMultiVM) {
		this.cacheType = cacheType;
		this.isMultiVM = isMultiVM;
	}
	
	private String cacheType;
	private Boolean isMultiVM;

}
