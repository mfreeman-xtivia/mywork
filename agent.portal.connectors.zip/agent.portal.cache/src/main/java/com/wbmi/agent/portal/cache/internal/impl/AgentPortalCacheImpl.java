package com.wbmi.agent.portal.cache.internal.impl;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.osgi.framework.BundleContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.cache.MultiVMPool;
import com.liferay.portal.kernel.cache.PortalCache;
import com.liferay.portal.kernel.cache.SingleVMPool;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.cache.api.AgentPortalCache;
import com.wbmi.agent.portal.cache.constants.CacheTypeEnum;
import com.wbmi.agent.portal.cache.model.PortalCacheMetadata;
import com.wbmi.agent.portal.configuration.util.PortalCacheConfigurationUtil;

/**
 * @author KMukher
 */
@Component(immediate = true, service = AgentPortalCache.class)
public class AgentPortalCacheImpl implements AgentPortalCache {

	@Override
	public Serializable getFromCache(PortalCacheMetadata portalCacheMetadata) {
		if(!isCachEnabled(portalCacheMetadata)) {
			return null;
		}
		
		PortalCache<Serializable, Serializable> portalCache = getPortalCache(portalCacheMetadata.getCacheType(),portalCacheMetadata.getCacheName());
		Serializable portalCacheObject = portalCache.get(portalCacheMetadata.getCacheKey());
		if(logger.isDebugEnabled()) {
			logger.debug("Object returned from cache for cache key : {} and is : {}", portalCacheMetadata.getCacheKey(), ((portalCacheObject == null) ? "Null" : "Not Null"));
		}
		return portalCacheObject;
	}

	@Override
	public void putInCache(PortalCacheMetadata portalCacheMetadata, Serializable objectToCache) {
		if(!isCachEnabled(portalCacheMetadata)) {
			return;
		}
		
		PortalCache<Serializable, Serializable> portalCache = getPortalCache(portalCacheMetadata.getCacheType(),portalCacheMetadata.getCacheName());
		if(logger.isDebugEnabled()) {
			logger.debug("Updating policy into cache for key : {}", portalCacheMetadata.getCacheKey());
		}
		portalCache.put(portalCacheMetadata.getCacheKey(), objectToCache);
		
	}
	
	@Override
	public void removeCache(PortalCacheMetadata portalCacheMetadata) {
		PortalCache<Serializable, Serializable> portalCache = getPortalCache(portalCacheMetadata.getCacheType(), portalCacheMetadata.getCacheName());
		portalCache.removeAll();
	}
	
	@Override
	public void removeCacheType(PortalCacheMetadata portalCacheMetadata) {
		if(portalCacheMetadata.getCacheType().isMultiVM()) {
			for (PortalCache<?, ?> portalCache : multiVMPortalCaches.values()) {
				portalCache.removeAll();
			}
		} else {
			for (PortalCache<?, ?> portalCache : singleVMPortalCaches.values()) {
				portalCache.removeAll();
			}
		}
	}

	@Override
	public void removeFromCache(PortalCacheMetadata portalCacheMetadata) {
		if(!isCachEnabled(portalCacheMetadata)) {
			return ;
		}
		
		PortalCache<Serializable, Serializable> portalCache = getPortalCache(portalCacheMetadata.getCacheType(),portalCacheMetadata.getCacheName());
		if(logger.isDebugEnabled()) {
			logger.debug("Removing policy from cache for key : {}", portalCacheMetadata.getCacheKey());
		}
		portalCache.remove(portalCacheMetadata.getCacheKey());
	}
	
	private PortalCache<Serializable, Serializable> getPortalCache(CacheTypeEnum cacheType,String cacheName) {
		if(!CacheRegistryUtil.isActive() || Validator.isNull(cacheType.isMultiVM())) {
			return null;
		}
		cacheName = getFullQualifiedCacheName(cacheName);
		if(logger.isDebugEnabled()) {
			logger.debug("The Cache finder key name is : {}", cacheName);
		}
		
		PortalCache<Serializable, Serializable> portalCache = null;
		if(cacheType.isMultiVM()) {
			portalCache = retrieveAppropriateCache(cacheType.isMultiVM(),cacheName, multiVMPortalCaches);
		} else {
			portalCache = retrieveAppropriateCache(cacheType.isMultiVM(),cacheName, singleVMPortalCaches); 
		}

		return portalCache;
	}

	private String getFullQualifiedCacheName(String cacheName) {
		return CACHE_FINDER_KEY + StringPool.PERIOD + cacheName;
	}

	@SuppressWarnings("unchecked")
	private PortalCache<Serializable, Serializable> retrieveAppropriateCache(Boolean isMultiVM, String cacheName,
				ConcurrentMap<String, PortalCache<Serializable, Serializable>> portalCaches ) {
		PortalCache<Serializable, Serializable> portalCache = portalCaches.get(cacheName);
		if(portalCache != null) {
			if(logger.isDebugEnabled()) {
				logger.debug("Portal cache is not null. The portal cache class is : {}", portalCache.getClass().getName());
			}
			return portalCache;
		}
		if (isMultiVM) {
			portalCache = (PortalCache<Serializable, Serializable>)multiVMPool.getPortalCache(cacheName);
		} else {
			portalCache = (PortalCache<Serializable, Serializable>)singleVMPool.getPortalCache(cacheName);
		}
		PortalCache<Serializable, Serializable> previousPortalCache = portalCaches.putIfAbsent(cacheName, portalCache);

		if (previousPortalCache != null) {
			return previousPortalCache;
		}
		
		return portalCache;
	}
	
	private Boolean isCachEnabled(PortalCacheMetadata portalCacheMetadata) {
		if(Validator.isNull(portalCacheMetadata)) {
			logger.warn("Invalid portal cache metadata");
			return Boolean.FALSE;
		}
		if(!PortalCacheConfigurationUtil.isPortalCacheEnabled()) {
			logger.warn("Portal Cache not enabled");
			return Boolean.FALSE;
		}
		// CacheType might be none and that will have the isMultiVM value as null :- Check CacheTypeEnum for detail
		if(Validator.isNull(portalCacheMetadata.getCacheType().isMultiVM())){
			logger.warn("Object doesn't support cache");
			return Boolean.FALSE;
		}
		
		return Boolean.TRUE;
	}

	@Activate
	protected void activate(BundleContext bundleContext,Map<String, Object> properties) {
		logger.info("Agent Portal Cache Activate called ");
	}
	
	private MultiVMPool multiVMPool; 
	private SingleVMPool singleVMPool;
	
	private final ConcurrentMap<String, PortalCache<Serializable, Serializable>> multiVMPortalCaches = new ConcurrentHashMap<>();
	private final ConcurrentMap<String, PortalCache<Serializable, Serializable>> singleVMPortalCaches = new ConcurrentHashMap<>();
	
	 @Reference(unbind = "-") 
	 protected void setMultiVMPool(MultiVMPool multiVMPool) { 
		 this.multiVMPool = multiVMPool;
	 }
	 
	 @Reference(unbind = "-")
	 protected void setSingleVMPool(SingleVMPool singleVMPool) {
		 this.singleVMPool = singleVMPool;
	}
	
	private static final String CACHE_FINDER_KEY = AgentPortalCacheImpl.class.getName();
	
	private static final Logger logger = LoggerFactory.getLogger(AgentPortalCacheImpl.class);

}
