package com.wbmi.agent.portal.cache.servlet.filter;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactory;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.servlet.HttpMethods;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.configuration.util.PortalCacheConfigurationUtil;

@Component(
		immediate = true,  
		service = AgentPortalCacheFilter.class
)
public class AgentPortalCacheFilter{

	public void processFilter(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		if (isCachingEnabled(httpServletRequest, httpServletResponse) && isAllowedUrl(httpServletRequest)) {
			calculateHeaders(httpServletResponse);
		}
	}

	private boolean isCachingEnabled(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		return PortalCacheConfigurationUtil.isPortalCacheEnabled() 
				&& PortalCacheConfigurationUtil.isBrowserCacheEnabled()
				/* && HttpServletResponse.SC_OK == httpServletResponse.getStatus() */
				&& HttpMethods.GET.equalsIgnoreCase(httpServletRequest.getMethod());
	}

	private boolean isAllowedUrl(HttpServletRequest httpServletRequest) {
		String[] byPassUrlPatterns = PortalCacheConfigurationUtil.byPassUrlPatterns();
		StringBuffer absoluteUrl = httpServletRequest.getRequestURL();
		return Validator.isNull(byPassUrlPatterns)
				|| !Arrays.stream(byPassUrlPatterns).anyMatch(absoluteUrl.toString()::contains);
	}

	private void calculateHeaders(HttpServletResponse httpServletResponse) throws JSONException {
		String[] cacheHeaders = PortalCacheConfigurationUtil.cacheHeaders();
		if (Validator.isNotNull(cacheHeaders)) {
			addHeaders(httpServletResponse, cacheHeaders);
		}
	}

	private void addHeaders(HttpServletResponse httpServletResponse, String[] cacheHeaders) throws JSONException {
		logger.debug("Adding headers to the reques");
		for (String cacheHeader : cacheHeaders) {
			JSONObject cacheHeaderJson = jsonFactory.createJSONObject(cacheHeader);
			String headerName = cacheHeaderJson.getString(AgentPortalCacheFilter.NAME);
			String value = cacheHeaderJson.getString(AgentPortalCacheFilter.VALUE2);
			if (Validator.isNotNull(headerName) && Validator.isNotNull(value)) {
				httpServletResponse.addHeader(headerName, value);
			}
		}
	}
	
	
	private static final String NAME = "name";

	private static final String VALUE2 = "value";

	@Reference
	private JSONFactory jsonFactory;

	private static final Logger logger = LoggerFactory.getLogger(AgentPortalCacheFilter.class);
}
