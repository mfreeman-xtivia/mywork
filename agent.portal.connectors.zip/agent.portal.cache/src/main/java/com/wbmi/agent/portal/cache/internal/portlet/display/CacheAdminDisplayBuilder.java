package com.wbmi.agent.portal.cache.internal.portlet.display;

import com.liferay.frontend.taglib.clay.servlet.taglib.util.NavigationItemList;
import com.liferay.portal.kernel.language.Language;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;

import java.util.Objects;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class CacheAdminDisplayBuilder {

	public CacheAdminDisplayBuilder(
			Language language, Portal portal, RenderRequest renderRequest,
			RenderResponse renderResponse) {

			_language = language;
			_portal = portal;
			_renderRequest = renderRequest;
			_renderResponse = renderResponse;
		}

		public CacheAdminDisplayContext build() {
			CacheAdminDisplayContext cacheAdminDisplayContext =
				new CacheAdminDisplayContext();

			NavigationItemList navigationItemList = new NavigationItemList();
			String selectedTab = getSelectedTab();

			addNavigationItemList(navigationItemList, "multi-vm-cache", selectedTab);

			addNavigationItemList(navigationItemList, "single-vm-cache", selectedTab);

			cacheAdminDisplayContext.setNavigationItemList(navigationItemList);
			cacheAdminDisplayContext.setSelectedTab(selectedTab);

			return cacheAdminDisplayContext;
		}

		protected void addNavigationItemList(
			NavigationItemList navigationItemList, String label,
			String selectedTab) {

			navigationItemList.add(
				navigationItem -> {
					navigationItem.setActive(selectedTab.equals(label));
					navigationItem.setHref(
						_renderResponse.createRenderURL(), "tabs1", label);
					navigationItem.setLabel(
						_language.get(
							_portal.getHttpServletRequest(_renderRequest), label));
				});
		}

		protected String getSelectedTab() {
			String selectedTab = ParamUtil.getString(
				_renderRequest, "tabs1", "multi-vm-cache");

			if (!Objects.equals(selectedTab, "single-vm-cache") &&
				!Objects.equals(selectedTab, "multi-vm-cache")) {

				return "multi-vm-cache";
			}

			return selectedTab;
		}

		private final Language _language;
		private final Portal _portal;
		private final RenderRequest _renderRequest;
		private final RenderResponse _renderResponse;
}
