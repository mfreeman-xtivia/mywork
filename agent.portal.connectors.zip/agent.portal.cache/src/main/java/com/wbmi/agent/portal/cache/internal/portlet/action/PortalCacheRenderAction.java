package com.wbmi.agent.portal.cache.internal.portlet.action;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.wbmi.agent.portal.cache.internal.portlet.PortalCachePortletKeys;

@Component(
		property = { 
			"javax.portlet.name=" + PortalCachePortletKeys.PORTLET_NAME,
			"mvc.command.name=/agent_cache_admin/view" 
		}, 
		service = MVCRenderCommand.class)
public class PortalCacheRenderAction implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) {

		return "/view.jsp";
	}

}
