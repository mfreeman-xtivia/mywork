package com.wbmi.agent.portal.cache.internal.portlet;

public class PortalCachePortletKeys {
	
	public static final String PORTLET_NAME= "com_wbmi_agent_portal_cache_internal_portlet_controlpanel_Portlet";

}
