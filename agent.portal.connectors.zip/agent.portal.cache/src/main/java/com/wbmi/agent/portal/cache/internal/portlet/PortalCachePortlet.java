package com.wbmi.agent.portal.cache.internal.portlet;

import java.io.IOException;

import javax.portlet.Portlet;
import javax.portlet.PortletConfig;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.kernel.language.Language;
import com.liferay.portal.kernel.model.PortletApp;
import com.liferay.portal.kernel.portlet.LiferayPortletConfig;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.servlet.ServletContextPool;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.wbmi.agent.portal.cache.internal.portlet.display.CacheAdminDisplayBuilder;
import com.wbmi.agent.portal.cache.internal.portlet.display.CacheAdminDisplayContext;

@Component(
		immediate = true,
		property = { 
				"com.liferay.portlet.add-default-resource=true",
				"com.liferay.portlet.css-class-wrapper=portlet-controlpanel",
				"com.liferay.portlet.display-category=category.hidden",
				"com.liferay.portlet.preferences-owned-by-group=true",
				"com.liferay.portlet.render-weight=100",
				"javax.portlet.display-name=Agent Portal Cache Control",
				"javax.portlet.expiration-cache=0",
				"javax.portlet.init-param.view-template=/view.jsp",
				"javax.portlet.name=" + PortalCachePortletKeys.PORTLET_NAME,
				"javax.portlet.resource-bundle=content.Language",
				"javax.portlet.security-role-ref=administrator",
				"javax.portlet.supports.mime-type=text/html"
		},
		service = Portlet.class)
public class PortalCachePortlet extends MVCPortlet {

	@Override
	public void init(PortletConfig portletConfig) throws PortletException {
		super.init(portletConfig);

		final LiferayPortletConfig liferayPortletConfig = (LiferayPortletConfig) portletConfig;

		final com.liferay.portal.kernel.model.Portlet portlet = liferayPortletConfig.getPortlet();

		final PortletApp portletApp = portlet.getPortletApp();

		ServletContextPool.put(portletApp.getServletContextName(), portletApp.getServletContext());
	}

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		logger.info("PortalCachePortlet.render()");
		CacheAdminDisplayBuilder cacheAdminDisplayBuilder =
				new CacheAdminDisplayBuilder(
					_language, _portal, renderRequest, renderResponse);
		
		CacheAdminDisplayContext cacheAdminDisplayContext =
				cacheAdminDisplayBuilder.build();
		
		renderRequest.setAttribute(
				WebKeys.PORTLET_DISPLAY_CONTEXT, cacheAdminDisplayContext);

		//String tab = cacheAdminDisplayContext.getSelectedTab();
		
		super.render(renderRequest, renderResponse);
	}
	
	
	@Reference
	private Language _language;

	@Reference
	private Portal _portal;
	
	private static final Logger logger = LoggerFactory.getLogger(PortalCachePortlet.class);
	
}

