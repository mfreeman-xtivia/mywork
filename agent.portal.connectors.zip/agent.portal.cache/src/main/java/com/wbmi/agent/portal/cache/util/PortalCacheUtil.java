package com.wbmi.agent.portal.cache.util;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.util.Validator;

public class PortalCacheUtil {
	
	public static String generateCacheKey(String ...args) {
		if(Validator.isNull(args) || args.length < 1) {
			return null;
		} else {
			StringBuilder cacheKey = new StringBuilder();
			for (String arg : args) {
				if(!Validator.isBlank(arg))
					cacheKey.append(arg).append(CACHE_KEY_DELIMITTER);
			}
			cacheKey.deleteCharAt(cacheKey.length()-1);
			return cacheKey.toString();
		}
		
	}
	
	public static String generateBillingServiceCallParam(String[] args) {
		return generateCacheKey(args);
	}
	
	private static final String CACHE_KEY_DELIMITTER = StringPool.DASH;
}
