package com.wbmi.agent.portal.cache.model;

import java.io.Serializable;

import com.wbmi.agent.portal.cache.constants.CacheTypeEnum;
import com.wbmi.agent.portal.cache.util.PortalCacheUtil;

/**
 * @author KMukher
 *
 */
public class PortalCacheMetadata implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1145827382783779711L;
	private CacheTypeEnum cacheType;
	private String cacheName;
	private String cacheKey;
	
	public PortalCacheMetadata(CacheTypeEnum cacheType, String cacheName, String cacheKey) {
		this.cacheType = cacheType;
		this.cacheName = cacheName;
		this.cacheKey = cacheKey;
	}
	
	public PortalCacheMetadata(CacheTypeEnum cacheType, String cacheName, String ...args) {
		this.cacheType = cacheType;
		this.cacheName = cacheName;
		this.cacheKey = PortalCacheUtil.generateCacheKey(args);
	}
	
	public PortalCacheMetadata() {
	}
	
	public CacheTypeEnum getCacheType() {
		return cacheType;
	}
	public void setCacheType(CacheTypeEnum cacheType) {
		this.cacheType = cacheType;
	}
	public String getCacheName() {
		return cacheName;
	}
	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}
	public String getCacheKey() {
		return cacheKey;
	}
	public void setCacheKey(String cacheKey) {
		this.cacheKey = cacheKey;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cacheKey == null) ? 0 : cacheKey.hashCode());
		result = prime * result + ((cacheName == null) ? 0 : cacheName.hashCode());
		result = prime * result + ((cacheType == null) ? 0 : cacheType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortalCacheMetadata other = (PortalCacheMetadata) obj;
		if (cacheKey == null) {
			if (other.cacheKey != null)
				return false;
		} else if (!cacheKey.equals(other.cacheKey))
			return false;
		if (cacheName == null) {
			if (other.cacheName != null)
				return false;
		} else if (!cacheName.equals(other.cacheName))
			return false;
		if (cacheType != other.cacheType)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PortalCacheMetadata [cacheType=");
		builder.append(cacheType);
		builder.append(", enforceCache=");
		builder.append(", cacheName=");
		builder.append(cacheName);
		builder.append(", cacheKey=");
		builder.append(cacheKey);
		builder.append("]");
		return builder.toString();
	}
}
