package com.wbmi.agent.portal.cache.api;

import java.io.Serializable;

import com.wbmi.agent.portal.cache.model.PortalCacheMetadata;

/**
 * 
 * @author KMukher
 *
 */

public interface AgentPortalCache {
	
	
	public Serializable getFromCache(PortalCacheMetadata portalCacheMetadata);
	
	public void putInCache(PortalCacheMetadata portalCacheMetadata, Serializable objectToCache);
	
	public void removeCacheType(PortalCacheMetadata portalCacheMetadata);
	
	public void removeCache(PortalCacheMetadata portalCacheMetadata);
	
	public void removeFromCache(PortalCacheMetadata portalCacheMetadata);

}
