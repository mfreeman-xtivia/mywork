package com.wbmi.agent.portal.cache.constants;

public enum SingleVMCacheNames {
	
	DOCUMENTS("com.wbmi.agent.portal.cache.Documents", "Liferay Documents"),
	DOCUMENT_DETAILS("com.wbmi.agent.portal.cache.DocumentDetails", "Liferay Document Details"),
	WEB_CONTENTS("com.wbmi.agent.portal.cache.WebContents", "Liferay Web Contents");
	
	private SingleVMCacheNames(String cacheName,String displayName) {
		this.cacheName = cacheName;
		this.displayName= displayName;
	}

	public String getCacheName() {
		return cacheName;
	}
	
	public String getDisplayName() {
		return displayName;
	}

	private String cacheName;
	private String displayName;
}
