package com.wbmi.agent.portal.common.executor.command;

import com.liferay.portal.kernel.exception.PortalException;

/**
 * 
 * @author kmukherjee
 *
 * @param <T>
 */
public interface WebServiceRequestExecuteCommand<T> {

	public T execute() throws PortalException;

}
