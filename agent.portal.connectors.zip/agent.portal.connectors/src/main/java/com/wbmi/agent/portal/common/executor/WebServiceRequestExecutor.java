package com.wbmi.agent.portal.common.executor;

import com.liferay.portal.kernel.exception.PortalException;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;

/**
 * @author Kaushik Mukherjee
 */
public interface WebServiceRequestExecutor {

	public String execute(WebServiceRequest webServiceRequest) throws PortalException;

}