package com.wbmi.agent.portal.internal.common.executor.impl;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.portal.kernel.exception.PortalException;
import com.wbmi.agent.portal.common.executor.WebServiceRequestExecutor;
import com.wbmi.agent.portal.common.executor.command.WebServiceRequestExecuteCommand;
import com.wbmi.agent.portal.common.executor.command.factory.WebServiceRequestExecutorCommandFactory;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;

/**
 * @author kmukherjee
 */
@Component(immediate = true, service = WebServiceRequestExecutor.class)
public class DefaultWebServiceRequestExecutor implements WebServiceRequestExecutor {

	@Override
	public String execute(WebServiceRequest webServiceRequest) throws PortalException {
		WebServiceRequestExecuteCommand<String> webServiceRequestExecuteCommand =
			webServiceRequestExecutorCommandFactory.createWebServiceRequestExecuteCommand(webServiceRequest);

		return webServiceRequestExecuteCommand.execute();
	}

	@Reference
	protected WebServiceRequestExecutorCommandFactory webServiceRequestExecutorCommandFactory;

}
