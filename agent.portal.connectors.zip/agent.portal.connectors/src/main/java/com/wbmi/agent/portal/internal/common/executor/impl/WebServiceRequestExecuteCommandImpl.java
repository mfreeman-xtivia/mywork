package com.wbmi.agent.portal.internal.common.executor.impl;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.RequestLine;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.LoggingTimer;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.common.executor.command.WebServiceRequestExecuteCommand;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;
import com.wbmi.agent.portal.exception.WebServiceException;

public class WebServiceRequestExecuteCommandImpl implements WebServiceRequestExecuteCommand<String> {

	public WebServiceRequestExecuteCommandImpl(HttpClient httpClient, WebServiceRequest webServiceRequest) {
		_httpClient = httpClient;
		_webServiceRequest = webServiceRequest;
	}

	@Override
	public String execute() throws PortalException {
		String apiKey = _webServiceRequest.getApiKey();
		HttpRequestBase httpRequestBase = _webServiceRequest.getHttpRequestBase();

		RequestLine requestLine = httpRequestBase.getRequestLine();

		String method = requestLine.getMethod();

		if (logger.isInfoEnabled()) {
			logger.info(String.format("Request: %s %s", method, requestLine.getUri()));
		}

		if (logger.isDebugEnabled() && httpRequestBase instanceof HttpEntityEnclosingRequest) {
			HttpEntity entity = ((HttpEntityEnclosingRequest) httpRequestBase).getEntity();

			if (Validator.isNotNull(entity)) {
				try {
					logger.debug("Request Body: " + EntityUtils.toString(entity));
				} catch (IOException | ParseException e) {
					logger.debug("Failed to log request body", e);
				}
			}
		}

		if (Validator.isNotNull(apiKey)) {
			if (logger.isDebugEnabled()) {
				if (_webServiceRequest.isAzureAPIMRequest()) {
					logger.debug(String.format("%s Header: %s", _AZURE_APIM_SUBSCRIPTION_KEY_HEADER, apiKey));
				} else {
					logger.debug(String.format("%s Header: %s", HttpHeaders.AUTHORIZATION, apiKey));
				}
			}

			if (_webServiceRequest.isAzureAPIMRequest()) {
				httpRequestBase.setHeader(_AZURE_APIM_SUBSCRIPTION_KEY_HEADER, apiKey);
			} else {
				httpRequestBase.setHeader(HttpHeaders.AUTHORIZATION, apiKey);
			}
		}

		try (LoggingTimer loggingTimer = new LoggingTimer(requestLine.getUri())) {
			HttpResponse response = _httpClient.execute(httpRequestBase);

			StatusLine statusLine = response.getStatusLine();

			int statusCode = statusLine.getStatusCode();

			if (logger.isInfoEnabled()) {
				logger.info(String.format("Response Status Code: %d - %s", statusCode, statusLine));
			}

			if (logger.isInfoEnabled()) {
				Header[] requestIdHeaders = response.getHeaders(_REQUEST_ID_HEADER);

				if (requestIdHeaders.length > 0) {
					logger.info(String.format("%s Header: %s", _REQUEST_ID_HEADER,
							ArrayUtil.toString(requestIdHeaders, "value")));
				}
			}

			HttpEntity httpEntity = response.getEntity();

			String payload = EntityUtils.toString(httpEntity);

			if (logger.isDebugEnabled()) {
				logger.debug("Response: " + payload);
			}

			if ((HttpServletResponse.SC_OK == statusCode) || (HttpServletResponse.SC_ACCEPTED == statusCode)) {
				return payload;
			} else {
				throw new WebServiceException(statusCode, statusLine.getReasonPhrase(), payload);
			}
		} catch (IOException ioe) {
			throw new WebServiceException(ioe);
		} finally {
			httpRequestBase.releaseConnection();
		}
	}

	private static final String _AZURE_APIM_SUBSCRIPTION_KEY_HEADER = "Ocp-Apim-Subscription-Key";

	private static final String _REQUEST_ID_HEADER = "X-Request-Id";

	private static final Logger logger = LoggerFactory.getLogger(WebServiceRequestExecuteCommandImpl.class);

	private final HttpClient _httpClient;
	private final WebServiceRequest _webServiceRequest;
}
