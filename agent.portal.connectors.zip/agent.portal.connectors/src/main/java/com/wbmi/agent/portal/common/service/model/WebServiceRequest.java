package com.wbmi.agent.portal.common.service.model;

import org.apache.http.client.methods.HttpRequestBase;

/**
 * 
 * @author kmukherjee
 *
 */
public class WebServiceRequest {

	public static WebServiceRequest createWebServiceRequest(String requestName, HttpRequestBase httpRequestBase, boolean azureAPIMRequest) {
		return new WebServiceRequest(requestName, null, httpRequestBase, azureAPIMRequest);
	}

	public static WebServiceRequest createWebServiceRequest(
		String requestName, String apiKey, HttpRequestBase httpRequestBase, boolean azureAPIMRequest) {

		return new WebServiceRequest(requestName, apiKey, httpRequestBase, azureAPIMRequest);
	}

	public WebServiceRequest(String requestName, String apiKey, HttpRequestBase httpRequestBase, boolean azureAPIMRequest) {
		_requestName = requestName;
		_apiKey = apiKey;
		_httpRequestBase = httpRequestBase;
		_azureAPIMRequest = azureAPIMRequest;
	}

	public String getApiKey() {
		return _apiKey;
	}

	public HttpRequestBase getHttpRequestBase() {
		return _httpRequestBase;
	}

	public String getRequestName() {
		return _requestName;
	}

	public boolean isAzureAPIMRequest() {
		return _azureAPIMRequest;
	}

	private String _apiKey;
	private boolean _azureAPIMRequest;
	private HttpRequestBase _httpRequestBase;
	private String _requestName;

}