package com.wbmi.agent.portal.internal.common.executor.factory.impl;

import org.apache.http.client.HttpClient;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.wbmi.agent.portal.common.executor.command.WebServiceRequestExecuteCommand;
import com.wbmi.agent.portal.common.executor.command.factory.WebServiceRequestExecutorCommandFactory;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;
import com.wbmi.agent.portal.internal.common.executor.impl.WebServiceRequestExecuteCommandImpl;

/**
 * @author Kaushik Mukherjee
 */
@Component(immediate = true, service = WebServiceRequestExecutorCommandFactory.class)
public class WebServiceRequestExecutorCommandFactoryImpl implements WebServiceRequestExecutorCommandFactory {

	@Override
	public WebServiceRequestExecuteCommand<String> createWebServiceRequestExecuteCommand(
		WebServiceRequest webServiceRequest) {

		WebServiceRequestExecuteCommand<String> webServiceRequestExecuteCommand =
			new WebServiceRequestExecuteCommandImpl(httpClient,webServiceRequest);

		return webServiceRequestExecuteCommand;
	}

	@Reference(target = "(name=defaultHttpClient)")
	protected HttpClient httpClient;
}
