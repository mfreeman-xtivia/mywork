package com.wbmi.agent.portal.internal.apim.executor.impl;

import java.io.File;
import java.io.Serializable;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.apim.executor.WebServiceExecutor;
import com.wbmi.agent.portal.cache.api.AgentPortalCache;
import com.wbmi.agent.portal.cache.model.PortalCacheMetadata;
import com.wbmi.agent.portal.common.executor.WebServiceRequestExecutor;
import com.wbmi.agent.portal.common.service.model.WebServiceMethod;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;
import com.wbmi.agent.portal.configuration.util.AzureAPIMConfigurationUtil;
import com.wbmi.agent.portal.exception.WebServiceException;

/**
 * Util class for making Web Service calls to APIM.
 *
 * @author Kaushik Mukherjee
 */
@Component(
	immediate = true, service = WebServiceExecutor.class
)
public class WebServiceExecutorImpl implements WebServiceExecutor {

	@Override
	public String executeGet(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL,String ...cacheKeyArgs ) throws PortalException {
		PortalCacheMetadata portalCacheMetadata = new PortalCacheMetadata(webServiceMethod.getCacheType(), webServiceMethod.getCacheName(), cacheKeyArgs);
		Serializable  cacheObject =  agentPortalCache.getFromCache(portalCacheMetadata);
		if (Validator.isNull(cacheObject)) {
			String fullURL = getURL(baseURL);

			HttpGet httpGet = new HttpGet(fullURL);

			WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(webServiceMethod.getName(), apiKey, httpGet, true);
			
			String response = webServiceRequestExecutor.execute(webServiceRequest);
			
			agentPortalCache.putInCache(portalCacheMetadata, response);
			
			return response;
		}

		return String.valueOf(cacheObject);
	}

	@Override
	public String executeMultipartPost(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, Map<String, String> requestParams,
			String fileParamName, Map<String, File> files) throws PortalException {

		String fullURL = getURL(baseURL);

		HttpPost httpPost = new HttpPost(fullURL);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();

		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

		for (Entry<String, File> entry : files.entrySet()) {
			builder.addPart(fileParamName, new FileBody(entry.getValue(), ContentType.DEFAULT_BINARY, entry.getKey()));
		}

		if (Validator.isNotNull(requestParams)) {
			for (Entry<String, String> entry : requestParams.entrySet()) {
				builder.addTextBody(entry.getKey(), entry.getValue());
			}
		}

		httpPost.setEntity(builder.build());

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(webServiceMethod.getName(), apiKey, httpPost, true);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	@Override
	public String executePost(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, String requestParam)
		throws PortalException {

		String fullURL = getURL(baseURL);

		HttpPost httpPost = new HttpPost(fullURL);

		_setRequestParam(requestParam, httpPost);

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(webServiceMethod.getName(), apiKey, httpPost, true);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	@Override
	public String executePut(
		long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, String requestParam) throws PortalException {

		String fullURL = getURL(baseURL);

		HttpPut httpPut = new HttpPut(fullURL);

		_setRequestParam(requestParam, httpPut);

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(webServiceMethod.getName(), apiKey, httpPut, true);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	protected String getBaseURL() {
		return AzureAPIMConfigurationUtil.apimBaseURL();
	}

	/**
	 * Get URL by appending configured Penguin Creek API base URL to given URL, if given URL is not absolute
	 */
	protected String getURL(String url) throws PortalException {
		String fullURL = url;

		String baseURL = getBaseURL();

		if (StringUtil.startsWith(url, CharPool.SLASH)) {
			if (Validator.isNull(baseURL)) {
				throw new WebServiceException(HttpServletResponse.SC_NOT_FOUND, "Unable to set location");
			}

			fullURL = baseURL + url;
		}

		if (Validator.isNull(fullURL)) {
			throw new WebServiceException(HttpServletResponse.SC_NOT_FOUND, "Unable to set location");
		}

		return fullURL;
	}

	@Reference
	protected WebServiceRequestExecutor webServiceRequestExecutor;
	
	@Reference 
	protected AgentPortalCache agentPortalCache;

	private void _setRequestParam(String requestParam, HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase) throws WebServiceException {
		if (Validator.isNotNull(requestParam)) {
			StringEntity entity = new StringEntity(requestParam, StringPool.UTF8);

			httpEntityEnclosingRequestBase.setEntity(entity);

			httpEntityEnclosingRequestBase.setHeader(HttpHeaders.ACCEPT, ContentTypes.APPLICATION_JSON);
			httpEntityEnclosingRequestBase.setHeader(HttpHeaders.CONTENT_TYPE, ContentTypes.APPLICATION_JSON);
		}
	}
}