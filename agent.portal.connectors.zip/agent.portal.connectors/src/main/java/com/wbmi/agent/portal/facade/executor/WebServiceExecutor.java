package com.wbmi.agent.portal.facade.executor;

import com.liferay.portal.kernel.exception.PortalException;

/**
 * @author Michael C. Han
 */
public interface WebServiceExecutor {

	public String executeGet(long companyId, String requestName, String baseURL, boolean azureAPIMRequest) throws PortalException;

	public String executePost(long companyId, String requestName, String baseURL, String requestParam, boolean azureAPIMRequest)
		throws PortalException;

	public String executePut(long companyId, String requestName, String baseURL, boolean azureAPIMRequest) throws PortalException;

}
