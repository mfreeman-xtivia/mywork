package com.wbmi.agent.portal.apim.executor;

import java.io.File;
import java.util.Map;

import com.liferay.portal.kernel.exception.PortalException;
import com.wbmi.agent.portal.common.service.model.WebServiceMethod;

/**
 * @author Michael C. Han
 */
public interface WebServiceExecutor {

	public String executeGet(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL,String ...cacheKeyArgs) throws PortalException;

	public String executeMultipartPost(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, Map<String, String> requestParams, String fileParamName, Map<String, File> files)
		throws PortalException;

	public String executePost(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, String requestParam)
		throws PortalException;

	public String executePut(long companyId, WebServiceMethod webServiceMethod,String apiKey, String baseURL, String requestParam) throws PortalException;

}
