package com.wbmi.agent.portal.common.service.model;

import java.util.HashMap;
import java.util.Map;

import com.wbmi.agent.portal.cache.constants.MultiVMCacheNames;
import com.wbmi.agent.portal.configuration.model.ErrorMessageCategoryEnum;

public enum WebServiceInterface {
	
	ACCOUNTS_PAST_DUE("AccountsPastDue",
		"Accounts Past  for Billing Account", MultiVMCacheNames.BILLING_CACHE.getCacheName(), 
		"com.wbmi.agent.portal.accounts.past.dues",ErrorMessageCategoryEnum.BILLING_ERROR.getCategory()),
	AGENCY_DIRECTORY("agencyDirectory",
		"Retrieves Agency Contact Details", MultiVMCacheNames.AGENCY_DIRECTORY.getCacheName(),
		"com.wbmi.agent.portal.agency.contacts",ErrorMessageCategoryEnum.RSM_ERROR.getCategory()),
	AGENCY_DETAILS("agencyDetails",
		"Gets Agency Details", MultiVMCacheNames.AGENCY_DETAILS.getCacheName(),
		"com.wbmi.agent.portal.agency.details",null),
	AGENCY_USER_DETAILS("agencies",
		"Gets Agency Details for Agent", MultiVMCacheNames.AGENCY_DETAILS.getCacheName(),
		"com.wbmi.agent.portal.agency.details",null),
	CONTINUING_EDUCATION("continuingeducation",
		"Retrieves the list of currently available courses", MultiVMCacheNames.CONTINUING_EDUCATION.getCacheName(),
		"com.wbmi.agent.portal.continuing.educations",ErrorMessageCategoryEnum.GENERAL_TECH_ERROR.getCategory()),
	CUSTOMER_DETAILS("customerDetail",
		"Retrieves Customer Details", MultiVMCacheNames.AGENCY_DIRECTORY.getCacheName(),
		"com.wbmi.agent.portal.customer.details",ErrorMessageCategoryEnum.RSM_ERROR.getCategory()),
	LAST_MONTH_CANCELLATION("LastMonthCancellations",
		"Last Month Cancellations for Billing Account", MultiVMCacheNames.BILLING_CACHE.getCacheName(),
		"com.wbmi.agent.portal.recent.cancellations",ErrorMessageCategoryEnum.BILLING_ERROR.getCategory()),
	RENEWALS_PAST_DUE("RenewalsPastDue",
		"Upcoming Renewals for Billing Accounts", MultiVMCacheNames.BILLING_CACHE.getCacheName(),
		"com.wbmi.agent.portal.upcoming.renewals",ErrorMessageCategoryEnum.BILLING_ERROR.getCategory()),
	START_QUOTE("newBusinessRollout",
		"Agency start quotes", MultiVMCacheNames.START_QUOTE.getCacheName(),
		"com.wbmi.agent.portal.start.quote.service",ErrorMessageCategoryEnum.UW_ERROR.getCategory()),
	CLAIMS_NEW("NewClaimsReports",
			"New Claims for Agency", MultiVMCacheNames.CLAIMS_REPORTS.getCacheName(),
			"com.wbmi.agent.portal.accounts.claims.reports.newclaims",ErrorMessageCategoryEnum.CLAIMS_REPORT_ERROR.getCategory()),
	CLAIMS_CLOSED("ClosedClaimsReports",
			"Closed Claims for Agency", MultiVMCacheNames.CLAIMS_REPORTS.getCacheName(),
			"com.wbmi.agent.portal.accounts.claims.reports.closedclaims",ErrorMessageCategoryEnum.CLAIMS_REPORT_ERROR.getCategory()),
	CLAIMS_PAYMENTS("PaidClaimsReports",
			"Paid Claims for Agency", MultiVMCacheNames.CLAIMS_REPORTS.getCacheName(),
			"com.wbmi.agent.portal.accounts.claims.reports.paidclaims",ErrorMessageCategoryEnum.CLAIMS_REPORT_ERROR.getCategory()),		
	MONITORING_SERVICE("Monitoring Service",
		"Health Check API for APIM services",null,null,null),
	NOTIFICATION_SERVICE("Notification Service",
		"Notification setup for agents",null,null,null);
	
	
	private WebServiceInterface(String requestName,String description,String cacheName,String cacheKeyIdentifier,String errorMessageCategory) {
		this.requestName = requestName;
		this.description = description;
		this.cacheName = cacheName;
		this.cacheKeyIdentifier = cacheKeyIdentifier;
		this.errorMessageCategory= errorMessageCategory;
	}
	
	public String getRequestName() {
		return requestName;
	}
	
	public String getCacheName() {
		return cacheName;
	}
	
	public String getDescription() {
		return description;
	}

	public String getCacheKeyIdentifier() {
		return cacheKeyIdentifier;
	}
	
	public String getErrorMessageCategory() {
		return errorMessageCategory;
	}
	
	/** 
	 *  Reverse Lookup Implementation
	 */
	// Lookup Table
	private static final Map<String,WebServiceInterface> lookup= new HashMap<>();
	
	// Populate the lookup table at loading Time
	static {
		for (WebServiceInterface web: WebServiceInterface.values()) {
			lookup.put(web.getRequestName(), web);
		}
	}
	
	//This method can be used for reverse lookup purpose 
	public static WebServiceInterface get(String requestName) {
		return lookup.get(requestName);
	}
	
	private String requestName;
	private String description;
	private String cacheName;
	private String cacheKeyIdentifier;
	private String errorMessageCategory;
}
