package com.wbmi.agent.portal.common.executor.command.factory;

import com.wbmi.agent.portal.common.executor.command.WebServiceRequestExecuteCommand;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;

public interface WebServiceRequestExecutorCommandFactory {

	public WebServiceRequestExecuteCommand<String> createWebServiceRequestExecuteCommand(
		WebServiceRequest webServiceRequest);

}
