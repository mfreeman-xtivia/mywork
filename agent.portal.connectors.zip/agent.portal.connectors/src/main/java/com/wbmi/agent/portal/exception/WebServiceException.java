package com.wbmi.agent.portal.exception;

import com.liferay.portal.kernel.exception.PortalException;

public class WebServiceException extends PortalException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6557891637961200793L;
	
	public WebServiceException() {
	}

	public WebServiceException(Exception e) {
		super(e);
	}

	public WebServiceException(int responseCode, String msg) {
		super(msg);

		_responseCode = responseCode;
	}

	public WebServiceException(int responseCode, String msg, String payload) {
		super(msg);

		_responseCode = responseCode;
		_payload = payload;
	}

	public WebServiceException(String msg) {
		super(msg);
	}

	public WebServiceException(String msg, Exception e) {
		super(msg, e);
	}

	public String getPayload() {
		return _payload;
	}

	public int getResponseCode() {
		return _responseCode;
	}

	@Override
	public String toString() {
		String s = getClass().getName();
		String message = getLocalizedMessage();

		if (message != null) {
			return s + ": Status Code " + _responseCode + " - " + message;
		}

		return s;
	}

	private String _payload;
	private int _responseCode;

}
