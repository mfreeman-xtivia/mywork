package com.wbmi.agent.portal.internal.common.http;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.pool.PoolStats;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.util.HashMapDictionary;
import com.liferay.portal.kernel.util.StringBundler;
import com.wbmi.agent.portal.configuration.connectivity.PoolingHttpClientFactoryConfiguration;

/**
 * @author kmukherjee
 */
@Component(
	configurationPid = "com.wbmi.agent.portal.configuration.connectivity.PoolingHttpClientFactoryConfiguration",
	immediate = true, service = PoolingHttpClientFactory.class
)
public class PoolingHttpClientFactory {

	@Activate
	protected synchronized void activate(BundleContext bundleContext, Map<String, Object> properties) {
		PoolingHttpClientFactoryConfiguration poolingHttpClientFactoryConfiguration =
			ConfigurableUtil.createConfigurable(PoolingHttpClientFactoryConfiguration.class, properties);
		logger.debug("PoolingHttpClientFactory.activate()");
		_poolingHttpClientConnectionManager = new PoolingHttpClientConnectionManager();

		_poolingHttpClientConnectionManager.setDefaultMaxPerRoute(
			poolingHttpClientFactoryConfiguration.defaultMaxConnectionsPerRoute());

		_poolingHttpClientConnectionManager.setMaxTotal(poolingHttpClientFactoryConfiguration.maxTotalConnections());

		HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();

		httpClientBuilder.setConnectionManager(_poolingHttpClientConnectionManager);

		RequestConfig requestConfig = RequestConfig.copy(RequestConfig.DEFAULT)
			.setConnectionRequestTimeout(poolingHttpClientFactoryConfiguration.connectionRequestTimeout())
			.build();

		httpClientBuilder.setDefaultRequestConfig(requestConfig);

		if (!poolingHttpClientFactoryConfiguration.contentCompressionEnabled()) {
			httpClientBuilder.disableContentCompression();
		}

		_closeableHttpClient = httpClientBuilder.build();

		Dictionary<String, String> httpClientProperties = new HashMapDictionary<>();
		httpClientProperties.put("name", "defaultHttpClient");

		_httpClientServiceRegistration = bundleContext.registerService(
			HttpClient.class, _closeableHttpClient, httpClientProperties);
	}

	@Deactivate
	protected synchronized void deactivate() {
		logger.debug("Shut down");

		if (_httpClientServiceRegistration != null) {
			_httpClientServiceRegistration.unregister();
		}

		if (_poolingHttpClientConnectionManager == null) {
			return;
		}

		int retry = 0;

		while (retry < _MAX_RETRIES) {
			PoolStats poolStats = _poolingHttpClientConnectionManager.getTotalStats();

			int availableConnections = poolStats.getAvailable();

			if (availableConnections <= 0) {
				break;
			}

			if (logger.isDebugEnabled()) {
				StringBundler sb = new StringBundler(_DEBUG_LOG_SIZE);

				sb.append(toString()).append(" is waiting on ");
				sb.append(String.valueOf(availableConnections));
				sb.append(" connections");

				logger.debug(sb.toString());
			}

			_poolingHttpClientConnectionManager.closeIdleConnections(
				_CONNECTION_MANAGER_CLOSE_TIMEOUT, TimeUnit.MILLISECONDS);

			try {
				synchronized (this) {
					wait(_SHUTDOWN_WAIT_TIMEOUT);
				}
			}
			catch (InterruptedException ie) {
				if (logger.isDebugEnabled()) {
					logger.debug(ie.getMessage(), ie);
				}
			}

			retry++;
		}

		_poolingHttpClientConnectionManager.shutdown();

		_poolingHttpClientConnectionManager = null;

		if (_closeableHttpClient != null) {
			try {
				_closeableHttpClient.close();
			}
			catch (IOException ioe) {
				if (logger.isInfoEnabled()) {
					logger.info(ioe.getMessage(), ioe);
				}
			}
		}

		_closeableHttpClient = null;

		logger.debug(toString() + " was shut down");
	}

	@Modified
	protected synchronized void modified(BundleContext bundleContext, Map<String, Object> properties) {
		deactivate();
		activate(bundleContext, properties);
	}

	private static final int _CONNECTION_MANAGER_CLOSE_TIMEOUT = 200;

	private static final int _DEBUG_LOG_SIZE = 4;

	private static final int _MAX_RETRIES = 10;

	private static final int _SHUTDOWN_WAIT_TIMEOUT = 500;

	private static final Logger logger = LoggerFactory.getLogger(PoolingHttpClientFactory.class);

	private CloseableHttpClient _closeableHttpClient;
	private ServiceRegistration<HttpClient> _httpClientServiceRegistration;
	private PoolingHttpClientConnectionManager _poolingHttpClientConnectionManager;

}
