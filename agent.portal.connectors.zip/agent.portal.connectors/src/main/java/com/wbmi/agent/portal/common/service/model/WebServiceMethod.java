package com.wbmi.agent.portal.common.service.model;

import com.liferay.portal.kernel.util.Http;
import com.wbmi.agent.portal.cache.constants.CacheTypeEnum;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum WebServiceMethod {

	ACCOUNTS_PAST_DUE(WebServiceInterface.ACCOUNTS_PAST_DUE, Http.Method.POST,
			"/Billing/Reports/AccountsPastDue", CacheTypeEnum.MULTI_VM_POOL),
	AGENCY_DIRECTORY(WebServiceInterface.AGENCY_DIRECTORY, Http.Method.GET,
			"/digital/agentportal/agencyDirectory/{agencyCode}", CacheTypeEnum.MULTI_VM_POOL),
	AGENCY_DETAILS(WebServiceInterface.AGENCY_DETAILS, Http.Method.GET, 
			"/digital/agentportal/agencyDetails", CacheTypeEnum.NONE),
	AGENCY_USER_DETAILS(WebServiceInterface.AGENCY_USER_DETAILS, Http.Method.GET, 
			"/digital/agentportal/agencies/{userId}", CacheTypeEnum.NONE),
	CONTINUING_EDUCATION(WebServiceInterface.CONTINUING_EDUCATION, Http.Method.GET,
			"/digital/agentportal/continuingeducation", CacheTypeEnum.MULTI_VM_POOL),
	CUSTOMER_DETAILS(WebServiceInterface.CUSTOMER_DETAILS, Http.Method.GET,
			"/digital/agentportal/customer/demographics/{customerNumber}/{policyNumber}/{indexType}", CacheTypeEnum.MULTI_VM_POOL),
	LAST_MONTH_CANCELLATION(WebServiceInterface.LAST_MONTH_CANCELLATION, Http.Method.POST, 
			"/Billing/Reports/LastMonthCancellations", CacheTypeEnum.MULTI_VM_POOL),
	RENEWALS_PAST_DUE(WebServiceInterface.RENEWALS_PAST_DUE, Http.Method.POST,
			"/Billing/Reports/RenewalsPastDue", CacheTypeEnum.MULTI_VM_POOL),
	START_QUOTE(WebServiceInterface.START_QUOTE,Http.Method.GET,
			"/digital/agentportal/newBusinessRollout", CacheTypeEnum.MULTI_VM_POOL),
	CLAIMS_NEW(WebServiceInterface.CLAIMS_NEW,Http.Method.POST,
			"/claims/edw/agency/newclaims", CacheTypeEnum.MULTI_VM_POOL),
	CLAIMS_CLOSED(WebServiceInterface.CLAIMS_CLOSED,Http.Method.POST,
			"/claims/edw/agency/closedclaims", CacheTypeEnum.MULTI_VM_POOL),
	CLAIMS_PAYMENTS(WebServiceInterface.CLAIMS_PAYMENTS,Http.Method.POST,
			"/claims/edw/agency/claimpayments", CacheTypeEnum.MULTI_VM_POOL),
	MONITORING_SERVICE_ALL(WebServiceInterface.MONITORING_SERVICE, Http.Method.GET,
			"/digital/monitor/source",CacheTypeEnum.NONE),
	MONITORING_SERVICE(WebServiceInterface.MONITORING_SERVICE, Http.Method.GET,
			"/digital/monitor/source/{serviceName}",CacheTypeEnum.NONE),
	MONITORING_SERVICE_POST(WebServiceInterface.MONITORING_SERVICE, Http.Method.POST,
			"/digital/monitor/source",CacheTypeEnum.NONE),
	MONITORING_SERVICE_PUT(WebServiceInterface.MONITORING_SERVICE, Http.Method.PUT,
			"/digital/monitor/source/{sourceName}",CacheTypeEnum.NONE),
	MONITORING_SERVICE_DELETE(WebServiceInterface.MONITORING_SERVICE, Http.Method.DELETE,
			"/digital/monitor/source/{sourceName}",CacheTypeEnum.NONE),
	NOTIFICATION_SERVICE(WebServiceInterface.MONITORING_SERVICE, Http.Method.POST,
			"/digital/monitor/Notificaton/",CacheTypeEnum.NONE);

	
	public WebServiceInterface getWebServiceInterface() {
		return _webServiceInterface;
	}

	public String getDescription() {
		return _description;
	}

	public Http.Method getMethod() {
		return _method;
	}

	public String getName() {
		return _name;
	}

	public String getUrl() {
		return _url;
	}

	public CacheTypeEnum getCacheType() {
		return _cacheType;
	}
	
	public String getCacheName() {
		return _cacheName;
	}
	
	public String getCacheKeyIdentifier() {
		return _cacheKeyIdentifier;
	}

	private WebServiceMethod(WebServiceInterface webServiceInterface, Http.Method method,String url,CacheTypeEnum cacheType) {

		_webServiceInterface = webServiceInterface;
		_name = webServiceInterface.getRequestName();
		_method = method;
		_description = webServiceInterface.getDescription();
		_cacheName = webServiceInterface.getCacheName();
		_cacheKeyIdentifier = webServiceInterface.getCacheKeyIdentifier();
		_url = url;
		_cacheType = cacheType;
	}

	private static final Map<String, WebServiceMethod> _nameToEnumMap = new HashMap<>();

	static {
		for (WebServiceMethod value : EnumSet.allOf(WebServiceMethod.class)) {
			_nameToEnumMap.put(value.name(), value);
		}
	}

	private String _description;
	private Http.Method _method;
	private String _name;
	private String _url;
	private String _cacheName;
	private String _cacheKeyIdentifier;
	private WebServiceInterface _webServiceInterface;
	private CacheTypeEnum _cacheType;
}
