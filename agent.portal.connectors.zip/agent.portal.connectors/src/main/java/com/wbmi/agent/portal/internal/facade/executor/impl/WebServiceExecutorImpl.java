package com.wbmi.agent.portal.internal.facade.executor.impl;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.petra.string.CharPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.common.executor.WebServiceRequestExecutor;
import com.wbmi.agent.portal.common.service.model.WebServiceRequest;
import com.wbmi.agent.portal.configuration.util.PortalFacadeConfigurationUtil;
import com.wbmi.agent.portal.exception.WebServiceException;
import com.wbmi.agent.portal.facade.executor.WebServiceExecutor;

/**
 * Util class for making Web Service calls to Portal Facade Service.
 *
 * @author Kaushik Mukherjee
 */
@Component(
    immediate = true,
	service = WebServiceExecutor.class
)
public class WebServiceExecutorImpl implements WebServiceExecutor {

	@Override
	public String executeGet(long companyId, String requestName, String baseURL, boolean azureAPIMRequest) throws PortalException {
		String fullURL = getURL(baseURL, azureAPIMRequest);

		HttpGet httpGet = new HttpGet(fullURL);

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(requestName, getAPIKey(azureAPIMRequest), httpGet, azureAPIMRequest);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	@Override
	public String executePost(long companyId, String requestName, String baseURL, String requestParam, boolean azureAPIMRequest)
		throws PortalException {

		String fullURL = getURL(baseURL, azureAPIMRequest);

		HttpPost httpPost = new HttpPost(fullURL);

		try {
			if (Validator.isNotNull(requestParam)) {
				StringEntity entity = new StringEntity(requestParam);

				httpPost.setEntity(entity);

				httpPost.setHeader(HttpHeaders.ACCEPT, ContentTypes.APPLICATION_JSON);
				httpPost.setHeader(HttpHeaders.CONTENT_TYPE, ContentTypes.APPLICATION_JSON);
			}
		}
		catch (IOException ioe) {
			throw new WebServiceException(ioe);
		}

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(requestName, getAPIKey(azureAPIMRequest), httpPost, azureAPIMRequest);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	@Override
	public String executePut(long companyId, String requestName, String baseURL, boolean azureAPIMRequest) throws PortalException {
		String fullURL = getURL(baseURL, azureAPIMRequest);

		HttpPut httpPut = new HttpPut(fullURL);

		httpPut.setHeader(HttpHeaders.ACCEPT, ContentTypes.APPLICATION_JSON);

		WebServiceRequest webServiceRequest = WebServiceRequest.createWebServiceRequest(requestName, getAPIKey(azureAPIMRequest), httpPut, azureAPIMRequest);

		return webServiceRequestExecutor.execute(webServiceRequest);
	}

	/**
	 * Get API Key for WBMI Services
	 */
	protected String getAPIKey(boolean azureAPIMRequest) throws PortalException {
		if (Validator.isNull(PortalFacadeConfigurationUtil.getWbmiApiKey())) {
			throw new WebServiceException(HttpServletResponse.SC_UNAUTHORIZED, "Unable to set authorization header");
		}

		if (azureAPIMRequest) {
			return PortalFacadeConfigurationUtil.getWbmiAzureApiSubscriptionKey();
		} else {
			return PortalFacadeConfigurationUtil.getWbmiApiKey();
		}
	}

	/**
	 * Get URL by appending configured WBMI API base URL to given URL, if given URL is not absolute
	 */
	protected String getURL(String url, boolean azureAPIMRequest) throws PortalException {
		String fullURL = url;

		if (StringUtil.startsWith(url, CharPool.SLASH)) {
			if (Validator.isNull(PortalFacadeConfigurationUtil.getWbmiBaseURL())) {
				throw new WebServiceException(HttpServletResponse.SC_NOT_FOUND, "Unable to set location");
			}

			if (azureAPIMRequest) {
				fullURL = PortalFacadeConfigurationUtil.getWbmiAzureApiBaseURL() + url;
			} else {
				fullURL = PortalFacadeConfigurationUtil.getWbmiBaseURL() + url;
			}
		}

		if (Validator.isNull(fullURL)) {
			throw new WebServiceException(HttpServletResponse.SC_NOT_FOUND, "Unable to set location");
		}

		return fullURL;
	}

	@Reference
	protected WebServiceRequestExecutor webServiceRequestExecutor;

}
