package com.wbmi.agent.portal.agency.internal.model;

import java.io.Serializable;

public class AgencyDetailsResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5864109662390027477L;
	private String agencyName;
	private String agencyCode;
	private String parentAgencyCode;
	
	
	public AgencyDetailsResponse() {
		
	}
	
	public AgencyDetailsResponse(String agencyName,String agencyCode, String parentAgencyCode) {
		this.agencyCode = agencyCode;
		this.agencyName = agencyName;
		this.parentAgencyCode = parentAgencyCode;
	}
	
	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}
	/**
	 * @param agencyName the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	/**
	 * @return the agencyCode
	 */
	public String getAgencyCode() {
		return agencyCode;
	}
	/**
	 * @param agencyCode the agencyCode to set
	 */
	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}
	/**
	 * @return the parentAgencyCode
	 */
	public String getParentAgencyCode() {
		return parentAgencyCode;
	}
	/**
	 * @param parentAgencyCode the parentAgencyCode to set
	 */
	public void setParentAgencyCode(String parentAgencyCode) {
		this.parentAgencyCode = parentAgencyCode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencyCode == null) ? 0 : agencyCode.hashCode());
		result = prime * result + ((agencyName == null) ? 0 : agencyName.hashCode());
		result = prime * result + ((parentAgencyCode == null) ? 0 : parentAgencyCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgencyDetailsResponse other = (AgencyDetailsResponse) obj;
		if (agencyCode == null) {
			if (other.agencyCode != null)
				return false;
		} else if (!agencyCode.equals(other.agencyCode))
			return false;
		if (agencyName == null) {
			if (other.agencyName != null)
				return false;
		} else if (!agencyName.equals(other.agencyName))
			return false;
		if (parentAgencyCode == null) {
			if (other.parentAgencyCode != null)
				return false;
		} else if (!parentAgencyCode.equals(other.parentAgencyCode))
			return false;
		return true;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AgencyDetailsResponse [");
		if (agencyName != null)
			builder.append("agencyName=").append(agencyName).append(", ");
		if (agencyCode != null)
			builder.append("agencyCode=").append(agencyCode).append(", ");
		if (parentAgencyCode != null)
			builder.append("parentAgencyCode=").append(parentAgencyCode);
		builder.append("]");
		return builder.toString();
	}
}
