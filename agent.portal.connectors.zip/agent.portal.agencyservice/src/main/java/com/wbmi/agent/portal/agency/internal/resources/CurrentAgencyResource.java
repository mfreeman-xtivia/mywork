package com.wbmi.agent.portal.agency.internal.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.model.UserGroup;
import com.liferay.portal.kernel.model.UserGroupRole;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.agency.detail.model.AgencyDetails;
import com.wbmi.agent.portal.agency.enums.OrgCustomFields;
import com.wbmi.agent.portal.agency.enums.UserCustomFields;
import com.wbmi.agent.portal.agency.internal.resources.common.CommonAgencyResource;
import com.wbmi.agent.portal.configuration.util.MockServiceConfigurationUtil;

@Component(immediate=true, service = CurrentAgencyResource.class)
public class CurrentAgencyResource extends CommonAgencyResource {
	
	public String[] retrieveBillingAgencyCode(User user, HttpServletRequest request,Boolean isOriginalServletRequest) {
		AgencyDetails agencyDetails = retrieveAgencyDetail(user.getUserId(),request,isOriginalServletRequest);
		if(agencyDetails.getIsParentAgency()) {
			List<Organization> orgList = organizationLocalService.getOrganizations(user.getCompanyId(), agencyDetails.getOrganizationId());
			List<String> agencyCodeList=  orgList.stream().map(org -> {
				Object obj = org.getExpandoBridge().getAttribute(OrgCustomFields.AGENCY_CODE.getKey(), Boolean.FALSE);
				if (Validator.isNotNull(obj)){
					return (String) obj; 
				} 
				return null;
			}).filter(str -> Validator.isNotNull(str)).collect(Collectors.toList());
			agencyCodeList.add(agencyDetails.getAgencyCode());
			return agencyCodeList.toArray(String[]::new);
		}
		return new String[]{agencyDetails.getAgencyCode()};
	}
	
	public String retrieveAgencyCode(long userId,HttpServletRequest request, Boolean isOriginalServletRequest, Boolean returnDefault) {
		if (!MockServiceConfigurationUtil.mockAgencyCodeEnabled()) {
			AgencyDetails cacheData = retrieveAgencyDetail(userId, request,isOriginalServletRequest) ;
			if (Validator.isNotNull(cacheData)) {
				return cacheData.getAgencyCode();
			} else if(!returnDefault) {
				return null;
			}
		} 
		return MockServiceConfigurationUtil.mockAgencyCode();
	}
	
	public AgencyDetails retrieveAgencyDetail(long userId,HttpServletRequest request, Boolean isOriginalServletRequest) {
		HttpServletRequest originalRequest = request;
		if (!isOriginalServletRequest) {
			originalRequest = PortalUtil.getOriginalServletRequest(request);
		}
		Object sz = originalRequest.getSession().getAttribute(SHARED_AGENCY);
		if (Validator.isNotNull(sz)) {
			try {
				return objectMapper.readValue((String) sz,AgencyDetails.class);
			} catch (JsonProcessingException e) {
				logger.error(e.getMessage(), e);
			}
		}
		return new AgencyDetails();
	}
	
	
	public AgencyDetails storeAgencyDetails(User user, String friendlyUrl, long orgId,HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException {
		Organization organization = organizationLocalService.getOrganization(orgId);
		agentPortalGroup = retriveGroup(agentPortalGroup, user.getCompanyId(), friendlyUrl);
		return storeAgencyDetails(user,agentPortalGroup.getGroupId(),organization,request,isOriginalServletRequest);
	}

	public AgencyDetails storeAgencyDetails(User user, String friendlyUrl, List<Organization> orgList,HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException {
		agentPortalGroup = retriveGroup(agentPortalGroup, user.getCompanyId(), friendlyUrl);
		Organization organization = findDefaultAgency(user);
		getAgenciesOrganization(organization.getCompanyId());
		if (Validator.isNull(organization)) {
			organization = findParentOrg(orgList);
		}
		return storeAgencyDetails(user,agentPortalGroup.getGroupId(),organization,request,isOriginalServletRequest);
	}


	private Organization findDefaultAgency(User user) {
		String defaultAgencyCode = (String) user.getExpandoBridge().getAttribute(UserCustomFields.DEFAULT_AGENCYID.getKey(),Boolean.FALSE);
		return findOrganizationFromAgencyCode(defaultAgencyCode);
	}

	public AgencyDetails storeAgencyDetails(long userId, AgencyDetails agencyData,HttpServletRequest request, Boolean isOriginalServletRequest) {
		HttpServletRequest originalRequest = request;
		if (!isOriginalServletRequest) {
			originalRequest = PortalUtil.getOriginalServletRequest(request);
		}
		originalRequest.getSession().setAttribute(SHARED_AGENCY, agencyData.toString());
		return agencyData;
	}
	
	public AgencyDetails storeAgencyDetails(User user,long groupId, long orgId,HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException {
		Organization organization = organizationLocalService.getOrganization(orgId);
		return storeAgencyDetails(user,groupId,organization,request,isOriginalServletRequest);
	}
	
	
	public AgencyDetails storeAgencyDetails(User user,long groupId, Organization organization,HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException {
		logger.info("AgencyDetailServiceImpl.storeAgencyDetails()");
		retrieveRoleDetails(user.getCompanyId());
		retrieveUserGroupDetails(user.getCompanyId());
		
		// Get Organization Custom Field Values to Determine what Site Roles will be added or deleted for the Agent
		String agencyCode = (String) organization.getExpandoBridge().getAttribute(OrgCustomFields.AGENCY_CODE.getKey(), Boolean.FALSE);
		Boolean isCL = (Boolean) organization.getExpandoBridge().getAttribute(OrgCustomFields.COMMERCIAL_LINES.getKey(), Boolean.FALSE);
		Boolean isPL = (Boolean) organization.getExpandoBridge().getAttribute(OrgCustomFields.PERSONAL_LINES.getKey(), Boolean.FALSE);
		Boolean isBond = (Boolean) organization.getExpandoBridge().getAttribute(OrgCustomFields.BONDS.getKey(), Boolean.FALSE);
		Boolean isArgent = (Boolean) organization.getExpandoBridge().getAttribute(OrgCustomFields.ARGENT.getKey(), Boolean.FALSE);
		Boolean isSL = (Boolean) organization.getExpandoBridge().getAttribute(OrgCustomFields.SPECIALTY_LINES.getKey(), Boolean.FALSE);
		
		addRemoveAgentsSiteRoles(user, groupId, isPL, isCL, isBond, isArgent, isSL);
		
		addRemoveAgentsUserGroups(user, organization);
		
		Boolean hasPrincipal = userGroupRoleLocalService.hasUserGroupRole(user.getUserId(), agentPortalGroup.getGroupId(), principal.getRoleId(),Boolean.TRUE);
		Boolean hasProducer = userGroupRoleLocalService.hasUserGroupRole(user.getUserId(), agentPortalGroup.getGroupId(), producer.getRoleId(),Boolean.TRUE);
		Boolean hasAgencySupport = userGroupRoleLocalService.hasUserGroupRole(user.getUserId(), agentPortalGroup.getGroupId(), agencySupport.getRoleId(),Boolean.TRUE);
		Boolean isWBMI = isWBMIUser(user);
		
		AgencyDetails agencyCacheData = new AgencyDetails(agencyCode,organization.getName(),null,isPL,isCL,isSL,
					isArgent, isBond, organization.getOrganizationId(),parentOrganization.getOrganizationId(), isParentAgency(organization),
					isWBMI || hasAgencySupport,isWBMI || hasPrincipal,isWBMI || hasProducer);
		storeAgencyDetails(user.getUserId(), agencyCacheData,request,isOriginalServletRequest);
		
		return agencyCacheData;
	}
	
	/**
	 * @param user
	 * @param groupId
	 * @param isPL
	 * @param isCL
	 * @param isBond
	 * @param isArgent
	 * @param isSL
	 * @throws PortalException
	 */
	private void addRemoveAgentsSiteRoles(User user, long groupId, Boolean isPL, Boolean isCL, Boolean isBond,
			Boolean isArgent, Boolean isSL) throws PortalException {
		List<Long> roletoAddList = new ArrayList<Long>();
		List<Long> rolestoDeleteList = new ArrayList<Long>();
		
		List<UserGroupRole> userGroupRoles = userGroupRoleLocalService.getUserGroupRoles(user.getUserId(),groupId);
		
		Boolean hasPLRole = checkGroupRole(personalLines,userGroupRoles);
		Boolean hasCLRole = checkGroupRole(commercialLines,userGroupRoles);
		Boolean hasSLRole = checkGroupRole(specialtyLines,userGroupRoles);
		Boolean hasBondRole = checkGroupRole(bonds,userGroupRoles);
		Boolean hasArgentRole = checkGroupRole(argent,userGroupRoles);
		
		determineRolestoAddandDelete(isPL,hasPLRole, personalLines,roletoAddList, rolestoDeleteList);
		determineRolestoAddandDelete(isCL,hasCLRole,commercialLines,roletoAddList, rolestoDeleteList);
		determineRolestoAddandDelete(isSL,hasSLRole, specialtyLines,roletoAddList, rolestoDeleteList);
		determineRolestoAddandDelete(isBond,hasBondRole, bonds,roletoAddList, rolestoDeleteList);
		determineRolestoAddandDelete(isArgent,hasArgentRole, argent,roletoAddList, rolestoDeleteList);
		
		removeUserGroupRole(user.getUserId(),groupId,rolestoDeleteList.stream().mapToLong(l -> l).toArray());
		addUserGroupRole(user.getUserId(),groupId,roletoAddList.stream().mapToLong(l -> l).toArray());
	}

	/**
	 * @param user
	 * @param organization
	 * @throws PortalException
	 */
	private void addRemoveAgentsUserGroups(User user, Organization organization) throws PortalException {
		// Determine what user group(e.g. Producer User Group or Principal User Group ) the agent will be part of in the target Agency
		if(!isWBMIUser(user)) {
			List<UserGroup> userGroups =  user.getUserGroups();
			List<UserGroupRole> orgRoles = userGroupRoleLocalService.getUserGroupRoles(user.getUserId(),organization.getGroupId());
			
			List<Long> userGroupstoAddList = new ArrayList<Long>();
			List<Long> userGroupstoDeleteList = new ArrayList<Long>();
			
			Boolean isPrincipal = hasRole(orgPrincipal,orgRoles);
			Boolean isProducer = hasRole(orgProducer,orgRoles);
			Boolean isAgencySupport = hasRole(orgAgencySupport,orgRoles);
			
			Boolean hasPrincipalUserGroup = checkUserGroup(principalUserGroup,userGroups);
			Boolean hasProducerUserGroup = checkUserGroup(producerUserGroup,userGroups);
			Boolean hasAgencySupportUserGroup = checkUserGroup(agencySupportUserGroup,userGroups);
			
			determineUserGroupstoAddandDelete(isPrincipal,hasPrincipalUserGroup, principalUserGroup,userGroupstoAddList, userGroupstoDeleteList);
			determineUserGroupstoAddandDelete(isProducer,hasProducerUserGroup, producerUserGroup,userGroupstoAddList, userGroupstoDeleteList);
			determineUserGroupstoAddandDelete(isAgencySupport,hasAgencySupportUserGroup, agencySupportUserGroup,userGroupstoAddList, userGroupstoDeleteList);
			
			removeUserGroups(user.getUserId(), userGroupstoDeleteList.stream().mapToLong(l -> l).toArray());
			addUserGroups(user.getUserId(), userGroupstoAddList.stream().mapToLong(l -> l).toArray());
			
		}
	}
	
	private static final Logger logger = LoggerFactory.getLogger(CurrentAgencyResource.class);

}
