package com.wbmi.agent.portal.agency.enums;

public enum OrgCustomFields {
	
	PERSONAL_LINES("personal_lines",1L),
	COMMERCIAL_LINES("commercial_lines",2L),
	SPECIALTY_LINES("specialty_lines",3L),
	ARGENT("argent",4L),
	BONDS("bonds",5L),
	AGENCY_CODE("agency_code",6L);
	
	private final String key;
	private final Long id;

	/**
	 * @param text
	 */
	private OrgCustomFields(final String key, final Long id) {
		this.key = key;
		this.id = id;
	}

	public String getKey() {
		return key;
	}
	
	public Long getId() {
		return id;
	}
	
}
