package com.wbmi.agent.portal.agency.internal.resources;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.agency.enums.UserCustomFields;
import com.wbmi.agent.portal.agency.internal.model.AgencyDetailsResponse;
import com.wbmi.agent.portal.agency.internal.model.GetAgenciesResponse;
import com.wbmi.agent.portal.agency.internal.resources.common.CommonAgencyResource;
import com.wbmi.agent.portal.common.service.model.WebServiceMethod;
import com.wbmi.agent.portal.configuration.util.AzureAPIMConfigurationUtil;
import com.wbmi.agent.portal.configuration.util.MockServiceConfigurationUtil;
import com.wbmi.agent.portal.exception.WebServiceException;

@Component(immediate=true,service=UserAgencySyncResource.class)
public class UserAgencySyncResource extends CommonAgencyResource {

	public User syncAgenciesForAgent(User user) throws PortalException {
		logger.info("UserAgencySyncResource.syncAgenciesForAgent()");
		GetAgenciesResponse agencies  = null;
		Boolean isMockingEnabled = MockServiceConfigurationUtil.agencyMockingEnabled();
		if (isMockingEnabled) {
			agencies =  createMockResponse(user);
		} else {
			agencies = retrieveAgencyDetails(user);
		}
		return updateUserAssignments(agencies,user);
	}
	
	private GetAgenciesResponse retrieveAgencyDetails(User user) throws WebServiceException {
		logger.info("UserAgencySyncResource.retrieveAgencyDetails()");
		String apiKey = AzureAPIMConfigurationUtil.agencyServiceApiKey();
		GetAgenciesResponse agencies  = null;
		try {
			String wbmiUserId = getWbmiUserId(user);
			if(Validator.isNull(wbmiUserId)) {
				throw new WebServiceException("Doesn't have WBMI UserId");
			}
			String url = StringUtil.replace( WebServiceMethod.AGENCY_USER_DETAILS.getUrl(),"{userId}", wbmiUserId);
			String response = _webServiceExecutor.executeGet(user.getCompanyId(), WebServiceMethod.AGENCY_USER_DETAILS,
					apiKey, url,WebServiceMethod.AGENCY_USER_DETAILS.getCacheKeyIdentifier());
			logger.debug("UserAgencySyncResource.retrieveAgencyDetails() {}", response);
			agencies = objectMapper.readValue(response, GetAgenciesResponse.class);
		} catch (Exception e) {
			throw new WebServiceException("Retrieving Agent Information failed" , e );
		}
		return agencies;
	}
	
	private GetAgenciesResponse createMockResponse(User user) throws WebServiceException {
		logger.debug("UserAgencySyncResource.createMockResponse()");
		URL mockJsonFileUrl = agentMockJsonFileUrl;
		if(isInternalUser(user)) {
			mockJsonFileUrl = wbmiMockJsonFileUrl;
		}
		try (InputStream inputStream = mockJsonFileUrl.openStream()) {
			String mockResponse = StringUtil.read(inputStream);
			return objectMapper.readValue(mockResponse, GetAgenciesResponse.class);
		} catch (IOException ioe) {
			throw new WebServiceException("Could not return default response for mock service", ioe);
		} catch (Exception e) {
			throw new WebServiceException("Could not return default response for mock service", e);
		}
	}
	

	private User updateUserAssignments(GetAgenciesResponse agencies, User user) throws PortalException {
		try {
			retrieveRoleDetails(user.getCompanyId());
			retrieveUserGroupDetails(user.getCompanyId());
			AgencyDetailsResponse[] relatedAgencies = agencies.getRelatedAgencies();
			removeExistingOrgs(user);	
			List<Organization> orgList = new ArrayList<>();
			setDefaultAgencyId(agencies,user);
			for (AgencyDetailsResponse agency : relatedAgencies) {
				Organization org = findOrganizationFromAgencyCode(agency);
				if(Validator.isNotNull(org)) {
					orgList.add(org);	
				}
			}
			if(orgList.size() > 0) {
				organizationLocalService.addUserOrganizations(user.getUserId(), orgList);
			}
			if(!agencies.getIsAgent()) {
				List<Long> userGroupstoAddList = new ArrayList<Long>();
				userGroupstoAddList.add(wbmiUserGroup.getUserGroupId());
				addUserGroups(user.getUserId(), userGroupstoAddList.stream().mapToLong(l -> l).toArray());
			} else {
				for(Organization org: orgList) {
					List<Long> roletoAddList = new ArrayList<Long>();
					roletoAddList.add(orgProducer.getRoleId());
					// TODO : When Roles are available map proper roles
					addUserGroupRole(user.getUserId(), org.getGroupId(), roletoAddList.stream().mapToLong(l -> l).toArray());
				}
			}
			return  userLocalService.fetchUser(user.getUserId());	
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			throw new PortalException(e.getMessage());
		}
	}
	
	private void setDefaultAgencyId(GetAgenciesResponse agencies, User user) {
		user.getExpandoBridge().setAttribute(UserCustomFields.DEFAULT_AGENCYID.getKey(), agencies.getAgency().getAgencyCode(), Boolean.FALSE);
		userLocalService.updateUser(user);
	}

	private void removeExistingOrgs(User user) {
		try {
			List<Organization> organizations = user.getOrganizations();
			organizationLocalService.deleteUserOrganizations(user.getUserId(), organizations);
		} catch (PortalException e) {
			logger.info("User {} doesn't have any org associate", user.getFullName());
		}
	}

	private String getWbmiUserId(User user) {
		return removeDomain(getWbmiUserIdCustomFieldValue(user));
	}

	/**
	 * @param user
	 */
	private String getWbmiUserIdCustomFieldValue(User user) {
		if(Validator.isNotNull(user.getExpandoBridge().getAttribute(UserCustomFields.WBMI_USERID.getKey(),Boolean.FALSE))) {
			return ((String) user.getExpandoBridge().getAttribute(UserCustomFields.WBMI_USERID.getKey(),Boolean.FALSE));
		}
		
		return null;
	}
	
	private String removeDomain(String userId) {
		if(Validator.isNull(userId)) {
			return null;
		}
		String[] userIds = splitWBMIUserId(userId);
		if(userIds.length > 1) {
			return userIds[1];
		}
		return null;
	}
	
	private Boolean isInternalUser(User user) {
		String wbmiUserId =  getWbmiUserIdCustomFieldValue(user);
		if(Validator.isNull(wbmiUserId)) {
			return Boolean.FALSE;
		}
		String[] userIds = splitWBMIUserId(wbmiUserId);
		if(userIds.length <= 1) {
			return Boolean.FALSE;
		}
		if("wbmi".equalsIgnoreCase(userIds[0])) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}


	/**
	 * @param userId
	 * @return
	 */
	private String[] splitWBMIUserId(String userId) {
		return userId.split(Pattern.quote(StringPool.BACK_SLASH));
	}
	
	
	@Activate
	protected void activate(BundleContext bundleContext, Map<String, Object> properties) {
		logger.debug("UserAgencySyncResource.activate()");
		Bundle bundle = bundleContext.getBundle();
		agentMockJsonFileUrl = bundle.getResource(AGENCT_MOCK_RESPONSE_JSON_FILE);
		wbmiMockJsonFileUrl = bundle.getResource(WBMI_USER_MOCK_RESPONSE_JSON_FILE);
	}


	private ObjectMapper objectMapper = new ObjectMapper();

	private URL agentMockJsonFileUrl;
	
	private URL wbmiMockJsonFileUrl;
	
	private static final String AGENCT_MOCK_RESPONSE_JSON_FILE = "/META-INF/default-ws-responses/GetAgenciesForAgent.json";
	
	private static final String WBMI_USER_MOCK_RESPONSE_JSON_FILE = "/META-INF/default-ws-responses/GetAgenciesForWBMIUser.json";
	
	private static final Logger logger = LoggerFactory.getLogger(UserAgencySyncResource.class);
}
