package com.wbmi.agent.portal.agency.detail.model;

import java.io.Serializable;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AgencyDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4790491379272933824L;
	private String agencyCode;
	private String agencyName;
	private String state;
	private Boolean isPL;
	private Boolean isCL;
	private Boolean isSL;
	private Boolean isArgent;
	private Boolean isBond;
	private Long organizationId;
	private Long parentOrganizationId;
	private Boolean isParentAgency;
	private Boolean isAgencySupport;
	private Boolean isPrincipal;
	private Boolean isProducer;
	
	public AgencyDetails() {
	}
	
	public AgencyDetails(String agencyCode, String agencyName, String state, Boolean isPL, Boolean isCL, Boolean isSL,
			Boolean isArgent, Boolean isBond, Long organizationId, Long parentOrganizationId, Boolean isParentAgency,
			Boolean isAgencySupport, Boolean isPrincipal, Boolean isProducer) {
		this.agencyCode = agencyCode;
		this.agencyName = agencyName;
		this.state = state;
		this.isPL = isPL;
		this.isCL = isCL;
		this.isSL = isSL;
		this.isArgent = isArgent;
		this.isBond = isBond;
		this.organizationId = organizationId;
		this.parentOrganizationId = parentOrganizationId;
		this.isParentAgency = isParentAgency;
		this.isAgencySupport = isAgencySupport;
		this.isPrincipal = isPrincipal;
		this.isProducer = isProducer;
	}


	/**
	 * @return the agencyCode
	 */
	public String getAgencyCode() {
		return agencyCode;
	}

	/**
	 * @param agencyCode the agencyCode to set
	 */
	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * @param agencyName the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the isPL
	 */
	public Boolean getIsPL() {
		return isPL;
	}

	/**
	 * @param isPL the isPL to set
	 */
	public void setIsPL(Boolean isPL) {
		this.isPL = isPL;
	}

	/**
	 * @return the isCL
	 */
	public Boolean getIsCL() {
		return isCL;
	}

	/**
	 * @param isCL the isCL to set
	 */
	public void setIsCL(Boolean isCL) {
		this.isCL = isCL;
	}

	/**
	 * @return the isSL
	 */
	public Boolean getIsSL() {
		return isSL;
	}

	/**
	 * @param isSL the isSL to set
	 */
	public void setIsSL(Boolean isSL) {
		this.isSL = isSL;
	}

	/**
	 * @return the isArgent
	 */
	public Boolean getIsArgent() {
		return isArgent;
	}

	/**
	 * @param isArgent the isArgent to set
	 */
	public void setIsArgent(Boolean isArgent) {
		this.isArgent = isArgent;
	}

	/**
	 * @return the isBond
	 */
	public Boolean getIsBond() {
		return isBond;
	}

	/**
	 * @param isBond the isBond to set
	 */
	public void setIsBond(Boolean isBond) {
		this.isBond = isBond;
	}

	/**
	 * @return the organizationId
	 */
	public Long getOrganizationId() {
		return organizationId;
	}

	/**
	 * @param organizationId the organizationId to set
	 */
	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}
	
	/**
	 * @return the parentOrganizationId
	 */
	public Long getParentOrganizationId() {
		return parentOrganizationId;
	}

	/**
	 * @param parentOrganizationId the parentOrganizationId to set
	 */
	public void setParentOrganizationId(Long parentOrganizationId) {
		this.parentOrganizationId = parentOrganizationId;
	}

	/**
	 * @return the isParentAgency
	 */
	public Boolean getIsParentAgency() {
		return isParentAgency;
	}

	/**
	 * @param isParentAgency the isParentAgency to set
	 */
	public void setIsParentAgency(Boolean isParentAgency) {
		this.isParentAgency = isParentAgency;
	}


	/**
	 * @return the isAgencySupport
	 */
	public Boolean getIsAgencySupport() {
		return isAgencySupport;
	}

	/**
	 * @param isAgencySupport the isAgencySupport to set
	 */
	public void setIsAgencySupport(Boolean isAgencySupport) {
		this.isAgencySupport = isAgencySupport;
	}

	/**
	 * @return the isPrincipal
	 */
	public Boolean getIsPrincipal() {
		return isPrincipal;
	}

	/**
	 * @param isPrincipal the isPrincipal to set
	 */
	public void setIsPrincipal(Boolean isPrincipal) {
		this.isPrincipal = isPrincipal;
	}

	/**
	 * @return the isProducer
	 */
	public Boolean getIsProducer() {
		return isProducer;
	}

	/**
	 * @param isProducer the isProducer to set
	 */
	public void setIsProducer(Boolean isProducer) {
		this.isProducer = isProducer;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencyCode == null) ? 0 : agencyCode.hashCode());
		result = prime * result + ((agencyName == null) ? 0 : agencyName.hashCode());
		result = prime * result + ((isAgencySupport == null) ? 0 : isAgencySupport.hashCode());
		result = prime * result + ((isArgent == null) ? 0 : isArgent.hashCode());
		result = prime * result + ((isBond == null) ? 0 : isBond.hashCode());
		result = prime * result + ((isCL == null) ? 0 : isCL.hashCode());
		result = prime * result + ((isPL == null) ? 0 : isPL.hashCode());
		result = prime * result + ((isParentAgency == null) ? 0 : isParentAgency.hashCode());
		result = prime * result + ((isPrincipal == null) ? 0 : isPrincipal.hashCode());
		result = prime * result + ((isProducer == null) ? 0 : isProducer.hashCode());
		result = prime * result + ((isSL == null) ? 0 : isSL.hashCode());
		result = prime * result + ((objectMapper == null) ? 0 : objectMapper.hashCode());
		result = prime * result + ((organizationId == null) ? 0 : organizationId.hashCode());
		result = prime * result + ((parentOrganizationId == null) ? 0 : parentOrganizationId.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgencyDetails other = (AgencyDetails) obj;
		if (agencyCode == null) {
			if (other.agencyCode != null)
				return false;
		} else if (!agencyCode.equals(other.agencyCode))
			return false;
		if (agencyName == null) {
			if (other.agencyName != null)
				return false;
		} else if (!agencyName.equals(other.agencyName))
			return false;
		if (isAgencySupport == null) {
			if (other.isAgencySupport != null)
				return false;
		} else if (!isAgencySupport.equals(other.isAgencySupport))
			return false;
		if (isArgent == null) {
			if (other.isArgent != null)
				return false;
		} else if (!isArgent.equals(other.isArgent))
			return false;
		if (isBond == null) {
			if (other.isBond != null)
				return false;
		} else if (!isBond.equals(other.isBond))
			return false;
		if (isCL == null) {
			if (other.isCL != null)
				return false;
		} else if (!isCL.equals(other.isCL))
			return false;
		if (isPL == null) {
			if (other.isPL != null)
				return false;
		} else if (!isPL.equals(other.isPL))
			return false;
		if (isParentAgency == null) {
			if (other.isParentAgency != null)
				return false;
		} else if (!isParentAgency.equals(other.isParentAgency))
			return false;
		if (isPrincipal == null) {
			if (other.isPrincipal != null)
				return false;
		} else if (!isPrincipal.equals(other.isPrincipal))
			return false;
		if (isProducer == null) {
			if (other.isProducer != null)
				return false;
		} else if (!isProducer.equals(other.isProducer))
			return false;
		if (isSL == null) {
			if (other.isSL != null)
				return false;
		} else if (!isSL.equals(other.isSL))
			return false;
		if (objectMapper == null) {
			if (other.objectMapper != null)
				return false;
		} else if (!objectMapper.equals(other.objectMapper))
			return false;
		if (organizationId == null) {
			if (other.organizationId != null)
				return false;
		} else if (!organizationId.equals(other.organizationId))
			return false;
		if (parentOrganizationId == null) {
			if (other.parentOrganizationId != null)
				return false;
		} else if (!parentOrganizationId.equals(other.parentOrganizationId))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}

	@Override
	public String toString() {
		try {
			return objectMapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
		}
		return null;
	}
	
	private ObjectMapper objectMapper = new ObjectMapper();
}
