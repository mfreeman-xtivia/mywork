package com.wbmi.agent.portal.agency.internal.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.wbmi.agent.portal.agency.detail.model.AgencyDetails;
import com.wbmi.agent.portal.agency.internal.resources.CurrentAgencyResource;
import com.wbmi.agent.portal.agency.internal.resources.OrganizationResource;
import com.wbmi.agent.portal.agency.internal.resources.UserAgencySyncResource;
import com.wbmi.agent.portal.agency.service.api.AgencyDetailService;
import com.wbmi.agent.portal.exception.WebServiceException;

@Component(immediate= true, service = AgencyDetailService.class)
public class AgencyDetailServiceImpl implements AgencyDetailService {
	
	@Override
	public User syncAgenciesForAgent(User user) throws PortalException {
		return userAgencyResource.syncAgenciesForAgent(user);
	}
	
	@Override
	public boolean syncAgencies(long companyId, HttpServletRequest request) throws WebServiceException {
		return orgResource.syncAgencies(companyId, request);
	}

	@Override
	public String retrieveAgencyCode(long userId, HttpServletRequest request, Boolean isOriginalServletRequest) {
		return currentAgencyResource.retrieveAgencyCode(userId,request,isOriginalServletRequest, Boolean.TRUE);
	}

	@Override
	public String[] retrieveBillingAgencyCode(User user, HttpServletRequest request, Boolean isOriginalServletRequest) {
		return currentAgencyResource.retrieveBillingAgencyCode(user, request, isOriginalServletRequest);
	}

	@Override
	public String retrieveAgencyCode(long userId, HttpServletRequest request, Boolean isOriginalServletRequest,
			Boolean returnDefault) {
		return currentAgencyResource.retrieveAgencyCode(userId, request, isOriginalServletRequest, returnDefault);
	}

	@Override
	public AgencyDetails retrieveAgencyDetail(long userId, HttpServletRequest request,
			Boolean isOriginalServletRequest) {
		return currentAgencyResource.retrieveAgencyDetail(userId, request, isOriginalServletRequest);
	}

	@Override
	public AgencyDetails storeAgencyDetails(long userId, AgencyDetails agencyData, HttpServletRequest request,
			Boolean isOriginalServletRequest) {
		return currentAgencyResource.storeAgencyDetails(userId, agencyData, request, isOriginalServletRequest);
	}

	@Override
	public AgencyDetails storeAgencyDetails(User user, String friendlyUrl, long orgId, HttpServletRequest request,
			Boolean isOriginalServletRequest) throws PortalException {
		return currentAgencyResource.storeAgencyDetails(user, friendlyUrl, orgId, request, isOriginalServletRequest);
	}

	@Override
	public AgencyDetails storeAgencyDetails(User user, String friendlyUrl, List<Organization> orgList,
			HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException {
		return currentAgencyResource.storeAgencyDetails(user, friendlyUrl, orgList, request, isOriginalServletRequest);
	}

	@Override
	public AgencyDetails storeAgencyDetails(User user, long groupId, long orgId, HttpServletRequest request,
			Boolean isOriginalServletRequest) throws PortalException {
		return currentAgencyResource.storeAgencyDetails(user, groupId, orgId, request, isOriginalServletRequest);
	}

	@Override
	public AgencyDetails storeAgencyDetails(User user, long groupId, Organization org, HttpServletRequest request,
			Boolean isOriginalServletRequest) throws PortalException {
		return currentAgencyResource.storeAgencyDetails(user, groupId, org, request, isOriginalServletRequest);
	}
	
	
	@Reference
	private OrganizationResource orgResource;
	
	@Reference
	private CurrentAgencyResource currentAgencyResource;
	
	@Reference
	private UserAgencySyncResource userAgencyResource;
}
