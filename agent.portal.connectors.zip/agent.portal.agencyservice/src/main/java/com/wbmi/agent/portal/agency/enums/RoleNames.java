package com.wbmi.agent.portal.agency.enums;

public enum RoleNames {
	
	SITE_PRINCIPAL("Site Principal"),
	SITE_PRODUCER("Site Producer"),
	SITE_AGENCY_SUPPORT("Site Agency Support"),
	SITE_PERSONAL_LINES("Site Personal Lines"),
	SITE_COMMERCIAL_LINES("Site Commercial Lines"),
	SITE_SPECIALTY_LINES("Site Specialty Lines"),
	SITE_BONDS("Site Bonds"),
	SITE_ARGENT("Site Argent"),
	
	ORG_PRINCIPAL("Organization Principal"),
	ORG_PRODUCER("Organization Producer"),
	ORG_AGENCY_SUPPORT("Organization Agency Support");
	
	private final String key;

	/**
	 * @param text
	 */
	private RoleNames(final String key) {
		this.key = key;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return key;
	}

}
