package com.wbmi.agent.portal.agency.internal.resources.common;

import java.util.List;
import java.util.NoSuchElementException;

import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.expando.kernel.model.ExpandoValue;
import com.liferay.expando.kernel.service.ExpandoValueLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.model.UserGroup;
import com.liferay.portal.kernel.model.UserGroupRole;
import com.liferay.portal.kernel.service.CountryService;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.service.OrganizationLocalService;
import com.liferay.portal.kernel.service.RegionService;
import com.liferay.portal.kernel.service.RoleLocalService;
import com.liferay.portal.kernel.service.UserGroupLocalService;
import com.liferay.portal.kernel.service.UserGroupRoleLocalService;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.agency.enums.OrgCustomFields;
import com.wbmi.agent.portal.agency.enums.RoleNames;
import com.wbmi.agent.portal.agency.enums.UserGroupNames;
import com.wbmi.agent.portal.agency.internal.model.AgencyDetailsResponse;
import com.wbmi.agent.portal.apim.executor.WebServiceExecutor;
import com.wbmi.agent.portal.exception.WebServiceException;

public class CommonAgencyResource {
	
	/**
	 * @param agencyDetail
	 * @return
	 */
	protected long findOrganizationIdFromAgencyCode(String agencyCode) throws NoSuchElementException {
		logger.debug("Running Dynamic query for {}", agencyCode);
		DynamicQuery dynamicQuery = expandoValueLocalService.dynamicQuery()
				.add(PropertyFactoryUtil.forName("columnId").eq(OrgCustomFields.AGENCY_CODE.getId()))
				.add(PropertyFactoryUtil.forName("data").eq(agencyCode));
		List<ExpandoValue> expandoValues = expandoValueLocalService.dynamicQuery(dynamicQuery);
		return expandoValues.stream().findFirst().orElseThrow().getClassPK();
	}
	
	protected Organization findOrganizationFromAgencyCode(AgencyDetailsResponse agencyDetail) {
		return findOrganizationFromAgencyCode(agencyDetail.getAgencyCode());
		
	}
	
	protected Organization findOrganizationFromAgencyCode(String agencyCode) {
		try {
			long orgId = findOrganizationIdFromAgencyCode(agencyCode);
			return organizationLocalService.fetchOrganization(orgId);
		} catch (NoSuchElementException e) {
			logger.error("No Organization Found for {}", agencyCode);
			return null;
		}
		
	}
	
	protected String getOrganizationName(AgencyDetailsResponse agencyDetails) {
		StringBuilder name = new StringBuilder(StringPool.OPEN_PARENTHESIS).append(agencyDetails.getAgencyCode())
				.append(StringPool.CLOSE_PARENTHESIS).append(StringPool.SPACE).append(agencyDetails.getAgencyName());
		return name.toString();
	}
	
	protected long findCountryId() {
		return countryService.fetchCountryByA3(USA).getCountryId();
	}
	
	protected long findRegionCode(long countryId, String agencyCode) {
		String regionCode = findState(agencyCode);
		return regionService.fetchRegion(countryId, regionCode).getRegionId();
	}

	/**
	 * @param agencyCode
	 * @return
	 */
	protected String findState(String agencyCode) {
		String startsWith = agencyCode.substring(0, 2);
		switch (startsWith) {
		case "02": return "AZ";
		case "12": return "IL";
		case "13": return "IN";
		case "14": return "IA";
		case "15": return "KS";
		case "16": return "KY";
		case "21": return "MI";
		case "22": return "MN";
		case "24": return "MO";
		case "26": return "NE";
		case "32": return "NC";
		case "34": return "OH";
		case "45": return "VA";
		case "48":
		case "88":
		default: return "WI" ;
		}
	}
	
	protected void retrieveRoleDetails(long companyId) throws PortalException {
		principal= retriveRole(principal,companyId,RoleNames.SITE_PRINCIPAL.toString());
		producer = retriveRole(producer,companyId,RoleNames.SITE_PRODUCER.toString());
		agencySupport = retriveRole(agencySupport,companyId,RoleNames.SITE_AGENCY_SUPPORT.toString());
		personalLines =retriveRole(personalLines,companyId,RoleNames.SITE_PERSONAL_LINES.toString());
		commercialLines = retriveRole(commercialLines,companyId,RoleNames.SITE_COMMERCIAL_LINES.toString());
		bonds =retriveRole(bonds,companyId,RoleNames.SITE_BONDS.toString());
		argent = retriveRole(argent,companyId,RoleNames.SITE_ARGENT.toString());
		specialtyLines = retriveRole(specialtyLines,companyId,RoleNames.SITE_SPECIALTY_LINES.toString());
		
		orgPrincipal= retriveRole(orgPrincipal,companyId,RoleNames.ORG_PRINCIPAL.toString());
		orgProducer = retriveRole(orgProducer,companyId,RoleNames.ORG_PRODUCER.toString());
		orgAgencySupport = retriveRole(orgAgencySupport,companyId,RoleNames.ORG_AGENCY_SUPPORT.toString());
	}
	
	protected void retrieveUserGroupDetails(long companyId) throws PortalException {
		principalUserGroup = retriveUserGroup(principalUserGroup, companyId,UserGroupNames.PRINCIPAL_USER_GROUP.getName());
		producerUserGroup = retriveUserGroup(producerUserGroup, companyId,UserGroupNames.PRODUCER_USER_GROUP.getName());
		agencySupportUserGroup = retriveUserGroup(agencySupportUserGroup, companyId,UserGroupNames.AGENCY_SUPPORT_USER_GROUP.getName());
		wbmiUserGroup = retriveUserGroup(wbmiUserGroup, companyId,UserGroupNames.WBMI_USER_GROUP.getName());
	}

	protected void removeUserGroupRole(long userId,long groupId, long[] roleIds) throws PortalException {
		userGroupRoleLocalService.deleteUserGroupRoles(userId, groupId, roleIds);
	}
	
	protected void addUserGroupRole(long userId,long groupId, long[] roleIds) throws PortalException {
		userGroupRoleLocalService.addUserGroupRoles(userId, groupId, roleIds);
	}
	
	protected void removeUserGroups(long userId, long[] userGroupIds) throws PortalException {
		userGroupLocalService.deleteUserUserGroups(userId, userGroupIds);
		for (long userGroupId: userGroupIds) {
			userLocalService.deleteUserGroupUser(userGroupId, userId);		
		}
	}
	
	protected void addUserGroups(long userId, long[] userGroupIds) throws PortalException {
		for (long userGroupId: userGroupIds) {
			userLocalService.addUserGroupUser(userGroupId, userId);
		}
	}
	
	protected Role retriveRole(Role role, long companyId,String roleName) throws PortalException {
		if(Validator.isNull(role)) {
			role = roleLocalService.fetchRole(companyId,roleName);
		}
		return role;
	}
	
	protected Group retriveGroup(Group group, long companyId,String groupFriendlyUrl) throws PortalException {
		if(Validator.isNull(group)) {
			group = groupLocalService.fetchFriendlyURLGroup(companyId, groupFriendlyUrl);
		}
		return group;
	}
	
	protected UserGroup retriveUserGroup(UserGroup usergroup, long companyId,String userGroupName) throws PortalException {
		if(Validator.isNull(usergroup)) {
			usergroup = userGroupLocalService.fetchUserGroup(companyId, userGroupName);
		}
		return usergroup;
	}
	
	protected Boolean hasRole(Role orgRole, List<UserGroupRole> orgRoles) {
		return orgRoles.stream().anyMatch(ogRole -> orgRole.getRoleId() == ogRole.getRoleId());
	}

	protected Boolean isWBMIUser(User user) {
		return PortalUtil.isOmniadmin(user) || user.getUserGroups().stream().anyMatch(userGroup -> userGroup.getName().equalsIgnoreCase(UserGroupNames.WBMI_USER_GROUP.getName()));
	}
	
	protected Boolean isParentAgency(Organization organization) throws WebServiceException{
		getAgenciesOrganization(organization.getCompanyId());
		return organization.getParentOrganizationId() == parentOrganization.getOrganizationId() || organization.getParentOrganizationId() == 0;
	}


	protected Organization findParentOrg(List<Organization> orgList) throws WebServiceException{
		getAgenciesOrganization(orgList.stream().findFirst().get().getCompanyId());
		return orgList.stream().filter(org -> org.getParentOrganizationId() == parentOrganization.getOrganizationId() ||  org.getParentOrganizationId() == 0).findFirst().get();
	}
	
	/**
	 * @param organization
	 */
	protected void getAgenciesOrganization(long companyId) throws WebServiceException {
		if(Validator.isNull(parentOrganization)) {
			parentOrganization = organizationLocalService.fetchOrganization(companyId, AGENCIES);
		}
	}
	
	protected void determineUserGroupstoAddandDelete(Boolean isRole, Boolean hasRole,	UserGroup userGroup, List<Long> userGroupstoAddList, List<Long> userGroupstoDeleteList) {
		if(!isRole && hasRole) {
			userGroupstoDeleteList.add(userGroup.getUserGroupId());
		} else if(isRole && !hasRole) {
			userGroupstoAddList.add(userGroup.getUserGroupId());
		}
		
	}

	protected void determineRolestoAddandDelete(Boolean isRole,Boolean hasRole, Role role, List<Long> roletoAddList, List<Long> rolestoDeleteList) {
		if(!isRole && hasRole) {
			rolestoDeleteList.add(role.getRoleId());
		} else if(isRole && !hasRole) {
			roletoAddList.add(role.getRoleId());
		}
	}
	
	protected boolean checkGroupRole(Role role, List<UserGroupRole> userGroupRoles) {
		return userGroupRoles.stream().anyMatch(grpRole -> grpRole.getRoleId() == role.getRoleId());
	}
	
	protected Boolean checkUserGroup(UserGroup userGroup, List<UserGroup> userGroups) {
		return userGroups.stream().anyMatch(uG -> userGroup.getName().equalsIgnoreCase(uG.getName()));
	}
	
	protected Organization parentOrganization = null;
	
	protected Role principal = null;
	protected Role producer = null;
	protected Role agencySupport = null;
	
	protected Role orgPrincipal = null;
	protected Role orgProducer = null;
	protected Role orgAgencySupport = null;
	
	protected Role personalLines = null;
	protected Role commercialLines = null;
	protected Role bonds = null;
	protected Role argent = null;
	protected Role specialtyLines = null;
	
	protected UserGroup principalUserGroup = null; 
	protected UserGroup producerUserGroup = null;
	protected UserGroup agencySupportUserGroup = null;
	protected UserGroup wbmiUserGroup = null;
	
	protected Group agentPortalGroup = null;
	
	@Reference
	protected OrganizationLocalService organizationLocalService;
	
	@Reference
	protected GroupLocalService groupLocalService;
	
	@Reference
	protected UserLocalService userLocalService;
	
	@Reference
	protected UserGroupRoleLocalService userGroupRoleLocalService;
	
	@Reference 
	protected UserGroupLocalService userGroupLocalService;
	
	@Reference
	protected RoleLocalService roleLocalService;
	
	@Reference
	protected ExpandoValueLocalService expandoValueLocalService;
	
	@Reference
	protected CountryService countryService;
	
	@Reference
	protected RegionService regionService;
	
	@Reference
	protected WebServiceExecutor _webServiceExecutor;
	
	@Reference
	protected CounterLocalService counterLocalService;
	
	protected ObjectMapper objectMapper = new ObjectMapper();
	
	protected static final String USA = "USA";
	protected static final String AGENCIES = "Agencies";
	protected static final String SHARED_AGENCY = "LIFERAY_SHARED_selectedAgency";
	
	protected static final String SAMPLE_ACCOUNT = "(99999) WBMI";
	protected static final String SAMPLE_ACCOUNT_CODE = "99999";
	
	private static final Logger logger = LoggerFactory.getLogger(CommonAgencyResource.class);
}
