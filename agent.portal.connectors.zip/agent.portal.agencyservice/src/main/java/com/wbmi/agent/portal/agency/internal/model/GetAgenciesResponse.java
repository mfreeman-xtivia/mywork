package com.wbmi.agent.portal.agency.internal.model;

import java.io.Serializable;
import java.util.Arrays;

public class GetAgenciesResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8430728808094943471L;
	private String username;
	private String userEmail;
	private Boolean isAgent;
	private AgencyDetailsResponse agency;
	private AgencyDetailsResponse[] relatedAgencies;
	/**
	 * @return the userName
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUsername(String userName) {
		this.username = userName;
	}
	/**
	 * @return the userEmail
	 */
	public String getUserEmail() {
		return userEmail;
	}
	/**
	 * @param userEmail the userEmail to set
	 */
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	/**
	 * @return the isAgent
	 */
	public Boolean getIsAgent() {
		return isAgent;
	}
	/**
	 * @param isAgent the isAgent to set
	 */
	public void setIsAgent(Boolean isAgent) {
		this.isAgent = isAgent;
	}
	/**
	 * @return the agency
	 */
	public AgencyDetailsResponse getAgency() {
		return agency;
	}
	/**
	 * @param agency the agency to set
	 */
	public void setAgency(AgencyDetailsResponse agency) {
		this.agency = agency;
	}
	/**
	 * @return the relatedAgencies
	 */
	public AgencyDetailsResponse[] getRelatedAgencies() {
		return relatedAgencies;
	}
	/**
	 * @param relatedAgencies the relatedAgencies to set
	 */
	public void setRelatedAgencies(AgencyDetailsResponse[] relatedAgencies) {
		this.relatedAgencies = relatedAgencies;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agency == null) ? 0 : agency.hashCode());
		result = prime * result + ((isAgent == null) ? 0 : isAgent.hashCode());
		result = prime * result + Arrays.hashCode(relatedAgencies);
		result = prime * result + ((userEmail == null) ? 0 : userEmail.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GetAgenciesResponse other = (GetAgenciesResponse) obj;
		if (agency == null) {
			if (other.agency != null)
				return false;
		} else if (!agency.equals(other.agency))
			return false;
		if (isAgent == null) {
			if (other.isAgent != null)
				return false;
		} else if (!isAgent.equals(other.isAgent))
			return false;
		if (!Arrays.equals(relatedAgencies, other.relatedAgencies))
			return false;
		if (userEmail == null) {
			if (other.userEmail != null)
				return false;
		} else if (!userEmail.equals(other.userEmail))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GetAgenciesResponse [");
		if (username != null)
			builder.append("userName=").append(username).append(", ");
		if (userEmail != null)
			builder.append("userEmail=").append(userEmail).append(", ");
		if (isAgent != null)
			builder.append("isAgent=").append(isAgent).append(", ");
		if (agency != null)
			builder.append("agency=").append(agency).append(", ");
		if (relatedAgencies != null)
			builder.append("relatedAgencies=").append(Arrays.toString(relatedAgencies));
		builder.append("]");
		return builder.toString();
	}
}
