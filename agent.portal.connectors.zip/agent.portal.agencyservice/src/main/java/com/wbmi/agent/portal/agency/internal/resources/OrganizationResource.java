package com.wbmi.agent.portal.agency.internal.resources;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.ListTypeConstants;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.wbmi.agent.portal.agency.enums.OrgCustomFields;
import com.wbmi.agent.portal.agency.internal.model.AgencyDetailsResponse;
import com.wbmi.agent.portal.agency.internal.resources.common.CommonAgencyResource;
import com.wbmi.agent.portal.common.service.model.WebServiceMethod;
import com.wbmi.agent.portal.configuration.util.AgencySyncConfigUtil;
import com.wbmi.agent.portal.configuration.util.AzureAPIMConfigurationUtil;
import com.wbmi.agent.portal.configuration.util.MockServiceConfigurationUtil;
import com.wbmi.agent.portal.exception.WebServiceException;

@Component(immediate=true, service=OrganizationResource.class)
public class OrganizationResource extends CommonAgencyResource {

	public boolean syncAgencies(long companyId,HttpServletRequest request) throws WebServiceException {
		logger.info("OrganizationResource.createOrganizations()");
		List<AgencyDetailsResponse> agencyDetails  = null;
		Boolean isMockingEnabled = MockServiceConfigurationUtil.agencyDetailsMockingEnabled();
		if (isMockingEnabled) {
			agencyDetails =  createMockResponse();
		} else {
			agencyDetails = retrieveAgencyDetails(companyId);
		}
		return createorUpdateOrgs(agencyDetails,companyId);
	}
	
	private boolean createorUpdateOrgs(List<AgencyDetailsResponse> agencyDetails, long companyId) throws WebServiceException {
		long countryId = findCountryId();
		User user;
		try {
			user = userLocalService.getDefaultUser(companyId);
			for(AgencyDetailsResponse agencyDetail : agencyDetails) {
				Organization org=  organizationLocalService.fetchOrganization(companyId, getOrganizationName(agencyDetail));
				if(Validator.isNotNull(org)) {
					updateOrganization(companyId, agencyDetail, org);
				} else {
					if (!SAMPLE_ACCOUNT_CODE.equalsIgnoreCase(agencyDetail.getAgencyCode())){
						createOrganization(user,companyId,agencyDetail,countryId);
					}
				}
			}
		} catch (PortalException pe) {
			throw new WebServiceException(pe.getMessage() , pe);
		}
		
		return false;
	}

	private void createOrganization(User user,long companyId, AgencyDetailsResponse agencyDetail, long countryId) throws WebServiceException {
		try {
			long parentOrganizationId = getParentOrganizationId(agencyDetail, companyId);
			String[] types = organizationLocalService.getTypes();
			Organization org = organizationLocalService.addOrganization(user.getUserId(),parentOrganizationId,getOrganizationName(agencyDetail),types[0],
					findRegionCode(countryId,agencyDetail.getAgencyCode()),countryId, ListTypeConstants.ORGANIZATION_STATUS_DEFAULT, null,Boolean.FALSE,null);
			org.getExpandoBridge().setAttributes(createCustomFieldsMap(agencyDetail),Boolean.FALSE);
			organizationLocalService.updateOrganization(org);
			logger.debug("Creating Agency {} with Agency Code {}", agencyDetail.getAgencyName(), agencyDetail.getAgencyCode() );
		} catch (PortalException e) {
			throw new WebServiceException("Creating Organization failed " , e);
		}
	
	}

	/**
	 * @param companyId
	 * @param agencyDetail
	 * @param org
	 */
	private Boolean updateOrganization(long companyId, AgencyDetailsResponse agencyDetail, Organization org) throws WebServiceException {
		try {
			org.getExpandoBridge().setAttributes(createCustomFieldsMap(agencyDetail),Boolean.FALSE);
			org.setParentOrganizationId(getParentOrganizationId(agencyDetail, companyId));
			organizationLocalService.updateOrganization(org);
		} catch(Exception e) {
			throw new WebServiceException("Updating Organization failed " , e);
		}
		return Boolean.TRUE;
	}

	/**
	 * @param agencyDetail
	 * @param org
	 * @throws WebServiceException 
	 */
	private long getParentOrganizationId(AgencyDetailsResponse agencyDetail, long companyId) throws WebServiceException {
		if(!Validator.isBlank(agencyDetail.getParentAgencyCode())) {
			try {
				long parentOrganizationId = findOrganizationIdFromAgencyCode(agencyDetail.getParentAgencyCode());
				return parentOrganizationId;
			} catch (NoSuchElementException e) {
				logger.error("No Organization Found for {}", agencyDetail.getAgencyCode());
			}
		} 
		if (OrganizationResource.SAMPLE_ACCOUNT_CODE.equalsIgnoreCase(agencyDetail.getAgencyCode())) {
			return 0;
		}
		getAgenciesOrganization(companyId);
		return parentOrganization.getOrganizationId();
	}

	/**
	 * @return
	 */
	private Map<String, Serializable> createCustomFieldsMap(AgencyDetailsResponse agencyDetail) {
		Map<String,Serializable> expandoBridgeAttributes = new HashMap<String, Serializable>();
		// When Profit Center Information is available in the service response we will update it.
		expandoBridgeAttributes.put(OrgCustomFields.AGENCY_CODE.getKey(), agencyDetail.getAgencyCode());
		expandoBridgeAttributes.put(OrgCustomFields.PERSONAL_LINES.getKey(), Boolean.TRUE);
		expandoBridgeAttributes.put(OrgCustomFields.COMMERCIAL_LINES.getKey(), Boolean.TRUE);
		expandoBridgeAttributes.put(OrgCustomFields.SPECIALTY_LINES.getKey(), Boolean.TRUE);
		expandoBridgeAttributes.put(OrgCustomFields.BONDS.getKey(), Boolean.TRUE);
		expandoBridgeAttributes.put(OrgCustomFields.ARGENT.getKey(), Boolean.TRUE);
		return expandoBridgeAttributes;
	}

	private List<AgencyDetailsResponse> retrieveAgencyDetails(long companyId) throws WebServiceException {
		logger.info("OrganizationResource.retrieveAgencyDetails()");
		String apiKey = AzureAPIMConfigurationUtil.agencyServiceApiKey();
		try {
			String response = _webServiceExecutor.executeGet(companyId, WebServiceMethod.AGENCY_DETAILS,
					apiKey, WebServiceMethod.AGENCY_DETAILS.getUrl(),WebServiceMethod.AGENCY_DETAILS.getCacheKeyIdentifier());
			logger.debug("OrganizationResource.retrieveAgencyDetails() {}", response);
			return sortResponse(response);
		} catch (Exception e) {
			throw new WebServiceException("Retrieving Agency Information failed" , e );
		}
	}
	
	
	private List<AgencyDetailsResponse> createMockResponse() throws WebServiceException {
		logger.debug("OrganizationResource.createMockResponse()");
		try (InputStream inputStream = mockJsonFileUrl.openStream()) {
			return sortResponse(StringUtil.read(inputStream));
		} catch (IOException ioe) {
			throw new WebServiceException("Could not return default response for mock service", ioe);
		} catch (Exception e) {
			throw new WebServiceException("Could not return default response for mock service", e);
		}
	}

	/**
	 * @param agencyDetails
	 * @throws JsonProcessingException 
	 * @throws JsonMappingException 
	 */
	private List<AgencyDetailsResponse> sortResponse(String response) throws IOException {
		AgencyDetailsResponse[] agencyDetails  = objectMapper.readValue(response, AgencyDetailsResponse[].class);
		List<AgencyDetailsResponse> unSortedList = Arrays.asList(agencyDetails);
		Map<String,AgencyDetailsResponse> agencyResponseMap = new HashMap<>();
		List<AgencyDetailsResponse> sortedList = new ArrayList<>();
		int recursionCounter = 0;
		recursiveSorting(unSortedList, agencyResponseMap, sortedList,recursionCounter);
		sortedList.stream().forEach(item -> logger.debug(item.toString()));
		return sortedList;
	}

	/**
	 * @param list
	 * @param agencyResponseMap
	 * @param sortedList
	 */
	private void recursiveSorting(List<AgencyDetailsResponse> unSortedList,Map<String, AgencyDetailsResponse> agencyResponseMap, List<AgencyDetailsResponse> sortedList, int recursionCounter) {
		Collections.sort(unSortedList, Comparator.comparing(AgencyDetailsResponse::getParentAgencyCode));
		unSortedList.stream().forEach(item -> {
			if (Validator.isBlank(item.getParentAgencyCode())) {
				sortedList.add(item);
				agencyResponseMap.put(item.getAgencyCode(), item);
			} else if (agencyResponseMap.containsKey(item.getParentAgencyCode())){
				sortedList.add(item);
				agencyResponseMap.put(item.getAgencyCode(), item);
			}
		});
		unSortedList = unSortedList.stream().filter(item -> !agencyResponseMap.containsKey(item.getAgencyCode())).collect(Collectors.toList());
		if(recursionCounter < AgencySyncConfigUtil.maxRecursionForSorting() && !unSortedList.isEmpty()) {
			logger.debug("before recursion");
			logger.info("Recursive Sorting getting called with list size {} ", String.valueOf(unSortedList.size()));
			unSortedList.stream().forEach(item -> logger.debug(item.toString()));
			recursionCounter++;
			recursiveSorting(unSortedList,agencyResponseMap,sortedList,recursionCounter);
			logger.debug("After recursion");
		} 
	}
	
	/**
	 * @param organization
	 * @throws WebServiceException 
	 */
	@Override
	protected void getAgenciesOrganization(long companyId) throws WebServiceException {
		if(Validator.isNull(parentOrganization)) {
			try {
				parentOrganization = organizationLocalService.getOrganization(companyId, AGENCIES);
			} catch (PortalException e) {
				User user;
				try {
					user = userLocalService.getDefaultUser(companyId);
					String[] types = organizationLocalService.getTypes();
					long countryId = findCountryId();
					parentOrganization = organizationLocalService.addOrganization(user.getUserId(),0,AGENCIES,types[0],
							0,countryId, ListTypeConstants.ORGANIZATION_STATUS_DEFAULT, null,Boolean.FALSE,null);
					AgencyDetailsResponse agencyDetailsResponse = new AgencyDetailsResponse();
					agencyDetailsResponse.setAgencyCode(OrganizationResource.SAMPLE_ACCOUNT_CODE);
					Organization sampleOrg = organizationLocalService.addOrganization(user.getUserId(),0,OrganizationResource.SAMPLE_ACCOUNT,types[0],
							0,countryId, ListTypeConstants.ORGANIZATION_STATUS_DEFAULT, null,Boolean.FALSE,null);
					sampleOrg.getExpandoBridge().setAttributes(createCustomFieldsMap(agencyDetailsResponse),Boolean.FALSE);
					organizationLocalService.updateOrganization(sampleOrg);
				} catch (PortalException e1) {
					throw new WebServiceException("Unable create parent Organization ", e);
				}
			}
		}
	}
	
	@Activate
	protected void activate(BundleContext bundleContext, Map<String, Object> properties) {
		logger.debug("OrganizationResource.activate()");
		Bundle bundle = bundleContext.getBundle();
		mockJsonFileUrl = bundle.getResource(AGENCY_DETAILS_MOCK_RESPONSE_JSON_FILE);
	}
	
	
	private URL mockJsonFileUrl;
	
	private static final String AGENCY_DETAILS_MOCK_RESPONSE_JSON_FILE = "/META-INF/default-ws-responses/GetAgencyDetailsResponse.json";
	
	private static final Logger logger = LoggerFactory.getLogger(OrganizationResource.class);
	
}
