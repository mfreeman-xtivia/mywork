package com.wbmi.agent.portal.agency.enums;

public enum UserGroupNames {
	
	PRINCIPAL_USER_GROUP("Principal User Group","Agent Portal Principal User Group"),
	PRODUCER_USER_GROUP("Producer User Group","Agent Portal Producer User Group"),
	AGENCY_SUPPORT_USER_GROUP("Agency Support User Group","	Agent Portal Agency Support User Group"),
	WBMI_USER_GROUP("WBMI User Group","WBMI User Group");

	private final String name;
	private final String description;

	/**
	 * @param text
	 */
	private UserGroupNames(final String name,final String description) {
		this.name = name;
		this.description = description;
	}

	public String getName() {
		return name;
	}
	
	
	public String getDescription() {
		return description;
	}

}
