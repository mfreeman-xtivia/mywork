package com.wbmi.agent.portal.agency.enums;

public enum UserCustomFields {
	
	WBMI_USERID("wbmiUserId",0l),
	DEFAULT_AGENCYID("defaultAgencyId",0l);
	
	private final String key;
	private final Long id;

	/**
	 * @param text
	 */
	private UserCustomFields(final String key, final Long id) {
		this.key = key;
		this.id = id;
	}

	public String getKey() {
		return key;
	}
	
	public Long getId() {
		return id;
	}

}
