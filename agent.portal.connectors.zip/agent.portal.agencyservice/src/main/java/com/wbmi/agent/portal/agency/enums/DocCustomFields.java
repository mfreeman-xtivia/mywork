package com.wbmi.agent.portal.agency.enums;

public enum DocCustomFields {

	CUSTOM_TITLE("custom_title",1L),
	POLICY_EFFECTIVE_DATE("policy_effective_date",2L),
	EXPIRATION_DATE("expiration_date",3L);

	private final String key;
	private final Long id;

	/**
	 * @param text
	 */
	private DocCustomFields(final String key, final Long id) {
		this.key = key;
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public Long getId() {
		return id;
	}

}
