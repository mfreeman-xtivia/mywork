package com.wbmi.agent.portal.agency.service.api;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.wbmi.agent.portal.agency.detail.model.AgencyDetails;
import com.wbmi.agent.portal.exception.WebServiceException;

public interface AgencyDetailService {
	
	public User syncAgenciesForAgent(User user) throws PortalException;
	
	public boolean syncAgencies(long companyId, HttpServletRequest request) throws WebServiceException; 
	
	public String retrieveAgencyCode(long userId, HttpServletRequest request, Boolean isOriginalServletRequest);
	
	public String[] retrieveBillingAgencyCode(User user, HttpServletRequest request, Boolean isOriginalServletRequest);
	
	public String retrieveAgencyCode(long userId, HttpServletRequest request,Boolean isOriginalServletRequest, Boolean returnDefault);

	public AgencyDetails retrieveAgencyDetail(long userId, HttpServletRequest request, Boolean isOriginalServletRequest);
	
	public AgencyDetails storeAgencyDetails(long userId, AgencyDetails agencyData, HttpServletRequest request,Boolean isOriginalServletRequest);
	
	public AgencyDetails storeAgencyDetails(User user,String friendlyUrl, long orgId, HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException;
	
	public AgencyDetails storeAgencyDetails(User user,String friendlyUrl, List<Organization> orgList, HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException;
	
	public AgencyDetails storeAgencyDetails(User user,long groupId, long orgId, HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException;
	
	public AgencyDetails storeAgencyDetails(User user,long groupId, Organization org, HttpServletRequest request, Boolean isOriginalServletRequest) throws PortalException;

}
