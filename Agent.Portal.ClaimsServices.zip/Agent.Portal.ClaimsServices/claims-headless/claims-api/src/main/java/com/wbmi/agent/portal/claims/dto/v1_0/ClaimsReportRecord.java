package com.wbmi.agent.portal.claims.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
@GraphQLName("ClaimsReportRecord")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ClaimsReportRecord")
public class ClaimsReportRecord implements Serializable {

	public static ClaimsReportRecord toDTO(String json) {
		return ObjectMapperUtil.readValue(ClaimsReportRecord.class, json);
	}

	@Schema(description = "")
	public String getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}

	@JsonIgnore
	public void setAgencyId(
		UnsafeSupplier<String, Exception> agencyIdUnsafeSupplier) {

		try {
			agencyId = agencyIdUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String agencyId;

	@Schema(description = "")
	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	@JsonIgnore
	public void setCauseOfLoss(
		UnsafeSupplier<String, Exception> causeOfLossUnsafeSupplier) {

		try {
			causeOfLoss = causeOfLossUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String causeOfLoss;

	@Schema(description = "")
	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	@JsonIgnore
	public void setCheckNumber(
		UnsafeSupplier<String, Exception> checkNumberUnsafeSupplier) {

		try {
			checkNumber = checkNumberUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String checkNumber;

	@Schema(description = "")
	public String getClaimKey() {
		return claimKey;
	}

	public void setClaimKey(String claimKey) {
		this.claimKey = claimKey;
	}

	@JsonIgnore
	public void setClaimKey(
		UnsafeSupplier<String, Exception> claimKeyUnsafeSupplier) {

		try {
			claimKey = claimKeyUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String claimKey;

	@Schema(description = "")
	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	@JsonIgnore
	public void setClaimNumber(
		UnsafeSupplier<String, Exception> claimNumberUnsafeSupplier) {

		try {
			claimNumber = claimNumberUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String claimNumber;

	@Schema(description = "")
	public String getClaimOccurrenceNumber() {
		return claimOccurrenceNumber;
	}

	public void setClaimOccurrenceNumber(String claimOccurrenceNumber) {
		this.claimOccurrenceNumber = claimOccurrenceNumber;
	}

	@JsonIgnore
	public void setClaimOccurrenceNumber(
		UnsafeSupplier<String, Exception> claimOccurrenceNumberUnsafeSupplier) {

		try {
			claimOccurrenceNumber = claimOccurrenceNumberUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String claimOccurrenceNumber;

	@Schema(description = "")
	public String getClaimOccurrenceType() {
		return claimOccurrenceType;
	}

	public void setClaimOccurrenceType(String claimOccurrenceType) {
		this.claimOccurrenceType = claimOccurrenceType;
	}

	@JsonIgnore
	public void setClaimOccurrenceType(
		UnsafeSupplier<String, Exception> claimOccurrenceTypeUnsafeSupplier) {

		try {
			claimOccurrenceType = claimOccurrenceTypeUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String claimOccurrenceType;

	@Schema(description = "")
	public String getClaimantName() {
		return claimantName;
	}

	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}

	@JsonIgnore
	public void setClaimantName(
		UnsafeSupplier<String, Exception> claimantNameUnsafeSupplier) {

		try {
			claimantName = claimantNameUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String claimantName;

	@Schema(description = "")
	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	@JsonIgnore
	public void setClosedDate(
		UnsafeSupplier<String, Exception> closedDateUnsafeSupplier) {

		try {
			closedDate = closedDateUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String closedDate;

	@Schema(description = "")
	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	@JsonIgnore
	public void setDateOfLoss(
		UnsafeSupplier<String, Exception> dateOfLossUnsafeSupplier) {

		try {
			dateOfLoss = dateOfLossUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dateOfLoss;

	@Schema(description = "")
	public String getDateReported() {
		return dateReported;
	}

	public void setDateReported(String dateReported) {
		this.dateReported = dateReported;
	}

	@JsonIgnore
	public void setDateReported(
		UnsafeSupplier<String, Exception> dateReportedUnsafeSupplier) {

		try {
			dateReported = dateReportedUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dateReported;

	@Schema(description = "")
	public String getFinancialTypeCode() {
		return financialTypeCode;
	}

	public void setFinancialTypeCode(String financialTypeCode) {
		this.financialTypeCode = financialTypeCode;
	}

	@JsonIgnore
	public void setFinancialTypeCode(
		UnsafeSupplier<String, Exception> financialTypeCodeUnsafeSupplier) {

		try {
			financialTypeCode = financialTypeCodeUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String financialTypeCode;

	@Schema(description = "")
	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	@JsonIgnore
	public void setLossDescription(
		UnsafeSupplier<String, Exception> lossDescriptionUnsafeSupplier) {

		try {
			lossDescription = lossDescriptionUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lossDescription;

	@Schema(description = "")
	public String getPayToTheOrderOf() {
		return payToTheOrderOf;
	}

	public void setPayToTheOrderOf(String payToTheOrderOf) {
		this.payToTheOrderOf = payToTheOrderOf;
	}

	@JsonIgnore
	public void setPayToTheOrderOf(
		UnsafeSupplier<String, Exception> payToTheOrderOfUnsafeSupplier) {

		try {
			payToTheOrderOf = payToTheOrderOfUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String payToTheOrderOf;

	@Schema(description = "")
	public String getPaymentIssuedDate() {
		return paymentIssuedDate;
	}

	public void setPaymentIssuedDate(String paymentIssuedDate) {
		this.paymentIssuedDate = paymentIssuedDate;
	}

	@JsonIgnore
	public void setPaymentIssuedDate(
		UnsafeSupplier<String, Exception> paymentIssuedDateUnsafeSupplier) {

		try {
			paymentIssuedDate = paymentIssuedDateUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String paymentIssuedDate;

	@Schema(description = "")
	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	@JsonIgnore
	public void setPolicyHolder(
		UnsafeSupplier<String, Exception> policyHolderUnsafeSupplier) {

		try {
			policyHolder = policyHolderUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String policyHolder;

	@Schema(description = "")
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	@JsonIgnore
	public void setPolicyNumber(
		UnsafeSupplier<String, Exception> policyNumberUnsafeSupplier) {

		try {
			policyNumber = policyNumberUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String policyNumber;

	@Schema(description = "")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		try {
			status = statusUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@Schema(description = "")
	public String getTotalIncurred() {
		return totalIncurred;
	}

	public void setTotalIncurred(String totalIncurred) {
		this.totalIncurred = totalIncurred;
	}

	@JsonIgnore
	public void setTotalIncurred(
		UnsafeSupplier<String, Exception> totalIncurredUnsafeSupplier) {

		try {
			totalIncurred = totalIncurredUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String totalIncurred;

	@Schema(description = "")
	public String getTotalPaymentAmount() {
		return totalPaymentAmount;
	}

	public void setTotalPaymentAmount(String totalPaymentAmount) {
		this.totalPaymentAmount = totalPaymentAmount;
	}

	@JsonIgnore
	public void setTotalPaymentAmount(
		UnsafeSupplier<String, Exception> totalPaymentAmountUnsafeSupplier) {

		try {
			totalPaymentAmount = totalPaymentAmountUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField(description = "")
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String totalPaymentAmount;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ClaimsReportRecord)) {
			return false;
		}

		ClaimsReportRecord claimsReportRecord = (ClaimsReportRecord)object;

		return Objects.equals(toString(), claimsReportRecord.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		if (agencyId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"agencyId\": ");

			sb.append("\"");

			sb.append(_escape(agencyId));

			sb.append("\"");
		}

		if (causeOfLoss != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"causeOfLoss\": ");

			sb.append("\"");

			sb.append(_escape(causeOfLoss));

			sb.append("\"");
		}

		if (checkNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"checkNumber\": ");

			sb.append("\"");

			sb.append(_escape(checkNumber));

			sb.append("\"");
		}

		if (claimKey != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimKey\": ");

			sb.append("\"");

			sb.append(_escape(claimKey));

			sb.append("\"");
		}

		if (claimNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimNumber));

			sb.append("\"");
		}

		if (claimOccurrenceNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimOccurrenceNumber\": ");

			sb.append("\"");

			sb.append(_escape(claimOccurrenceNumber));

			sb.append("\"");
		}

		if (claimOccurrenceType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimOccurrenceType\": ");

			sb.append("\"");

			sb.append(_escape(claimOccurrenceType));

			sb.append("\"");
		}

		if (claimantName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimantName\": ");

			sb.append("\"");

			sb.append(_escape(claimantName));

			sb.append("\"");
		}

		if (closedDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"closedDate\": ");

			sb.append("\"");

			sb.append(_escape(closedDate));

			sb.append("\"");
		}

		if (dateOfLoss != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateOfLoss\": ");

			sb.append("\"");

			sb.append(_escape(dateOfLoss));

			sb.append("\"");
		}

		if (dateReported != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateReported\": ");

			sb.append("\"");

			sb.append(_escape(dateReported));

			sb.append("\"");
		}

		if (financialTypeCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"financialTypeCode\": ");

			sb.append("\"");

			sb.append(_escape(financialTypeCode));

			sb.append("\"");
		}

		if (lossDescription != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lossDescription\": ");

			sb.append("\"");

			sb.append(_escape(lossDescription));

			sb.append("\"");
		}

		if (payToTheOrderOf != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"payToTheOrderOf\": ");

			sb.append("\"");

			sb.append(_escape(payToTheOrderOf));

			sb.append("\"");
		}

		if (paymentIssuedDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"paymentIssuedDate\": ");

			sb.append("\"");

			sb.append(_escape(paymentIssuedDate));

			sb.append("\"");
		}

		if (policyHolder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"policyHolder\": ");

			sb.append("\"");

			sb.append(_escape(policyHolder));

			sb.append("\"");
		}

		if (policyNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"policyNumber\": ");

			sb.append("\"");

			sb.append(_escape(policyNumber));

			sb.append("\"");
		}

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		if (totalIncurred != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"totalIncurred\": ");

			sb.append("\"");

			sb.append(_escape(totalIncurred));

			sb.append("\"");
		}

		if (totalPaymentAmount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"totalPaymentAmount\": ");

			sb.append("\"");

			sb.append(_escape(totalPaymentAmount));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		defaultValue = "com.wbmi.agent.portal.claims.dto.v1_0.ClaimsReportRecord",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		return string.replaceAll("\"", "\\\\\"");
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\":");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(value);
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(",");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}