package com.wbmi.agent.portal.claims.internal.resource.v1_0;

import com.wbmi.agent.portal.claims.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.resource.v1_0.ClaimsServiceResource;
import com.wbmi.agent.portal.claims.service.ClaimsReportsService;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/claims-service.properties",
	scope = ServiceScope.PROTOTYPE, service = ClaimsServiceResource.class
)
public class ClaimsServiceResourceImpl extends BaseClaimsServiceResourceImpl {

	@Override
	public ClaimsReportsResponse getAgencyPlClaimReport(String agencyId,
														String claimType,
														String dateRange) throws Exception {

		logger.info("start--ClaimsServiceResourceImpl.getAgencyPlClaimReport()");
		ClaimsReportsResponse claimsReportsResp = claimsReportsService.
				getAgencyClaimsReports(agencyId,claimType, dateRange, contextCompany);
		//cacheFilter.processFilter(contextHttpServletRequest, contextHttpServletResponse);
		return claimsReportsResp;
	}

	public String getAgencyPlClaimDetail(String claimId) throws Exception {
		logger.info("start--ClaimsServiceResourceImpl.getAgencyPlClaimDetail()");
		String claimDetail = claimsReportsService.getAgencyClaimDetail(claimId, contextCompany);
		//cacheFilter.processFilter(contextHttpServletRequest, contextHttpServletResponse);
		return claimDetail;
	}

	@Reference
	private ClaimsReportsService claimsReportsService;

//	@Reference
//	private AgentPortalCacheFilter cacheFilter;

	private static final Logger logger = LoggerFactory.getLogger(ClaimsServiceResourceImpl.class);
}