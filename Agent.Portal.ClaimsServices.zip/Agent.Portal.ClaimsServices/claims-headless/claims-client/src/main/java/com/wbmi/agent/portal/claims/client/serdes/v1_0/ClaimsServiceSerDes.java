package com.wbmi.agent.portal.claims.client.serdes.v1_0;

import com.wbmi.agent.portal.claims.client.dto.v1_0.ClaimsService;
import com.wbmi.agent.portal.claims.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsServiceSerDes {

	public static ClaimsService toDTO(String json) {
		ClaimsServiceJSONParser claimsServiceJSONParser =
			new ClaimsServiceJSONParser();

		return claimsServiceJSONParser.parseToDTO(json);
	}

	public static ClaimsService[] toDTOs(String json) {
		ClaimsServiceJSONParser claimsServiceJSONParser =
			new ClaimsServiceJSONParser();

		return claimsServiceJSONParser.parseToDTOs(json);
	}

	public static String toJSON(ClaimsService claimsService) {
		if (claimsService == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (claimsService.getService() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"service\": ");

			sb.append("\"");

			sb.append(_escape(claimsService.getService()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		ClaimsServiceJSONParser claimsServiceJSONParser =
			new ClaimsServiceJSONParser();

		return claimsServiceJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(ClaimsService claimsService) {
		if (claimsService == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (claimsService.getService() == null) {
			map.put("service", null);
		}
		else {
			map.put("service", String.valueOf(claimsService.getService()));
		}

		return map;
	}

	public static class ClaimsServiceJSONParser
		extends BaseJSONParser<ClaimsService> {

		@Override
		protected ClaimsService createDTO() {
			return new ClaimsService();
		}

		@Override
		protected ClaimsService[] createDTOArray(int size) {
			return new ClaimsService[size];
		}

		@Override
		protected void setField(
			ClaimsService claimsService, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "service")) {
				if (jsonParserFieldValue != null) {
					claimsService.setService((String)jsonParserFieldValue);
				}
			}
			else if (jsonParserFieldName.equals("status")) {
				throw new IllegalArgumentException();
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\":");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(",");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}