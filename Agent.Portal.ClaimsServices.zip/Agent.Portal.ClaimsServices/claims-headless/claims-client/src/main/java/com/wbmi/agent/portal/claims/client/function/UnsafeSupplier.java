package com.wbmi.agent.portal.claims.client.function;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@FunctionalInterface
@Generated("")
public interface UnsafeSupplier<T, E extends Throwable> {

	public T get() throws E;

}