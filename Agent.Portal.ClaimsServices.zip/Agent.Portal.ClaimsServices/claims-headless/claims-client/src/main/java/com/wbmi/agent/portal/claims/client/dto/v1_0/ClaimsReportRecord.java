package com.wbmi.agent.portal.claims.client.dto.v1_0;

import com.wbmi.agent.portal.claims.client.function.UnsafeSupplier;
import com.wbmi.agent.portal.claims.client.serdes.v1_0.ClaimsReportRecordSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsReportRecord implements Cloneable, Serializable {

	public static ClaimsReportRecord toDTO(String json) {
		return ClaimsReportRecordSerDes.toDTO(json);
	}

	public String getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}

	public void setAgencyId(
		UnsafeSupplier<String, Exception> agencyIdUnsafeSupplier) {

		try {
			agencyId = agencyIdUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String agencyId;

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public void setCauseOfLoss(
		UnsafeSupplier<String, Exception> causeOfLossUnsafeSupplier) {

		try {
			causeOfLoss = causeOfLossUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String causeOfLoss;

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	public void setCheckNumber(
		UnsafeSupplier<String, Exception> checkNumberUnsafeSupplier) {

		try {
			checkNumber = checkNumberUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String checkNumber;

	public String getClaimKey() {
		return claimKey;
	}

	public void setClaimKey(String claimKey) {
		this.claimKey = claimKey;
	}

	public void setClaimKey(
		UnsafeSupplier<String, Exception> claimKeyUnsafeSupplier) {

		try {
			claimKey = claimKeyUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String claimKey;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public void setClaimNumber(
		UnsafeSupplier<String, Exception> claimNumberUnsafeSupplier) {

		try {
			claimNumber = claimNumberUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String claimNumber;

	public String getClaimOccurrenceNumber() {
		return claimOccurrenceNumber;
	}

	public void setClaimOccurrenceNumber(String claimOccurrenceNumber) {
		this.claimOccurrenceNumber = claimOccurrenceNumber;
	}

	public void setClaimOccurrenceNumber(
		UnsafeSupplier<String, Exception> claimOccurrenceNumberUnsafeSupplier) {

		try {
			claimOccurrenceNumber = claimOccurrenceNumberUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String claimOccurrenceNumber;

	public String getClaimOccurrenceType() {
		return claimOccurrenceType;
	}

	public void setClaimOccurrenceType(String claimOccurrenceType) {
		this.claimOccurrenceType = claimOccurrenceType;
	}

	public void setClaimOccurrenceType(
		UnsafeSupplier<String, Exception> claimOccurrenceTypeUnsafeSupplier) {

		try {
			claimOccurrenceType = claimOccurrenceTypeUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String claimOccurrenceType;

	public String getClaimantName() {
		return claimantName;
	}

	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}

	public void setClaimantName(
		UnsafeSupplier<String, Exception> claimantNameUnsafeSupplier) {

		try {
			claimantName = claimantNameUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String claimantName;

	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	public void setClosedDate(
		UnsafeSupplier<String, Exception> closedDateUnsafeSupplier) {

		try {
			closedDate = closedDateUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String closedDate;

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public void setDateOfLoss(
		UnsafeSupplier<String, Exception> dateOfLossUnsafeSupplier) {

		try {
			dateOfLoss = dateOfLossUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String dateOfLoss;

	public String getDateReported() {
		return dateReported;
	}

	public void setDateReported(String dateReported) {
		this.dateReported = dateReported;
	}

	public void setDateReported(
		UnsafeSupplier<String, Exception> dateReportedUnsafeSupplier) {

		try {
			dateReported = dateReportedUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String dateReported;

	public String getFinancialTypeCode() {
		return financialTypeCode;
	}

	public void setFinancialTypeCode(String financialTypeCode) {
		this.financialTypeCode = financialTypeCode;
	}

	public void setFinancialTypeCode(
		UnsafeSupplier<String, Exception> financialTypeCodeUnsafeSupplier) {

		try {
			financialTypeCode = financialTypeCodeUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String financialTypeCode;

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public void setLossDescription(
		UnsafeSupplier<String, Exception> lossDescriptionUnsafeSupplier) {

		try {
			lossDescription = lossDescriptionUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String lossDescription;

	public String getPayToTheOrderOf() {
		return payToTheOrderOf;
	}

	public void setPayToTheOrderOf(String payToTheOrderOf) {
		this.payToTheOrderOf = payToTheOrderOf;
	}

	public void setPayToTheOrderOf(
		UnsafeSupplier<String, Exception> payToTheOrderOfUnsafeSupplier) {

		try {
			payToTheOrderOf = payToTheOrderOfUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String payToTheOrderOf;

	public String getPaymentIssuedDate() {
		return paymentIssuedDate;
	}

	public void setPaymentIssuedDate(String paymentIssuedDate) {
		this.paymentIssuedDate = paymentIssuedDate;
	}

	public void setPaymentIssuedDate(
		UnsafeSupplier<String, Exception> paymentIssuedDateUnsafeSupplier) {

		try {
			paymentIssuedDate = paymentIssuedDateUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String paymentIssuedDate;

	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public void setPolicyHolder(
		UnsafeSupplier<String, Exception> policyHolderUnsafeSupplier) {

		try {
			policyHolder = policyHolderUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String policyHolder;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public void setPolicyNumber(
		UnsafeSupplier<String, Exception> policyNumberUnsafeSupplier) {

		try {
			policyNumber = policyNumberUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String policyNumber;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		try {
			status = statusUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String status;

	public String getTotalIncurred() {
		return totalIncurred;
	}

	public void setTotalIncurred(String totalIncurred) {
		this.totalIncurred = totalIncurred;
	}

	public void setTotalIncurred(
		UnsafeSupplier<String, Exception> totalIncurredUnsafeSupplier) {

		try {
			totalIncurred = totalIncurredUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String totalIncurred;

	public String getTotalPaymentAmount() {
		return totalPaymentAmount;
	}

	public void setTotalPaymentAmount(String totalPaymentAmount) {
		this.totalPaymentAmount = totalPaymentAmount;
	}

	public void setTotalPaymentAmount(
		UnsafeSupplier<String, Exception> totalPaymentAmountUnsafeSupplier) {

		try {
			totalPaymentAmount = totalPaymentAmountUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String totalPaymentAmount;

	@Override
	public ClaimsReportRecord clone() throws CloneNotSupportedException {
		return (ClaimsReportRecord)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ClaimsReportRecord)) {
			return false;
		}

		ClaimsReportRecord claimsReportRecord = (ClaimsReportRecord)object;

		return Objects.equals(toString(), claimsReportRecord.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ClaimsReportRecordSerDes.toJSON(this);
	}

}