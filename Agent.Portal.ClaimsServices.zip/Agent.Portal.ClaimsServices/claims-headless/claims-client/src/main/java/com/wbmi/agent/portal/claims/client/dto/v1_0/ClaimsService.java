package com.wbmi.agent.portal.claims.client.dto.v1_0;

import com.wbmi.agent.portal.claims.client.function.UnsafeSupplier;
import com.wbmi.agent.portal.claims.client.serdes.v1_0.ClaimsServiceSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsService implements Cloneable, Serializable {

	public static ClaimsService toDTO(String json) {
		return ClaimsServiceSerDes.toDTO(json);
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public void setService(
		UnsafeSupplier<String, Exception> serviceUnsafeSupplier) {

		try {
			service = serviceUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String service;

	@Override
	public ClaimsService clone() throws CloneNotSupportedException {
		return (ClaimsService)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ClaimsService)) {
			return false;
		}

		ClaimsService claimsService = (ClaimsService)object;

		return Objects.equals(toString(), claimsService.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ClaimsServiceSerDes.toJSON(this);
	}

}