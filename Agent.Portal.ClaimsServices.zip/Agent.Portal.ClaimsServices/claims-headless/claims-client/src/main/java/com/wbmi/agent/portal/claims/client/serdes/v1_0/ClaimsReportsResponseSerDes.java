package com.wbmi.agent.portal.claims.client.serdes.v1_0;

import com.wbmi.agent.portal.claims.client.dto.v1_0.ClaimsReportRecord;
import com.wbmi.agent.portal.claims.client.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;

import javax.annotation.Generated;

/**
 * @author WBMI
 * @generated
 */
@Generated("")
public class ClaimsReportsResponseSerDes {

	public static ClaimsReportsResponse toDTO(String json) {
		ClaimsReportsResponseJSONParser claimsReportsResponseJSONParser =
			new ClaimsReportsResponseJSONParser();

		return claimsReportsResponseJSONParser.parseToDTO(json);
	}

	public static ClaimsReportsResponse[] toDTOs(String json) {
		ClaimsReportsResponseJSONParser claimsReportsResponseJSONParser =
			new ClaimsReportsResponseJSONParser();

		return claimsReportsResponseJSONParser.parseToDTOs(json);
	}

	public static String toJSON(ClaimsReportsResponse claimsReportsResponse) {
		if (claimsReportsResponse == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (claimsReportsResponse.getClaimsReportRecords() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"claimsReportRecords\": ");

			sb.append("[");

			for (int i = 0;
				 i < claimsReportsResponse.getClaimsReportRecords().length;
				 i++) {

				sb.append(
					String.valueOf(
						claimsReportsResponse.getClaimsReportRecords()[i]));

				if ((i + 1) <
						claimsReportsResponse.getClaimsReportRecords().length) {

					sb.append(", ");
				}
			}

			sb.append("]");
		}

		if (claimsReportsResponse.getFilterCriteria() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"filterCriteria\": ");

			sb.append("\"");

			sb.append(_escape(claimsReportsResponse.getFilterCriteria()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		ClaimsReportsResponseJSONParser claimsReportsResponseJSONParser =
			new ClaimsReportsResponseJSONParser();

		return claimsReportsResponseJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(
		ClaimsReportsResponse claimsReportsResponse) {

		if (claimsReportsResponse == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (claimsReportsResponse.getClaimsReportRecords() == null) {
			map.put("claimsReportRecords", null);
		}
		else {
			map.put(
				"claimsReportRecords",
				String.valueOf(claimsReportsResponse.getClaimsReportRecords()));
		}

		if (claimsReportsResponse.getFilterCriteria() == null) {
			map.put("filterCriteria", null);
		}
		else {
			map.put(
				"filterCriteria",
				String.valueOf(claimsReportsResponse.getFilterCriteria()));
		}

		return map;
	}

	public static class ClaimsReportsResponseJSONParser
		extends BaseJSONParser<ClaimsReportsResponse> {

		@Override
		protected ClaimsReportsResponse createDTO() {
			return new ClaimsReportsResponse();
		}

		@Override
		protected ClaimsReportsResponse[] createDTOArray(int size) {
			return new ClaimsReportsResponse[size];
		}

		@Override
		protected void setField(
			ClaimsReportsResponse claimsReportsResponse,
			String jsonParserFieldName, Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "claimsReportRecords")) {
				if (jsonParserFieldValue != null) {
					claimsReportsResponse.setClaimsReportRecords(
						Stream.of(
							toStrings((Object[])jsonParserFieldValue)
						).map(
							object -> ClaimsReportRecordSerDes.toDTO(
								(String)object)
						).toArray(
							size -> new ClaimsReportRecord[size]
						));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "filterCriteria")) {
				if (jsonParserFieldValue != null) {
					claimsReportsResponse.setFilterCriteria(
						(String)jsonParserFieldValue);
				}
			}
			else if (jsonParserFieldName.equals("status")) {
				throw new IllegalArgumentException();
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\":");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(",");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}