package com.wbmi.agent.portal.claims.internal.model;

public class ClaimsEmail {

    public String emailAddress;
    public String emailType;
}
