package com.wbmi.agent.portal.claims.internal.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ClaimSummary {
	   
    public ClaimSummary(String jsonClaim) {

       this.document = Configuration.defaultConfiguration().jsonProvider().parse(jsonClaim);

       setHeaderFields();
       loadReserves();
       loadAdjuster();

    }

    public void setHeaderFields() {
       this.claimNumber = JsonPath.read(document,"$.Claim.Claim.ClaimNumber");
       this.claimStatus = JsonPath.read(document,"$.Claim.Claim.ClaimStatusCodeDescription");
    }

    private ClaimsEmail findEmailContact(String key) {
       String query = String.format("$.Claim.Claim.ContactPoints.EmailContacts[?(@.key=='%s')]",key);
    	List<Map<String, Object>> emailContacts = JsonPath.read(document,query);
    	if (emailContacts.size() > 0) {
            for (Map <String,Object> emailContact: emailContacts) {
                String testKey = (String) emailContact.get("key");
                if (testKey.equals(key)) {
                    ClaimsEmail claimsEmail = new ClaimsEmail();
                    claimsEmail.emailAddress = (String) emailContact.get("EmailAddress");
                    claimsEmail.emailType = (String) emailContact.get("EmailTypeCode");
                    return claimsEmail;
                }
            }
        }
    	return null;
    }

    private ClaimsPhone findPhone(String key) {
        String query = String.format("$.Claim.Claim.ContactPoints.TelephoneContacts[?(@.key=='%s')]",key);
        List<Map<String, Object>> phoneContacts = JsonPath.read(document,query);
        if (phoneContacts.size() > 0) {
            for (Map <String,Object> phoneContact: phoneContacts) {
                String testKey = (String) phoneContact.get("key");
                if (testKey.equals(key)) {
                    ClaimsPhone claimsPhone = new ClaimsPhone();
                    claimsPhone.phoneNumber = (String) phoneContact.get("TelephoneNumber");
                    claimsPhone.phoneType = (String) phoneContact.get("TelephoneTypeCode");
                    return claimsPhone;
                }
            }
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
	private ClaimPerson getPerson(String key) {
    	String query = String.format("$.Claim.Claim.Parties.People[?(@.key=='%s')]",key);
    	List<Map<String, Object>> people = JsonPath.read(document,query);
    	if (people.size() > 0) {
    		ClaimPerson claimPerson = new ClaimPerson();
    		Map<String, Object> person = people.get(0);
    		List<Map<String, Object>> names = (List<Map<String, Object>>) person.get("PersonNames");
    		if (names != null && names.size() > 0) {
    			Map<String, Object> nameinfo = names.get(0);
    			claimPerson.firstName = (String) nameinfo.get("GivenName");
    			claimPerson.lastName = (String) nameinfo.get("Surname");
                Map<String, Object> references = (Map<String, Object>) person.get("References");
                List<String> contacts = (List<String>) references.get("ContactPointReferences");
                if (contacts.size() > 0) {
                    contacts.forEach(contactKey -> {
                        ClaimsEmail email = findEmailContact(contactKey);
                        if (email != null) {
                            claimPerson.emailList.add(email);
                        }
                        ClaimsPhone phone = findPhone(contactKey);
                        if (phone != null) {
                            claimPerson.phoneList.add(phone);
                        }
                    });
                }
    		}
        	return claimPerson;
    	}
    	return null;
    }
    
    @SuppressWarnings("unchecked")
  	private ClaimOrganization getOrganization(String key) {
      	String query = String.format("$.Claim.Claim.Parties.Organizations[?(@.key=='%s')]",key);
      	List<Map<String, Object>> orgs = JsonPath.read(document,query);
      	if (orgs.size() > 0) {
      		ClaimOrganization claimOrganization = new ClaimOrganization();
      		Map<String, Object> org = orgs.get(0);
      		List<Map<String, Object>> names = (List<Map<String, Object>>) org.get("OrganizationNames");
      		if (names != null && names.size() > 0) {
      			Map<String, Object> nameinfo = names.get(0);
      			claimOrganization.name = (String) nameinfo.get("FullName");
      		}
          	return claimOrganization;
      	}
      	return null;
    }

    @SuppressWarnings("unchecked")
    private void loadAdjuster() {
        List<Map<String, Object>> adjusters = JsonPath.read(document,"$.Claim.Claim.PartyRoleInClaim.ClaimAdjusters");
        if (adjusters.size() > 0) {
            Map<String, Object> adjuster = adjusters.get(0);
            Map<String,Object> references = (Map<String,Object>) adjuster.get("References");
            List<String> partyReferences = (List<String>) references.get("PartyReferences");
            String adjusterKey = partyReferences.get(0);
            this.adjuster = getPerson(adjusterKey);
        }
    }

    private void loadReserves() {
        List<ClaimReserve> claimReserves = new ArrayList<>();
        List<Map<String, Object>> reserves = JsonPath.read(document,"$.Claim.Claim.ClaimReserves");
        reserves.forEach (reserve -> {
            ClaimReserve claimReserve = new ClaimReserve();
            claimReserve.majorPeril = (String) reserve.get("ReserveMajorPeril");
            claimReserve.reserveCategory = (String) reserve.get("ReserveCategory");
            claimReserves.add(claimReserve);
        });
        this.claimReserves = claimReserves;
    }

    //  fields for the claim
    public String claimNumber;
    public String claimStatus;
    public ClaimPerson adjuster;
    public List<ClaimReserve> claimReserves;

    // parsed JSON document
    @JsonIgnore
    private final Object document;
    
    // generate JSON output for this object
    public String toString() {
        ObjectMapper mapper = new ObjectMapper();  
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }

    // main function for internal/development testing
    public static void main(String[] args) throws Exception {
        String json = new String(Files.readAllBytes(Paths.get("C:/Users/mfreeman/Projects/temp/jsonpath/Claims_Detail.json")));
        ClaimSummary claimSummary = new ClaimSummary(json);
        System.out.println(claimSummary);
    }
}
