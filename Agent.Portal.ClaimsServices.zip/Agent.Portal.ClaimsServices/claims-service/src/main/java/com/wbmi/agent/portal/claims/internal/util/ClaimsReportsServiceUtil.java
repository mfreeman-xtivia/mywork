package com.wbmi.agent.portal.claims.internal.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ClaimsReportsServiceUtil {

	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");

	public static String formatDate(String dateValue) {
		LocalDate date = LocalDate.parse(dateValue);
		return formatter.format(date);
	}

	public static LocalDate getDate(String dateValue) {
		return LocalDate.parse(dateValue, formatter);
	}

}
