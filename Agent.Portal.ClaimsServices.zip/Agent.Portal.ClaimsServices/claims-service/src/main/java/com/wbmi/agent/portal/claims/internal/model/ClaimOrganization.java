package com.wbmi.agent.portal.claims.internal.model;

public class ClaimOrganization {

	public String name = "unknown";
}
