package com.wbmi.agent.portal.claims.service.impl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Company;
import com.wbmi.agent.portal.claims.dto.v1_0.ClaimsReportsResponse;
import com.wbmi.agent.portal.claims.internal.resource.ClaimsReportsServiceResource;
import com.wbmi.agent.portal.claims.service.ClaimsReportsService;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, service = ClaimsReportsService.class)
public class ClaimsReportsServiceImpl implements ClaimsReportsService {

	@Override
	public ClaimsReportsResponse getAgencyClaimsReports(String agencyId,
														String claimType,
														String dateRange,
														Company company)
			                                            throws PortalException {
		logger.debug("ClaimsReportsImpl.getAgencyClaimsReports()");
		return agencyClaimsReportsResource.getAgencyClaimsReports(agencyId,claimType, dateRange, company);
	}

	@Override
	public String getAgencyClaimDetail(String claimId, Company company) throws PortalException {
		logger.debug("ClaimsReportsImpl.getAgencyClaimDetail()");
		return agencyClaimsReportsResource.getAgencyClaimDetail(claimId,company);
	}


	@Reference
	private ClaimsReportsServiceResource agencyClaimsReportsResource;

	private static final Logger logger =
			LoggerFactory.getLogger(ClaimsReportsServiceImpl.class);

}
