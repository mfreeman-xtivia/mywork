package com.wbmi.agent.portal.claims.internal.model;

public class ClaimsPhone {

    public String phoneNumber;
    public String phoneType;
}
