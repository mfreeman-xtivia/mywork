package com.wbmi.agent.portal.claims.internal.model;

import java.util.ArrayList;
import java.util.List;

public class ClaimPerson {

	public String firstName = "unknown";
	public String lastName = "unknown";

	public List<ClaimsEmail> emailList = new ArrayList<>();
	public List<ClaimsPhone> phoneList = new ArrayList<>();
}
