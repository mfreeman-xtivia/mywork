package com.wbmi.agent.portal.claims.internal.model;

public class ClaimReserve {

    public String majorPeril;
    public String reserveCategory;
}
