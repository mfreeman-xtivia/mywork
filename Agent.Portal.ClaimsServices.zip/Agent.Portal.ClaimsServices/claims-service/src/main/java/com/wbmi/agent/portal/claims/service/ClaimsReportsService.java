package com.wbmi.agent.portal.claims.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Company;
import com.wbmi.agent.portal.claims.dto.v1_0.ClaimsReportsResponse;

public interface ClaimsReportsService {

	public ClaimsReportsResponse getAgencyClaimsReports(String agencyId,
														String claimType,
														String dateRange,
														Company company	)
			                                            throws PortalException;

	public String getAgencyClaimDetail(String claimId, Company company) throws PortalException;
}
