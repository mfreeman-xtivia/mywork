package com.wbmi.agent.portal.claims.internal.constants;

public class ClaimsConstants {

	public static final String CLAIMS_REPORTS_RESPONSE_JSON_FILE =
            "/META-INF/default-ws-responses/AgencyClaimsReportsResponse";
	public static final String CLAIMS_DETAIL_RESPONSE_JSON_FILE =
			"/META-INF/default-ws-responses/AgencyClaimsDetailResponse";

	public static final String NEW_CLAIMS = "newClaims";
	public static final String CLOSED_CLAIMS = "closedClaims";
	public static final String CLAIM_PAYMENTS = "claimPayments";

	public static final String LAST7DAYS = "lastSevenDays";
	public static final String LAST2WEEKS = "lastTwoWeeks";
	public static final String LASTMONTH = "lastMonth";

}
